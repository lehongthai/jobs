<?php

namespace App\Employer;

use Illuminate\Database\Eloquent\Model;

class EmployerJoinCandidate extends Model
{
    protected $table = 'employer_jon_candidate';
    protected $fillable = ['id', 'employer_id', 'id_candidate', 'da_lien_he', 'da_phong_van', 'tu_choi', 'da_test', 'trung_tuyen', 'create_date', 'note'];
    public $timestamps = false;
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdditionalCompany extends Model
{
    protected $table = 'additional_company';
    protected $fillable = ['id', 'user_id', 'name', 'email', 'phone', 'address'];
    public $timestamps = false;
}

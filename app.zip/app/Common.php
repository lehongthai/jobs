<?php 
namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
class Common extends Model {

	public static function getProvin()
	{
		return DB::table('provins')->get();
	}

	public static function getJob()
	{
		return DB::table('jobs')->select('id', 'name')->get();
	}

	public static function getLevel()
	{
		return DB::table('infocv_user')->where('alias', 'level')->get();
	}

	public static function getEmpirical()
	{
		return DB::table('infocv_user')->where('alias', 'empirical')->get();
	}

	public static function getDiploma()
	{
		return DB::table('infocv_user')->where('alias', 'diploma')->get();
	}

	public static function getDiplomaWish()
	{
		return DB::table('infocv_user')->where('alias', 'diploma_wish')->get();
	}

	public static function getExigency()
	{
		return DB::table('infocv_user')->where('alias', 'exigency')->get();
	}
	public static function getProbationTime()
	{
		return DB::table('infocv_user')->where('alias', 'probation_time')->get();
	}

	public static function getWage()
	{
		return DB::table('infocv_user')->where('alias', 'wage')->get();
	}

	public static function Attribute()
	{
		return DB::table('infocv_user')->where('alias', 'attribute')->get();
	}

	public static function getType()
	{
		return DB::table('type')->get();
	}
	public static function getLoaiTn()
	{
		return DB::table('infocv_user')->where('alias', 'loai_tn')->get();
	}
	public static function getLanguage()
	{
		return DB::table('infocv_user')->where('alias', 'language')->get();
	}
	public static function getLanguageLevel()
	{
		return DB::table('infocv_user')->where('alias', 'language_level')->get();
	}
	public static function getQuyMo()
	{
		return DB::table('infocv_user')->where('alias', 'quy_mo')->get();
	}

	public static function getNameById($id)
	{
		return DB::table('infocv_user')->where('id', $id)->value('name');
	}

	public static function getTypeNameById($id)
	{
		return DB::table('type')->where('id', $id)->value('name');
	}

	public static function getJobNameById($id)
	{
		return DB::table('jobs')->where('id', $id)->first()->name;
	}

	public static function getProvinNameById($id)
	{
		return DB::table('provins')->where('id', $id)->value('name');
	}

	public static function getTypeLanguageAndTech($value)
	{
		$result = 'Không Xác Định';
		if ($value == 1) {
			$result = 'Giỏi';
		}elseif($value == 2){
			$result = 'Khá';
		}elseif($value == 3){
			$result = 'Trung Bình';
		}elseif($value == 4){
			$result = 'Kém';
		}

		return $result;
	}
	public static function getInfoResume($id)
	{
		return DB::table('cv_user')->where('user_id', $id)->first();
	}

	public static function countViewJob($id)
	{
		return DB::table('candidate_join_jobs')->where('jobs_id', 2)->count();
	}

	public static function getInfoCompanyById($id)
	{
		return DB::table('company')->where('id', $id)->first();
	}

	/*get list job in company*/
	public static function getJobCompanyById($employer_id)
	{
		return DB::table('post_jobs')->where('employer_id', $employer_id)->where('active', 1)->where('status', 1)->get();
	}

	/*get company id by id user*/
	public static function getCompanyIdByUserId($user_id)
	{
		return DB::table('company')->where('user_id', $user_id)->first()->id;
	}

	/*get company name by id user*/
	public static function getCompanyNameById($id)
	{
		return DB::table('company')->where('id', $id)->value('name');
	}

	/*get viec làm hot*/
	public static function getHotJob($limit=10)
	{
		return DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type_job', 1)->where('active', 1)->where('status', 1)->skip(0)->take($limit)->get();
	}
	public static function getNewJob($limit=10)
	{
		return DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type_job', 4)->where('active', 1)->where('status', 1)->skip(0)->take($limit)->get();
	}
	public static function getHighWageJob($limit=10)
	{
		return DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type_job', 2)->where('active', 1)->where('status', 1)->skip(0)->take($limit)->get();
	}
	public static function getGapJob($limit=10)
	{
		return DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type_job', 3)->where('active', 1)->where('status', 1)->skip(0)->take($limit)->get();
	}

}

<?php

namespace App\Candidate;

use Illuminate\Database\Eloquent\Model;
use DB;
class Check extends Model
{
    public static function checkStatus($user_id)
    {
    	$totalDetail = DB::select('select count(*) as totalDetail from detail_cv where candidate_id = ?', [$user_id])[0]->totalDetail;
    	$totalDiploma = DB::select('select count(*) as totalDiploma from detail_cv_diploma where candidate_id = ?', [$user_id])[0]->totalDiploma;

    	if ($totalDetail > 0 && $totalDiploma > 0) {
    		return true;
    	}else{
    		return false;
    	}
    }

    public static function checkCompanyActive($user_id)
    {
        $active = DB::select('select active from company where user_id = ?', [$user_id])[0]->active;
        if ($active == 1) {
            return true;
        }else{
            return false;
        }
    }
}

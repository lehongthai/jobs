<?php 
namespace App\Http\Controllers;
use DB, Mail, Auth;
use App\Common;
use Session;
use Illuminate\Http\Request;

class MainController extends Controller {

	public function viewResume($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return redirect('404');
		}else{
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id = $id_arr[count($id_arr) - 1];

			$infoResume = \App\CvUser::where('id', $id)->where('duyet', 1)->first();
			if ($infoResume) {
				$infoCandidate = DB::select('select * from users where id = ?', [$infoResume->user_id])[0];
				$infoDetailResume = DB::select('select * from detail_cv where candidate_id = ?', [$infoResume->user_id])[0];
				$infoDetailResumeDiploma = DB::select('select * from detail_cv_diploma where candidate_id = ?', [$infoResume->user_id])[0];
				DB::update('update cv_user set view = view + 1 where id = ?', [$id]);
				return view('page.content.resume_detail', compact('infoResume', 'infoCandidate', 'infoDetailResume', 'infoDetailResumeDiploma'));
			}else{
				return redirect('404');
			}
			
		}
	}
	public function viewJob($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return redirect('404');
		}else{
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id = $id_arr[count($id_arr) - 1];
			$detailJob = DB::table('post_jobs')->where('id', $id)->where('active', 1)->where('status', 1)->first();

			if ($detailJob) {
				$listRelatedJob = array();
				$arrRelated = explode(',', $detailJob->fields);
				$sqlRelated = "SELECT * FROM post_jobs WHERE active =1 AND status = 1 AND id <> $id ";
				foreach ($arrRelated as $key => $val) 
				{
					if (isset($key) && $key != 0 && (count($arrRelated) - 1) != $key) 
					{
						$sqlRelated .= ' OR fields LIKE "%' . $val . '%" ';
					}elseif(isset($key) && $key == 0 && count($arrRelated) > 1)
					{
						$sqlRelated .= 'AND (fields LIKE "%' . $val . '%" ';
					}elseif(isset($key) && $key == 0  && count($arrRelated) == 1){
						$sqlRelated .= 'AND fields LIKE "%' . $val . '%" ';
					}elseif(isset($key) && (count($arrRelated) - 1) == $key)
					{
						$sqlRelated .= ' OR fields LIKE "%' . $val . '%") ';
					}
				}

				$sqlRelated .= " ORDER BY view LIMIT 10";

				$listRelatedJob = DB::select($sqlRelated);
				DB::update('update post_jobs set view = view + 1 where id = ?', [$id]);
				
				return view('page.content.job_detail', compact('detailJob', 'listRelatedJob'));
			}else{
				return redirect('404');
			}
		}
		
	}

	public function getSearchJob()
	{
		$sqlSearch = "SELECT id, alias, employer_id, provin, type, wage, title FROM post_jobs WHERE active = 1 AND status =1 ";
		$url = url('tim-kiem?');

		if (isset($_GET['title']) && $_GET['title'] != NULL) 
		{
			$sqlSearch .= ' AND alias LIKE "%' . convert_vi_to_en($_GET['title']) . '%" ';
			$url .= 'title=' . $_GET['title'];
		}
		if (isset($_GET['wage']) && $_GET['wage'] != NULL) 
		{
			$sqlSearch .= ' AND wage = ' . $_GET['wage'];
			$url .= '&wage=' . $_GET['wage'];
		}
		if (isset($_GET['level']) && $_GET['level'] != NULL) 
		{
			$sqlSearch .= ' AND level = ' . $_GET['level'];
			$url .= '&level=' . $_GET['level'];
		}
		if (isset($_GET['empirical']) && $_GET['empirical'] != NULL) 
		{
			$sqlSearch .= ' AND empirical = ' . $_GET['empirical'];
			$url .= '&empirical=' . $_GET['empirical'];
		}
		if (isset($_GET['type']) && $_GET['type'] != NULL) 
		{
			$sqlSearch .= ' AND type = ' . $_GET['type'];
			$url .= '&type=' . $_GET['type'];
		}
		if (isset($_GET['provin']) && $_GET['provin'] != NULL && $_GET['provin'] != 'all') 
		{
			$sqlSearch .= ' AND provin LIKE "%^' . $_GET['provin'] . '^%"';
			$url .= '&provin=' . $_GET['provin'];
		}
		if (isset($_GET['sex']) && $_GET['sex'] != NULL && $_GET['sex'] != 0) 
		{
			$sqlSearch .= ' AND sex = ' . $_GET['sex'];
			$url .= '&sex=' . $_GET['sex'];
		}
		if (isset($_GET['job']) && $_GET['job'] != NULL) 
		{
			$sqlSearch .= ' AND fields LIKE "%^' . $_GET['job'] . '^%"';
			$url .= '&job=' . $_GET['job'];
		}

		$start = 0;
		$limit = 3;
		$total = count(DB::select($sqlSearch));
			$totalPagination = ($total % $limit == 0) ? intval($total / $limit) : intval($total / $limit) + 1;
		
			$sqlSearchRow = getPagination($total, $start, $limit, $sqlSearch, " ORDER BY view ");

			$searchRessult = DB::select($sqlSearchRow);

			return view('page.content.searchJob', compact('searchRessult', 'totalPagination', 'url'));
	}


	public function findJobByCompany($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return view('page.content.resume');
		}else{
			$url = url('cong-ty/' . $alias . '?');
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id_company = $id_arr[count($id_arr) - 1];
			$sqlSearch = "SELECT id, alias, employer_id, provin, type, wage, title, expired_at FROM post_jobs WHERE employer_id = $id_company AND active = 1 AND status =1 ";
			$start = 0;
			$limit = 1;
			$total = count(DB::select($sqlSearch));
				$totalPagination = ($total % $limit == 0) ? intval($total / $limit) : intval($total / $limit) + 1;
				$sqlSearchRow = getPagination($total, $start, $limit, $sqlSearch, " ORDER BY view ");

				$listJob = DB::select($sqlSearchRow);
				$detailCompany = DB::select('select * from company where id = ?', [$id_company])[0];

				return view('page.content.findJob', compact('totalPagination', 'detailCompany', 'listJob', 'url'));
		}
	}

	public function findJobByProvin($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return view('page.content.resume');
		}else{
			$url = url('tinh-thanh/' . $alias . '?');
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id_provin = $id_arr[count($id_arr) - 1];
			$sqlSearch = 'SELECT id, alias, employer_id, provin, type, wage, title, expired_at FROM post_jobs WHERE active = 1 AND status = 1 AND provin LIKE "%^' . $id_provin . '^%"';
			$start = 0;
			$limit = 1;
			$total = count(DB::select($sqlSearch));
				$totalPagination = ($total % $limit == 0) ? intval($total / $limit) : intval($total / $limit) + 1;
				$sqlSearchRow = getPagination($total, $start, $limit, $sqlSearch, " ORDER BY view ");

				$listJob = DB::select($sqlSearchRow);
				$detailProvin = DB::select('select * from provins where id = ?', [$id_provin])[0];

				return view('page.content.findJob', compact('totalPagination', 'detailProvin', 'listJob', 'url'));
		}
	}
	public function findJobByJob($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return view('page.content.resume');
		}else{
			$url = url('viec-lam/' . $alias . '?');
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id_job = $id_arr[count($id_arr) - 1];
			$sqlSearch = 'SELECT id, alias, employer_id, provin, type, wage, title, expired_at FROM post_jobs WHERE active =1 AND status = 1 AND fields LIKE "%^' . $id_job . '^%"';
			$start = 0;
			$limit = 1;
			$total = count(DB::select($sqlSearch));
				$totalPagination = ($total % $limit == 0) ? intval($total / $limit) : intval($total / $limit) + 1;
				$sqlSearchRow = getPagination($total, $start, $limit, $sqlSearch, " ORDER BY view ");

				$listJob = DB::select($sqlSearchRow);
				$detailProvin = DB::select('select * from jobs where id = ?', [$id_job])[0];

				return view('page.content.findJob', compact('totalPagination', 'detailProvin', 'listJob', 'url'));
		}
	}

	public function getSearchResume()
	{
		$sqlSearch = "SELECT cv.id, u.fullname, cv.title, cv.alias, cv.provin_wish, cv.empirical, cv.wage 
						FROM cv_user AS cv 
						LEFT JOIN users AS u 
							ON cv.user_id = u.id 
					    WHERE cv.duyet = 1 ";
		$url = url('tim-kiem-ho-so?');

		if (isset($_GET['title']) && $_GET['title'] != NULL) 
		{
			$sqlSearch .= ' AND cv.alias LIKE "%' . convert_vi_to_en($_GET['title']) . '%" ';
			$url .= 'title=' . $_GET['title'];
		}
		if (isset($_GET['level']) && $_GET['level'] != NULL) 
		{
			$sqlSearch .= ' AND cv.level = ' . $_GET['level'];
			$url .= '&level=' . $_GET['level'];
		}
		if (isset($_GET['empirical']) && $_GET['empirical'] != NULL) 
		{
			$sqlSearch .= ' AND cv.empirical = ' . $_GET['empirical'];
			$url .= '&empirical=' . $_GET['empirical'];
		}
		if (isset($_GET['type']) && $_GET['type'] != NULL) 
		{
			$sqlSearch .= ' AND cv.type = ' . $_GET['type'];
			$url .= '&type=' . $_GET['type'];
		}
		if (isset($_GET['provin']) && $_GET['provin'] != NULL && $_GET['provin'] != 'all') 
		{
			$sqlSearch .= ' AND cv.provin_wish LIKE "%^' . $_GET['provin'] . '^%"';
			$url .= '&provin=' . $_GET['provin'];
		}
		if (isset($_GET['sex']) && $_GET['sex'] != NULL && $_GET['sex'] != 0) 
		{
			$sqlSearch .= ' AND u.sex = ' . $_GET['sex'];
			$url .= '&sex=' . $_GET['sex'];
		}
		if (isset($_GET['job']) && $_GET['job'] != NULL) 
		{
			$sqlSearch .= ' AND cv.jobs_wish LIKE "%^' . $_GET['job'] . '^%"';
			$url .= '&job=' . $_GET['job'];
		}
		$start = 0;
		$limit = 1;
		$total = count(DB::select($sqlSearch));
			$totalPagination = ($total % $limit == 0) ? intval($total / $limit) : intval($total / $limit) + 1;
			$sqlSearchRow = getPagination($total, $start, $limit, $sqlSearch, " ORDER BY view ");

			$searchRessult = DB::select($sqlSearchRow);
			$title = 'Kết quả tìm kiếm';
			return view('page.content.searchCandidates', compact('searchRessult', 'totalPagination', 'url', 'title'));
	}

	public function getFullResume()
	{
		$listResume = DB::table('cv_user')->select('cv_user.id', 'users.fullname', 'cv_user.title', 'cv_user.alias', 'cv_user.provin_wish', 'cv_user.empirical', 'cv_user.wage')
						->where('duyet', 1)
					   ->join('users', 'users.id', '=', 'cv_user.user_id')
		               ->orderBy('cv_user.create_date', 'DESC')->paginate(1);
		$title = 'Tất cả hồ sơ';
		return view('page.content.candidates', compact('listResume', 'title'));
	}

	public function findResumeByProvin($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return view('page.content.resume');
		}else{
			$url = url('ho-so-tinh-thanh/' . $alias . '?');
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id_provin = $id_arr[count($id_arr) - 1];
			$sqlSearch = 'SELECT cv.id, u.fullname, cv.title, cv.alias, cv.provin_wish, cv.empirical, cv.wage 
						FROM cv_user AS cv 
						LEFT JOIN users AS u 
							ON cv.user_id = u.id 
						WHERE duyet = 1 AND cv.provin_wish LIKE "%^' . $id_provin . '^%"';
			$start = 0;
			$limit = 1;
			$total = count(DB::select($sqlSearch));
				$totalPagination = ($total % $limit == 0) ? intval($total / $limit) : intval($total / $limit) + 1;
				$sqlSearchRow = getPagination($total, $start, $limit, $sqlSearch, " ORDER BY view ");

				$searchRessult = DB::select($sqlSearchRow);
				$detailProvin = DB::select('select * from provins where id = ?', [$id_provin])[0];
				return view('page.content.findResume', compact('detailProvin', 'totalPagination', 'searchRessult', 'url'));
		}
	}

	public function findResumeByJob($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return view('page.content.resume');
		}else{
			$url = url('ho-so-cong-viec/' . $alias . '?');
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id_job = $id_arr[count($id_arr) - 1];
			$sqlSearch = 'SELECT cv.id, u.fullname, cv.title, cv.alias, cv.provin_wish, cv.empirical, cv.wage 
						FROM cv_user AS cv 
						LEFT JOIN users AS u 
							ON cv.user_id = u.id 
						WHERE duyet = 1 AND cv.jobs_wish LIKE "%^' . $id_job . '^%"';
			$start = 0;
			$limit = 1;
			$total = count(DB::select($sqlSearch));
				$totalPagination = ($total % $limit == 0) ? intval($total / $limit) : intval($total / $limit) + 1;	
				$sqlSearchRow = getPagination($total, $start, $limit, $sqlSearch, " ORDER BY view ");

				$searchRessult = DB::select($sqlSearchRow);
				$detailProvin = DB::select('select * from jobs where id = ?', [$id_job])[0];
				return view('page.content.findResume', compact('detailProvin', 'totalPagination', 'searchRessult', 'url'));
		}
	}
	
}

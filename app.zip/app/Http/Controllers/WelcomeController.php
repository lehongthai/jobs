<?php 
namespace App\Http\Controllers;
use DB, Mail;
use App\Common;
use Illuminate\Http\Request;

class WelcomeController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Welcome Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders the "marketing page" for the application and
	| is configured to only allow guests. Like most of the other sample
	| controllers, you are free to modify or remove it as you desire.
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */

	/**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
		$listSlider = \App\Post::select('id', 'title', 'intro', 'alias', 'image_link')->get();
		$hotJob = Common::getHotJob(20);
		$newJob = Common::getNewJob(20);
		$highJob = Common::getHighWageJob(20);
		$gapJob = Common::getGapJob(20);
		$companyJobs = DB::select('SELECT * FROM company ORDER BY count_job ASC LIMIT 2');
		$companyTuyenDung = DB::select('SELECT company.id, company.logo, company.name, company.alias, company.logo, count(post_jobs.employer_id) as total FROM company LEFT JOIN post_jobs ON company.id = post_jobs.employer_id WHERE tuyen_dung = 1 GROUP BY company.id');
		return view('page.content.home', compact('hotJob', 'newJob', 'highJob', 'gapJob', 'companyJobs', 'companyTuyenDung', 'listSlider'));
	}

	public function findJobByHighWage()
	{
		$listJob = DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type_job', 2)->where('active', 1)->where('status', 1)->paginate(1);
		$title = 'Việc làm lương cao';
		return view('page.content.job', compact('listJob', 'title'));
	}

	public function findJobByNew()
	{
		$listJob = DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type_job', 4)->where('active', 1)->where('status', 1)->paginate(1);
		$title = 'Việc làm mới nhất';
		return view('page.content.job', compact('listJob', 'title'));
	}

	public function findJobByHot()
	{
		$listJob = DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type_job', 1)->where('active', 1)->where('status', 1)->paginate(1);
		$title = 'Việc làm đang hot';
		return view('page.content.job', compact('listJob', 'title'));
	}

	public function findJobByGap()
	{
		$listJob = DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type_job', 1)->where('active', 1)->where('status', 1)->paginate(1);
		$title = 'Việc làm tuyển gấp';
		return view('page.content.job', compact('listJob', 'title'));
	}


	public function findFullJob()
	{
		$listJob = DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('active', 1)->where('status', 1)->orderBy('create_date', 'DESC')->paginate(1);
		$title = 'Tất cả việc làm';
		return view('page.content.job', compact('listJob', 'title'));
	}



	public function findJobByManager()
	{
		$listJob = DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type', 2)->where('active', 1)->where('status', 1)->paginate(1);
		$title = 'Việc làm bán thời gian';
		return view('page.content.job', compact('listJob', 'title'));
	}
	public function findJobByStudent()
	{
		$listJob = DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type', 3)->where('active', 1)->where('status', 1)->paginate(1);
		$title = 'Công việc thực tập';
		return view('page.content.job', compact('listJob', 'title'));
	}
	public function findJobByCommon()
	{
		$listJob = DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type', 6)->where('active', 1)->where('status', 1)->paginate(1);
		$title = 'Việc làm ngoài giờ';
		return view('page.content.job', compact('listJob', 'title'));
	}
	public function findJobBySpecialized()
	{
		$listJob = DB::table('post_jobs')->select('id','employer_id', 'title', 'alias', 'wage', 'provin', 'type')->where('type', 5)->where('active', 1)->where('status', 1)->paginate(1);
		$title = 'Việc làm chính thức';
		return view('page.content.job', compact('listJob', 'title'));
	}

	public function getInResume($id='')
	{
		if ($id == null || !is_numeric($id)) {
			return view('page.content.resume');
		}else{
			$infoUser = \App\User::select('*')->where('id', $id)->first();
			$infoResume = \App\CvUser::where('user_id', $id)->first();
			$infoDetailResume = DB::select('select * from detail_cv where candidate_id = ?', [$id])[0];
			$infoDetailResumeDiploma = DB::select('select * from detail_cv_diploma where candidate_id = ?', [$id])[0];
			return view('page.content.candidate.inResume', compact('infoUser', 'infoResume', 'infoDetailResume', 'infoDetailResumeDiploma'));
		}
	}

	public function getViewAq()
	{
		$listAq = DB::select('select * from aq ORDER BY orders');
		$title = 'Câu hỏi thường gặp';
		return view('page.content.aq', compact('title', 'listAq'));
	}

	public function postContact(Request $request)
	{
		$this->validate($request, 
				[
				 'contact_name' => 'required',
				 'contact_email' => 'required|e-mail',
				 'contact_subject' => 'required|min:10',
				 'contact_message' => 'required'
				], 
				[
				'contact_name.required' => 'Bạn chưa nhập tên',
				'contact_email.required' => 'Bạn chưa nhập email',
				'contact_subject.required' => 'Bạn chưa nhập tiêu đề',
				'contact_message.required' => 'Bạn chưa nhập nội dung',
				'contact_email.e_mail' => 'Đại chỉ mail sai',
				'contact_subject.min' => 'Tiêu đề ít nhất 10 kí tự'
				]);
		$data = [
			'name' => $request->contact_name,
			'email' => $request->contact_email,
			'title' => $request->contact_subject,
			'message' => $request->contact_message,
			];
		Mail::send('emails.mail_body',['data' => $data], function ($message) use ($data) {
		    $message->from($data['email'], $data['name']);
		    $message->sender($data['email'], $data['name']);
		
		    $message->to('teamchich26@gmail.com', 'Admin');
		
		    $message->replyTo($data['email'], $data['name']);
		
		    $message->subject($data['title']);
		
		    $message->priority(3);
		
		    //$message->attach('pathToFile');
		});

		echo "<script>
			alert('Cảm ơn bạn, chúng tối đã nhận được mail và sẽ liên hệ lại với bạn sớm nhất !!');
			window.location = '".url('/')."'
		</script>";
	}

	public function getViewPost($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return view('page.content.resume');
		}else{
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id = $id_arr[count($id_arr) - 1];
			$detailPost = \App\Post::find($id);
			if ($detailPost) {
				DB::update('update posts set views = views+1 where id = ?', [$id]);
				return view('page.content.post', compact('detailPost'));
			}else{
				return redirect('404');
			}
		}
	}
}

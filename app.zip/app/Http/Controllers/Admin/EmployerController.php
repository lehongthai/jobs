<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use DB, Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class EmployerController extends Controller
{
    public function getListResume()
    {
    	$listJob = DB::select('SELECT pj.id, pj.employer_id, c.name, c.alias AS cAlias, pj.title, pj.create_date, pj.status, pj.alias, pj.active, pj.type_job from post_jobs as pj LEFT JOIN company as c ON c.id = pj.employer_id ');
    	//pre($listJob);
    	$title = "Danh sách việc làm";
    	return view('admin.nhatuyendung.list', compact('listJob', 'title'));
    }

    public function viewJob($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return redirect('admin/quan-ly-cong-viec/danh-sach');
		}else{
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id = $id_arr[count($id_arr) - 1];
			$detailJob = DB::table('post_jobs')->where('id', $id)->first();

			if ($detailJob) {
				$listRelatedJob = array();
				$arrRelated = explode(',', $detailJob->fields);
				$sqlRelated = "SELECT * FROM post_jobs WHERE active =1 AND status = 1 AND id <> $id ";
				foreach ($arrRelated as $key => $val) 
				{
					if (isset($key) && $key != 0 && (count($arrRelated) - 1) != $key) 
					{
						$sqlRelated .= ' OR fields LIKE "%' . $val . '%" ';
					}elseif(isset($key) && $key == 0 && count($arrRelated) > 1)
					{
						$sqlRelated .= 'AND (fields LIKE "%' . $val . '%" ';
					}elseif(isset($key) && $key == 0  && count($arrRelated) == 1){
						$sqlRelated .= 'AND fields LIKE "%' . $val . '%" ';
					}elseif(isset($key) && (count($arrRelated) - 1) == $key)
					{
						$sqlRelated .= ' OR fields LIKE "%' . $val . '%") ';
					}
				}

				$sqlRelated .= " ORDER BY view LIMIT 10";

				$listRelatedJob = DB::select($sqlRelated);
				DB::update('update post_jobs set view = view + 1 where id = ?', [$id]);
				
				return view('page.content.job_detail', compact('detailJob', 'listRelatedJob'));
			}else{
				return redirect('admin/quan-ly-cong-viec/danh-sach');
			}
		}
	}

	/*Edit Nhanh*/
	public function action(Request $request)
	{
		if ($request->action == 'edit') 
		{
			$job = \App\PostJob::find($request->id);
			if ($job) {
				$job->active = $request->active;
				$job->type_job = $request->type_job;
				$job->user_active = Auth::user()->id;
				$job->time_active = \Carbon\Carbon::now();
				if($job->save()){
					$response = array(
					  'code' => 'success'
					);
				}else{
					$response = array(
					  'code' => 'fail'
					);
				}
			}
		}
		echo json_encode($response);
	}
}

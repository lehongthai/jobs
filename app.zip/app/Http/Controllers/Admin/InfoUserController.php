<?php 
namespace App\Http\Controllers\Admin;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\InfoUser;
use DB;
class InfoUserController extends \App\Http\Controllers\Controller {

	public function getListLevel()
	{
		$check = 'level';
		$data = InfoUser::where('alias', 'level')->get();
		$title = "Bằng cấp hiện tại";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}
	public function getListEmpirical()
	{
		$check = 'empirical';
		$data = InfoUser::where('alias', 'empirical')->get();
		$title = "Kinh nghiệm";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}
	public function getListDiploma()
	{
		$check = 'diploma';
		$data = InfoUser::where('alias', 'diploma')->get();
		$title = "Chức vụ hiện tại";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}
	public function getListDiploma_wish()
	{
		$check = 'diploma_wish';
		$data = InfoUser::where('alias', 'diploma_wish')->get();
		$title = "Chức vụ mong muốn";
		return view('admin.infouser.list', compact('data', 'check'));
	}
	public function getListExigency()
	{
		$check = 'exigency';
		$data = InfoUser::where('alias', 'exigency')->get();
		$title = "Nhu cầu tìm việc";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}
	public function getListType()
	{
		$check = 'type';
		$data = DB::select('select * from type');
		$title = "Loại hình việc làm";
		return view('admin.infouser.type', compact('data', 'check', 'title'));
	}

	public function getListProbationTime()
	{
		$check = 'probation_time';
		$data = InfoUser::where('alias', 'probation_time')->get();
		$title = "Thời gian thử việc";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}

	public function getListAttribute()
	{
		$check = 'attribute';
		$data = InfoUser::where('alias', 'attribute')->get();
		$title = "Tính chất công việc";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}

	public function getListLoaiTn()
	{
		$check = 'loai_tn';
		$data = InfoUser::where('alias', 'loai_tn')->get();
		$title = "Loại tốt nghiệp";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}

	public function getListLanguage()
	{
		$check = 'language';
		$data = InfoUser::where('alias', 'language')->get();
		$title = "Ngôn ngữ";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}

	public function getListLanguageLevel()
	{
		$check = 'language_level';
		$data = InfoUser::where('alias', 'language_level')->get();
		$title = "Trình độ ngôn ngữ";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}

	public function getListQuyMo()
	{
		$check = 'quy_mo';
		$data = InfoUser::where('alias', 'quy_mo')->get();
		$title = "Quy mô công ty";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}

	public function getListWage()
	{
		$check = 'wage';
		$data = InfoUser::where('alias', 'wage')->get();
		$title = "Mức lương làm việc";
		return view('admin.infouser.list', compact('data', 'check', 'title'));
	}

	public function getAdd()
	{
		return view('admin.infouser.add');
	}

	public function postAdd(Request $PostRequest)
	{		
		$this->validate($PostRequest, 
								[
								'txtName' => "required|unique:infocv_user,name",
								],
								[
								'txtName.required' => 'Vui lòng nhập tên',
								'txtName.unique' => 'Tên đã tồn tại'
								]
			);

		$info = new InfoUser;
		$info->name = $PostRequest->txtName;
		$info->orders = $PostRequest->txtOrder;
		$info->alias = $PostRequest->alias;


		if($info->save()){
			return redirect('admin/info/list/'.$PostRequest->alias);
		}
	}

	
	public function getEdit($id=0)
	{
		$info = InfoUser::find($id);
		if (isset($info) && $info != null && isset($info)) {
			$data = $info->toArray();
			return view('admin.infouser.edit', compact('data'));
		}
		return redirect()->route('admin.infouser.listlevel');
	}
	public function postEdit(Request $request)
	{

		$id = $request->id;
		$this->validate($request, 
								[
								'txtName' => "required|unique:infocv_user,name,$id",
								],
								[
								'txtName.required' => 'Vui lòng nhập tên',
								'txtName.unique' => 'Tên đã tồn tại'
								]
			);
		
		$info = InfoUser::find($id);
		if ($info) {
			$info->name = $request->txtName;
			$info->orders = $request->txtOrder;
			$info->alias = $request->alias;
			if($info->save()){
				return redirect('admin/info/list/'. $info->alias);
			}
		}
		
	}

	public function getDelete($id=0)
	{
		$info = InfoUser::find($id);
		if (isset($info) && $info && $info != null) {
			if ($info->delete()) {
				return redirect('admin/info/list/' . $info->alias);
			}
		}else{
			return redirect()->back();
		}
		
	}

	public function getDeleteType($id=0)
	{
		$info = DB::select('select count(*) as total from type where id = ?', [$id]);

		if (isset($info) && $info && $info != null) {
			DB::delete('delete from type where id = ?', [$id]);
			return redirect('admin/info/type/');
		}else{
			return redirect()->back();
		}
		
	}

	/*Edit Nhanh*/
	public function action(Request $request)
	{
		if ($request->action == 'edit') 
		{
			$info = InfoUser::find($request->id);
			if ($info) {
				$info->orders = $request->orders;
				if($info->save()){
					$response = array(
					  'code' => 'success',
					  'alias' => $info->alias
					);
				}else{
					$response = array(
					  'code' => 'fail',
					  'alias' => $info->alias
					);
				}
			}
		}
		echo json_encode($response);
	}

}

<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use DB, Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class DuyetHoSoController extends Controller
{
    public function getListResume()
    {
    	$listResume = DB::select('select id, title, create_date, duyet, user_id, alias from cv_user');
    	$title = "Danh sách hồ sơ";
    	return view('admin.hoso.list', compact('listResume', 'title'));
    }

    public function viewResume($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return redirect('admin/quan-ly-ho-so/danh-sach');
		}else{
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id = $id_arr[count($id_arr) - 1];

			$infoResume = \App\CvUser::where('id', $id)->first();
			if ($infoResume) {
				$infoCandidate = DB::select('select * from users where id = ?', [$infoResume->user_id])[0];
				$infoDetailResume = DB::select('select * from detail_cv where candidate_id = ?', [$infoResume->user_id])[0];
				$infoDetailResumeDiploma = DB::select('select * from detail_cv_diploma where candidate_id = ?', [$infoResume->user_id])[0];
				DB::update('update cv_user set view = view + 1 where id = ?', [$id]);
				return view('page.content.resume_detail', compact('infoResume', 'infoCandidate', 'infoDetailResume', 'infoDetailResumeDiploma'));
			}else{
				return redirect('admin/quan-ly-ho-so/danh-sach');
			}
			
		}
	}

	/*Edit Nhanh*/
	public function action(Request $request)
	{
		if ($request->action == 'edit') 
		{
			$cv = \App\CvUser::find($request->id);
			if ($cv) {
				$cv->duyet = $request->duyet;
				$cv->user_duyet = Auth::user()->id;
				$cv->time_duyet = \Carbon\Carbon::now();
				if($cv->save()){
					$response = array(
					  'code' => 'success'
					);
				}else{
					$response = array(
					  'code' => 'fail'
					);
				}
			}
		}
		echo json_encode($response);
	}
}

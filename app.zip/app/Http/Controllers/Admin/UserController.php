<?php 
namespace App\Http\Controllers\Admin;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\User;
use Auth, DB;

class UserController extends Controller {

	public function getListEmployer()
	{
		$listUser = User::select('users.id', 'users.active', 'users.banded', 'users.created_at', 'users.email', 'company.id AS cId', 'company.name', 'company.alias')->join('company', 'company.user_id', '=', 'users.id')->where('users.level', 2)->get();

		$url = 'nha-tuyen-dung';
		$title = 'Nhà tuyển dụng';
		return view('admin.user.list', compact('listUser', 'title', 'url'));
	}

	public function getListCandidate()
	{
		$listUser = User::select('id', 'active', 'banded', 'created_at', 'email', 'fullname')->where('level', 1)->get();
		$url = 'ung-vien';
		$title = 'Ứng viên';
		return view('admin.user.list', compact('listUser', 'title', 'url'));
	}

	public function action(Request $request)
	{
		if ($request->action == 'edit') 
		{
			$user = User::find($request->id);
			if ($user) {
				$user->banded = $request->banded;
				$user->user_banded = Auth::user()->id;
				$user->time_banded = \Carbon\Carbon::now();
				if($user->save()){
					$response = array(
					  'code' => 'success'
					);
				}else{
					$response = array(
					  'code' => 'fail'
					);
				}
			}
		}
		echo json_encode($response);
	}
	public function getViewUser($alias='')
	{
		if ($alias == null || !$alias || stristr($alias, '.html') != '.html') {
			return redirect('admin/quan-ly-thanh-vien/nha-tuyen-dung');
		}else{
			$id_arr = explode('-', explode('.', $alias)[0]);
			$id = $id_arr[count($id_arr) - 1];
			$sqlEmployer = "SELECT u.email AS uEmail, u.id AS uId, c.*  
									FROM users AS u 
									LEFT JOIN company AS c 
										ON u.id = c.user_id 
									WHERE u.level = 2 
									AND c.id = $id";
			$infoEmployer = DB::select($sqlEmployer);
			if ($infoEmployer && !empty($infoEmployer)) {
				$infoEmployer = $infoEmployer[0];
				$title = "Thông tin nhà tuyển dụng";
				return view('admin.user.employer', compact('infoEmployer', 'title'));
			}else{
				return redirect('admin/quan-ly-thanh-vien/nha-tuyen-dung');
			}

		}
	}

	public function active($id='')
	{
		if ($id == null || !is_numeric($id)) {
			return redirect('quan-ly-thanh-vien/nha-tuyen-dung');
		}else{
			$company = \App\Company::find($id);
			$message = ['level' => 'danger', 'flash_message' => 'Kích hoạt không thành công'];
			if ($company) {
				$company->active = 1;
				if ($company->save()) {
					$message = ['level' => 'success', 'flash_message' => 'Kích hoạt thành công'];
				}else{
					$message = ['level' => 'danger', 'flash_message' => 'Kích hoạt không thành công'];
				}
			}
			return redirect()->back()->with($message);
		}
	}

	public function deActive($id='')
	{
		if ($id == null || !is_numeric($id)) {
			return redirect('quan-ly-thanh-vien/nha-tuyen-dung');
		}else{
			$company = \App\Company::find($id);
			$message = ['level' => 'danger', 'flash_message' => 'Kích hoạt không thành công'];
			if ($company) {
				$company->active = md5(uniqid());
				if ($company->save()) {
					$message = ['level' => 'success', 'flash_message' => 'Bỏ kích hoạt thành công'];
				}else{
					$message = ['level' => 'danger', 'flash_message' => 'Bỏ kích hoạt không thành công'];
				}
			}
			return redirect()->back()->with($message);
		}
	}
}

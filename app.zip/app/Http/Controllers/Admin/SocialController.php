<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use Socialite;
use App\User, App\Socials, App\Common, App\Company, App\AdditionalCompany;

use Auth, Mail, Hash, File;
use App\Http\Controllers\Controller;

class SocialController extends Controller
{
    public function getLogin()
    {
        return view('page.content.login');
    }

    public function redirectFacebookToProvider()
    {
    	return Socialite::driver('facebook')->redirect();
    }

    public function handleFacebookProviderCallback()
    {
    	$user = Socialite::driver('facebook')->user();
    	
    	$socials = Socials::where('social_id', $user->id)->where('provider', 'facebook')->first();
    	if ($socials) {
    		$u = User::where('email', $user->email)->first();
    		Auth::login($u);
    		return redirect('/');
    	}else{
    		$facebook = new Socials;
    		$facebook->social_id = $user->id;
    		$facebook->_token = $user->_token;
    		$facebook->provider = 'facebook';
    		$facebook->avatar = $user->avatar;
    		$facebook->create_at = Carbon\Carbon::now();

    		$u = User::where('email', $user->email)->first();
    		if (!$u) {
    			$u = User::create([
    								'fullname' => $user->name,
    								'email' => $user->email,
    								'level' => 1,
    								'active' => 1
    								]);
    		}

    		$facebook->user_id = $u->id;
    		$facebook->save();
    		Auth::login($u);
    		return redirect('/');

    	}
    }

    public function redirectGoogleToProvider()
    {
    	return Socialite::driver('google')->redirect();
    }

    public function handleGoogleProviderCallback()
    {
    	$user = Socialite::driver('google')->user();
    	
    	$socials = Socials::where('social_id', $user->id)->where('provider', 'google')->first();
    	if ($socials) {
    		$u = User::where('email', $user->email)->first();
    		Auth::login($u);
    		return redirect('/');
    	}else{
    		$google = new Socials;
    		$google->social_id = $user->id;
    		$google->_token = $user->_token;
    		$google->provider = 'google';
    		$google->avatar = $user->avatar;
    		$google->create_at = Carbon\Carbon::now();

    		$u = User::where('email', $user->email)->first();
    		if (!$u) {
    			$u = User::create([
    								'fullname' => $user->name,
    								'email' => $user->email,
    								'level' => 1,
    								'active' => 1
    								]);
    		}

    		$google->user_id = $u->id;
    		$google->save();
    		Auth::login($u);
    		return redirect('/');

    	}
    }

    public function postRegister(Request $request)
    {
    	$this->validate($request,
    		[
    		'fullname' 				=> 'required',
			'passwordRegister' 		=> 'required|min:6',
			'password_confirm'      => 'same:passwordRegister',
			'email' 				=> 'required|E-Mail|unique:users,email',
            'phone'                 => 'required|numeric',
            'birthday'              => 'date|before:today',
            'sex'                   => 'in:1,2',
            'provin'                => 'exists:provins,id',
			],
			[
			'fullname.required' 	=> 'Tên không được để trống',
			'email.unique' 			=> 'Email đã được sử dụng',
			'phone.numeric' 		=> 'Số điện thoại phải là số',
			'phone.required' 	    => 'Số điện thoại không được để trống',
			'passwordRegister.required' 	=> 'Mật Khẩu không được để trống',
			'passwordRegister.min' 			=> 'Mật Khẩu ít nhất 6 ký tự',
			'password_confirmation.same' 	=> 'Nhập lại Mật Khẩu không đúng',
			'email.required'		=> 'Email không được để trống',
			'email.e_mail' 			=> 'Email không đúng định dạng',
            'birthday.date'         => 'Ngày sinh không đúng định dạng',
            'provin.exists'         => 'Tỉnh / Thành phố không tồn tại',
            'sex.in'                => 'Giới tính chỉ được là nam hoặc nữ',
            'birthday.before'       => 'Ngày sinh phải bé hơn ngày hiện tại',  
			]);


    	$user = new User;
		$user->fullname			= $request->fullname;
		$user->address			= $request->address;
		$user->email			= $request->email;
        $user->sex              = $request->sex;
        $user->birthday          = $request->birthday;
        $user->phone            = $request->phone;
        $user->provin            = $request->provin;
		$user->password			= bcrypt($request->passwordRegister);
		$user->level			= 1;
		$user->remember_token 	= $request->_token;
		$user->active = md5(uniqid());
        $user->banded = md5(uniqid());

		if($user->save()){
			$id = $user->id;
			$data = array('id'=>$id , 'userMail' => $user->email);
            Mail::send('emails.active', $data, function ($message) use ($user)  {
                $message->from('teamchich26@gmail.com', 'Xác nhận tài khoản');
                $message->to($user->email)->subject('Xác nhận tài khoản');
            });

			$message = ['level' => 'success', 'flash_message' => 'Tạo thành công thành viên '];
		}else{
			$message = ['level' => 'danger', 'flash_message' => 'Tạo không thành công thành viên'];
		}

		return redirect('/')->with($message);
    }

    public function getConfirmUser($id)
	{
		$user = User::find($id);
        if ($user) {
            $user->active = 1;
            $user->banded = 1;
            if ($user->save()) {
                echo "<script>
		            alert('Xác nhận tài khoản thành công, Cảm ơn bạn đã đăng ký tài khoản !!');
		            window.location = '".url('/')."'
		        </script>";
		            }
        }else{
             echo "<script>
		            alert('Xác nhận tài khoản không thành công, Xin lỗi vì sự cố này !!');
		            window.location = '".url('/')."'
		        </script>";
		}
       
    }

    public function getRegister()
    {
        $listProvin = Common::getProvin();
        $listQuyMo = Common::getQuyMo();
        return view('page.content.register', compact('listProvin', 'listQuyMo'));
    }

    public function postEditProfile(Request $request)
    {
        $id = Auth::user()->id;
        $this->validate($request,
            [
            'fullname'              => 'required',
            'old_password'          => 'required',
            'email'                 => "required|E-Mail|unique:users,email,$id",
            'phone'                 => 'required|numeric',
            'birthday'              => 'date|before:today',
            'sex'                   => 'in:1,2',
            'provinUser'                => 'exists:provins,id',
            ],
            [
            'fullname.required'     => 'Tên không được để trống',
            'email.unique'          => 'Email đã được sử dụng',
            'phone.numeric'         => 'Số điện thoại phải là số',
            'phone.required'        => 'Số điện thoại không được để trống',
            'old_password.required'     => 'Mật Khẩu không được để trống',
            'email.required'        => 'Email không được để trống',
            'email.e_mail'          => 'Email không đúng định dạng',
            'birthday.date'         => 'Ngày sinh không đúng định dạng',
            'provinUser.exists'         => 'Tỉnh / Thành phố không tồn tại',
            'sex.in'                => 'Giới tính chỉ được là nam hoặc nữ',
            'birthday.before'       => 'Ngày sinh phải bé hơn ngày hiện tại',  
            ]);

        if (!Hash::check($request->old_password, Auth::user()->password)) {
            echo "<script>
                    alert('Xác nhận sai mật khẩu !!');
                    window.location = '".url('ung-vien/ho-so-ca-nhan')."'
                </script>";
        }else{
            $user = User::find($id);
            $user->fullname         = $request->fullname;
            $user->address          = $request->address;
            $user->email            = $request->email;
            $user->sex              = $request->sex;
            $user->birthday          = $request->birthday;
            $user->phone            = $request->phone;
            $user->provin            = $request->provinUser;
            $user->remember_token   = $request->_token;

            if($user->save()){

                $message = ['level' => 'success', 'flash_message' => 'Cập nhật thành công thành viên <b>'.$request->name.'</b>'];
            }else{
                $message = ['level' => 'danger', 'flash_message' => 'Cập nhật không thành công thành viên <b>'.$request->name.'</b>'];
            }
            return redirect('ung-vien/'. $request->returnUrl);
        }

        
    }

    public function changeImageAvatar(Request $request)
    {
        if ($request->hasFile('imageAvatar')) {
            $file = $request->file('imageAvatar');
            $fileDuoi = $file->getClientOriginalExtension();

            if ($fileDuoi != 'jpg' && $fileDuoi != 'jpeg' && $fileDuoi != 'png') {
                echo "<script>
                    alert('Xác nhận sai định dạng file !!');

                    window.location = '".url('ung-vien/ho-so-ca-nhan')."'
                </script>";
            }else{
                $fileNameOld = $file->getClientOriginalName();
                $fileNameNew = md5(uniqid()) . '_' . $fileNameOld;
                $path = url('public/upload/avatar/');
                $file->move('public/upload/avatar/' , $fileNameNew);
                $user = User::find(Auth::user()->id);
                
                if (File::exists('public/upload/avatar/' . $user->avatar) && $user->avatar != 'avatar.png') {
                    File::delete('public/upload/avatar/' . $user->avatar);
                }

                $user->avatar = $fileNameNew;
                if ($user->save()) {
                    return redirect('ung-vien/'. $request->returnUrl);
                }
                
            }
            
        }
    }

    public function postRegisterEmployer(Request $request)
    {
       $this->validate($request,
                        [
                        'emailEmployer' => "required|E-Mail|unique:users,email,1,level",
                        'passwordEmployer'      => 'required|min:6',
                        'passwordEmployerConfirm'      => 'same:passwordEmployer',
                        'companyPhone'                 => 'required|numeric',
                        'companyProvin'                => 'required|exists:provins,id',
                        'companyQuyMo'      => 'required|exists:infocv_user,id,alias,quy_mo',
                        'companyIntro'      => 'required',
                        'companyName'      => 'required',
                        'companyAddress'      => 'required',
                        'addName' => "required",
                        'addEmail'      => 'required|E-Mail',
                        'addPhone'      => 'required|numeric',
                        'imageLogo' => 'max:2048',
                        ],
                        [
                        'emailEmployer.required'     => 'Đại chỉ Email không được để trống',
                        'emailEmployer.unique'          => 'Email đã được sử dụng',
                        'emailEmployer.e_mail'      => 'Vui lòng nhập đúng định dạng email',
                        'passwordEmployer.required' => 'Vui lòng nhập Mật Khẩu',
                        'passwordEmployer.min' => 'Mật Khẩu ít nhất là 6 ký tự',
                        'passwordEmployerConfirm.same' => 'Nhập lại mật khẩu không đúng',
                        'companyPhone.required' => 'Vui lòng nhập số điện thoại công ty',
                        'companyPhone.numeric' => 'Số điện thoại công ty phải là số',
                        'companyQuyMo.required' => 'Vui lòng nhập quy mô công ty',
                        'companyQuyMo.exists' => 'Quy mô công ty không đúng',
                        'companyIntro.required' => 'Vui lòng nhập sơ lượt công ty',
                        'companyName.required' => 'Vui lòng nhập tên công ty',
                        'companyAddress.required' => 'Vui lòng nhập địa công ty',
                        'companyProvin.exists' => 'Vui lòng nhập Tỉnh / Thành phố',
                        'companyProvin.required' => 'Tỉnh / Thành phố không tồn tại',
                        'addName.required' => 'Vui lòng nhập tên thông tin người liên hệ',
                        'addEmail.required' => 'Vui lòng nhập địa chỉ email người liên hệ',
                        'addPhone.required' => 'Vui lòng nhập số điện thoại người liên hệ',
                        'addEmail.e_mail' => 'Vui lòng nhập đúng định dạng email',
                        'addPhone.numeric' => 'Số điện thoại người liên hệ phải là số',
                        ]); 

        $employer = new User();
        $company = new Company();
        $addCompany = new AdditionalCompany();

        $employer->phone            = $request->companyPhone;
        $employer->email            = $request->emailEmployer;
        $employer->provin           = $request->companyProvin;
        $employer->password         = bcrypt($request->passwordEmployer);
        $employer->level            = 2;
        $employer->fullname         = $request->companyName;
        $employer->remember_token   = $request->_token;
        $employer->active = md5(uniqid());
        $employer->banded = md5(uniqid());

        if($employer->save()){
            $id_employer = $employer->id;
        }else{
            echo "<script>
                    alert('Đăng ký không hợp lệ !');
                    window.location = '".url('/')."'
                </script>";
        }

        $company->user_id = $id_employer;
        $company->name = $request->companyName;
        $company->alias = convert_vi_to_en($request->companyName);
        $company->address = $request->companyAddress;
        $company->phone = $request->companyPhone;
        $company->provin = $request->companyProvin;
        $company->quy_mo = $request->companyQuyMo;
        $company->so_luot = $request->companyIntro;
        $company->fax = $request->companyFax;
        $company->website = $request->companyWebsite;
        $company->status = 2;
        $company->count_job = 0;
        $company->create_date = \Carbon\Carbon::now();

        if ($request->hasFile('imageLogo')) {
            $file = $request->file('imageLogo');
            $fileNameOld = $file->getClientOriginalName();
            $fileNameNew = md5(uniqid()) . '_' . $fileNameOld;
            $path = url('public/upload/company/');
            $file->move('public/upload/company/' , $fileNameNew);
            $company->logo = $fileNameNew;
        }
        
       $company->active = md5(uniqid());

        $addCompany->user_id = $id_employer;
        $addCompany->name = $request->addName;
        $addCompany->phone = $request->addPhone;
        $addCompany->email = $request->addEmail;

        if ($company->save() && $addCompany->save()) {
            $message = ['level' => 'success', 'flash_message' => 'Tạo thành công thành nhà tuyển dụng'];
            $data = array('id'=>$id_employer , 'userMail' => $employer->email);
            Mail::send('emails.active', $data, function ($message) use ($employer)  {
                $message->from('teamchich26@gmail.com', 'Xác nhận tài khoản');
                $message->to($employer->email)->subject('Xác nhận tài khoản');
            });
        }else{
            $employer->delete();
            $message = ['level' => 'danger', 'flash_message' => 'Tạo không thành công nhà tuyển dụng'];
        }

        return redirect('/')->with($message);

    }

    public function getForgotPass()
    {
        return view('page.content.forgotPass');
    }
    public function postForgotPass(Request $request)
    {
        $this->validate($request,
            ['email' => 'required|E-Mail|exists:users,email'],
            [
            'email.required' => 'Vui lòng nhập địa chỉ mail',
            'email.e_mail'  => 'Địa chỉ mail không hợp lệ',
            'email.exists'  => 'Bạn chưa đăng ký tài khoản với email này'
            ]);
        $pass = substr(md5(uniqid()), 3, 6);
        
        $user = User::where('email', $request->email)->first();
        $user->password = bcrypt($pass);

        if($user->save()){
            $data = array('pass' => $pass, 'email' => $request->email);
            Mail::send('emails.forgotPass', $data, function ($message) use ($user)  {
                $message->from('teamchich26@gmail.com', 'Lấy lại mật khẩu');
                $message->to($user->email)->subject('Lấy lại mật khẩu');
            });
            $message = '';
            $message = ['level' => 'success', 'flash_message' => 'Vui lòng kiểm tra mail để lấy mật khẩu'];
        }else{
            $message = ['level' => 'danger', 'flash_message' => 'Không thể lấy lại mật khẩu, vui lòng thử lại'];
        }
        
        return redirect()->back()->with($message);

    }

}

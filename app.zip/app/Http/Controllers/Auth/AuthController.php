<?php

namespace App\Http\Controllers\Auth;

use App\User;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use App\Http\Requests\LoginRequest;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware($this->guestMiddleware(), ['except' => 'logout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|min:6|confirmed',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }

    public function postLogin(LoginRequest $loginRequest)
    {
        $dataAdmin = [
            'email' => $loginRequest->usernameLogin,
            'password' => $loginRequest->passwordLogin,
            'level' => 3,
        ];

        $dataCandidate = [
            'email' => $loginRequest->usernameLogin,
            'password' => $loginRequest->passwordLogin,
            'level' => 1,
        ];

        $dataEmployer = [
            'email' => $loginRequest->usernameLogin,
            'password' => $loginRequest->passwordLogin,
            'level' => 2,
        ];

        if (Auth::attempt($dataAdmin)) {
            if (Auth::user()->active != 1) {
                Auth::logout();
                $message = ['level' => 'danger', 'flash_message' => 'Bạn chưa đăng nhập, vui lòng đăng nhập'];
                return redirect()->back()->with($message);
            }elseif(Auth::user()->banded != 1){
                Auth::logout();
                $message = ['level' => 'danger', 'flash_message' => 'Tài khoản đã bị cấm hoạt động'];
            return redirect()->back()->with($message);
            }else{
                return redirect()->route('admin.post.list');
            }
        }elseif(Auth::attempt($dataCandidate)){
            if (Auth::user()->active != 1) {
                Auth::logout();
                $message = ['level' => 'danger', 'flash_message' => 'Bạn chưa đăng nhập, vui lòng đăng nhập'];
                return redirect()->back()->with($message);
            }elseif(Auth::user()->banded != 1){
                Auth::logout();
                $message = ['level' => 'danger', 'flash_message' => 'Tài khoản đã bị cấm hoạt động'];
                return redirect()->back()->with($message);
            }else{
                return redirect('ung-vien/tai-khoan');
            }
        }elseif(Auth::attempt($dataEmployer)){
            if (Auth::user()->active != 1) {
                Auth::logout();
                $message = ['level' => 'danger', 'flash_message' => 'Bạn chưa đăng nhập, vui lòng đăng nhập'];
                return redirect()->back()->with($message);
            }elseif(Auth::user()->banded != 1){
                Auth::logout();
                $message = ['level' => 'danger', 'flash_message' => 'Tài khoản đã bị cấm hoạt động'];
                return redirect()->back()->with($message);
            }else{
                return redirect('nha-tuyen-dung/tai-khoan');
            }
        }else{
             $message = ['level' => 'danger', 'flash_message' => 'Tài khoản không đúng'];
            return redirect()->back()->with($message);
        }
    }

    
}

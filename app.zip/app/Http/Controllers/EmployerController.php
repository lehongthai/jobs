<?php 
namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use \App\Candidate\Check;
use Illuminate\Http\Request;
use App\Common, App\CvUser, App\PostJob;
use Auth, Mail, DB, File, Hash;

class EmployerController extends Controller {
	
	public function getPostJob()
	{
		if (Check::checkCompanyActive(Auth::user()->id)) {
			$listJob = Common::getJob();
			$listProvin = Common::getProvin();
			$listLevel = Common::getLevel();
			$listEmpirical = Common::getEmpirical();
			$listDiploma = Common::getDiploma();
			$listExigency = Common::getExigency();
			$listType = Common::getType();
			$listProbationTime = Common::getProbationTime();
			$listWage = Common::getWage();
			$listAttribute = Common::Attribute();
			$title = 'Đăng tin tuyển dụng';
			return view('page.content.employer.post_job', compact('listJob','listProvin','listLevel','listEmpirical','listDiploma','listExigency','listType','listProbationTime','listWage','listAttribute', 'title'));
		}else{
			$message = ['level' => 'danger', 'flash_message' => 'Không thể đăng việc vì chưa kích hoạt công ty, vui lòng đợi ban quản trị xem xét'];
            return redirect()->back()->with($message);
		}
		
	}

	public function postJob(Request $request)
	{
		$this->validate($request,
						[
						'title' 	=> 'required',
						'wage' 			=> 'required|exists:infocv_user,id,alias,wage',
		 				'level' 		=> 'required|exists:infocv_user,id,alias,level',
		 				'empirical' 	=> 'required|exists:infocv_user,id,alias,empirical',
		 				'job' 			=> 'required|exists:jobs,id',
		 				'type' 			=> 'required|exists:type,id',
		 				'provin' 		=> 'required|exists:provins,id',
		 				'quanlity'		=> 'numeric',
		 				'description'	=> 'required',
		 				'attribute'		=> 'required|exists:infocv_user,id,alias,attribute',
		 				'min_kickback'	=> 'numeric',
		 				'max_kickback'	=> 'numeric',
		 				'probation_time'=> 'required|exists:infocv_user,id,alias,probation_time',
		 				'expired_at'	=> 'required|date|after:today',
		 				'status'	=> 'required|in:1,2',
		 				'sex' 	=> 'in:1,2'
						],
						[
						'title.required' 	=> 'Vui lòng nhập tên công việc',
						'wage.required' 	=> 'Vui lòng nhập mức lương',
						'level.required' 	=> 'Vui lòng nhập cấp bậc',
						'empirical.required' 	=> 'Vui lòng nhập kinh nghiệm',
						'job.required' 	=> 'Vui lòng nhập loại công việc',
						'type.required' 	=> 'Vui lòng nhập kiểu công việc',
						'provin.required' 	=> 'Vui lòng nhập nơi làm việc',
						'description.required' 	=> 'Vui lòng nhập mô tả công việc',
						'attribute.required' 	=> 'Vui lòng nhập tính chất công việc',
						'probation_time.required' 	=> 'Vui lòng nhập thời gian thử việc',
						'expired_at.required' 	=> 'Vui lòng nhập ngày hết hạn',
						'status.required' 	=> 'Vui lòng nhập trạng thái đăng việc',
						'level.exists' 	=> 'Cấp bậc không tồn tại',
						'empirical.exists' 	=> 'Kinh nghiệm không tồn tại',
						'job.exists' 	=> 'Loại công việc không tồn tại',
						'type.exists' 	=> 'Kiểu công việc không tồn tại',
						'wage.exists' 	=> 'Mức lương không tồn tại',
						'provin.exists' 	=> 'Nơi làm việc không tồn tại',
						'probation_time.exists' 	=> 'Thời gian thử việc không tồn tại',
						'attribute.exists' 	=> 'Tính chất không tồn tại',
						'max_kickback.numeric' 	=> ' phải là số',
						'min_kickback.numeric' 	=> ' phải là số',
						'quanlity.numeric' 	=> 'Số lượng phải là số',
						'sex.in' 	=> 'Giới tính không hợp lệ',
						'status.in' 	=> ' không đúng',
						'expired_at.date' 	=> 'Ngày hết hạn không hợp lệ',
						'expired_at.after' 	=> 'Ngày hết hạn không hợp lệ',
						]);


		$job = new PostJob;
		$job->title = $request->title;
		$job->quanlity = $request->quanlity;
		if (isset($request->job) && $request->job != NULL) {
			$fields = implode(',', $request->job);
			$job->fields = replaceArrayInsert($request->job);
			DB::update("UPDATE jobs set count_employer = count_employer + 1 where id in ($fields)");
		}
		if (isset($request->provin) && $request->provin != NULL) {
			$provins = implode(',', $request->provin);
			$job->provin = replaceArrayInsert($request->provin);
			DB::update("UPDATE provins set count_employer = count_employer + 1 where id in ($provins)");
		}

		$job->description = $request->description;
		$job->sex = $request->sex;
		$job->alias = convert_vi_to_en($request->title);
		$job->require = $request->require;
		$job->attribute = $request->attribute;
		$job->level = $request->level;
		$job->empirical = $request->empirical;
		$job->wage = $request->wage;
		$job->min_kickback = $request->min_kickback;
		$job->max_kickback = $request->max_kickback;
		$job->type = $request->type;
		$job->probation_time = $request->probation_time;
		$job->benefit = $request->benefit;
		$job->status = $request->status;
		$job->expired_at = $request->expired_at;
		$job->create_date = \Carbon\Carbon::now();
		$job->employer_id = Common::getCompanyIdByUserId(Auth::user()->id);
		$job->active = md5(uniqid());
		$job->view = 0;
		

		if($job->save()){
			DB::update('update company set count_job = count_job + 1 where id = ?', [Common::getCompanyIdByUserId(Auth::user()->id)]);
			DB::update('update company set tuyen_dung = tuyen_dung - 1 where id = ?', [Common::getCompanyIdByUserId(Auth::user()->id)]);
			return redirect('nha-tuyen-dung/quan-ly-tin-tuyen-dung');
		}
	}

	public function getManagerJob()
	{
		$sqlListPostJob = "SELECT 
							pj.id,pj.alias, pj.expired_at, pj.title, pj.view, pj.active, pj.create_date 
									FROM post_jobs AS pj 
										LEFT JOIN company AS c ON c.id = pj.employer_id 
										LEFT JOIN users AS u ON u.id=c.user_id 
									WHERE u.id = " . Auth::user()->id;
		$listPostJob = DB::select($sqlListPostJob);
		return view('page.content.employer.view_post_job', compact('listPostJob'));
	}

	public function deletePostJob($id='')
	{
		if ($id == null || !is_numeric($id)) {
			return redirect()->back();
		}else{
			$postJob = PostJob::find($id);
			$message = '';
			if ($postJob) {
				if ($postJob->delete()) {
					$message = ['level' => 'success', 'flash_message' => 'Xóa thành công'];
				}
			}else{
				$message = ['level' => 'danger', 'flash_message' => 'Không có thông tin'];
			}
			return redirect('nha-tuyen-dung/quan-ly-tin-tuyen-dung')->with($message);
		}
	}

	public function getInfoEmployer()
	{
		$id_employer = Auth::user()->id;
		$infoEmployer = DB::select('select email from users where id = ?', [$id_employer])[0];
		$infoCompany = DB::select('select * from company where user_id = ?', [$id_employer])[0];
		$infoAddCompany = DB::select('select * from additional_company where user_id = ?', [$id_employer])[0];
		$listProvin = Common::getProvin();
        $listQuyMo = Common::getQuyMo();

        $title = 'Tài khoản';
        return view('page.content.employer.infoEmployer', compact('title', 'infoEmployer', 'infoCompany', 'listProvin', 'listQuyMo', 'infoAddCompany'));
	}

	public function postInfoEmployer(Request $request)
	{
		$this->validate($request,
                        [
                        'companyPhone'                 => 'required|numeric',
                        'companyProvin'                => 'required|exists:provins,id',
                        'companyQuyMo'      => 'required|exists:infocv_user,id,alias,quy_mo',
                        'companyIntro'      => 'required',
                        'companyAddress'      => 'required',
                        'addName' => "required",
                        'addEmail'      => 'required|E-Mail',
                        'addPhone'      => 'required|numeric',
                        'imageLogo' => 'max:2048',
                        ],
                        [
                        'companyPhone.required' => 'Vui lòng nhập số điện thoại công ty',
                        'companyPhone.numeric' => 'Số điện thoại công ty phải là số',
                        'companyQuyMo.required' => 'Vui lòng nhập quy mô công ty',
                        'companyQuyMo.exists' => 'Quy mô công ty không đúng',
                        'companyIntro.required' => 'Vui lòng nhập sơ lượt công ty',
                        'companyAddress.required' => 'Vui lòng nhập địa công ty',
                        'companyProvin.exists' => 'Vui lòng nhập Tỉnh / Thành phố',
                        'companyProvin.required' => 'Tỉnh / Thành phố không tồn tại',
                        'addName.required' => 'Vui lòng nhập tên thông tin người liên hệ',
                        'addEmail.required' => 'Vui lòng nhập địa chỉ email người liên hệ',
                        'addPhone.required' => 'Vui lòng nhập số điện thoại người liên hệ',
                        'addEmail.e_mail' => 'Vui lòng nhập đúng định dạng email',
                        'addPhone.numeric' => 'Số điện thoại người liên hệ phải là số',
                        ]); 

        
        $company = \App\Company::where('user_id', Auth::user()->id)->first();
        $addCompany = \App\AdditionalCompany::where('user_id', Auth::user()->id)->first();

        $company->address = $request->companyAddress;
        $company->phone = $request->companyPhone;
        $company->provin = $request->companyProvin;
        $company->quy_mo = $request->companyQuyMo;
        $company->so_luot = $request->companyIntro;
        $company->fax = $request->companyFax;
        $company->website = $request->companyWebsite;

        if ($request->hasFile('imageLogo')) {
            $file = $request->file('imageLogo');
            $fileNameOld = $file->getClientOriginalName();
            $fileNameNew = md5(uniqid()) . '_' . $fileNameOld;
            $path = url('public/upload/company/');
            $file->move('public/upload/company/' , $fileNameNew);
                
           	if (File::exists('public/upload/company/' . $company->logo) && $company->logo != 'logo.png') 
           	{
                File::delete('public/upload/company/' . $company->logo);
            }
            $company->logo = $fileNameNew;
        }

        $addCompany->name = $request->addName;
        $addCompany->phone = $request->addPhone;
        $addCompany->email = $request->addEmail;
        $addCompany->address = $request->addAddress;

        if ($company->save() && $addCompany->save()) {
            $message = ['level' => 'success', 'flash_message' => 'Cập nhật thành công'];
        }else{
            $message = ['level' => 'danger', 'flash_message' => 'Cập nhật thất bại'];
        }
        return redirect()->back();
	}

	public function getChangePass()
	{
		$title = 'Thay đổi mật khẩu';
		return view('page.content.employer.changePass', compact('title'));
	}

	public function postChangePass(Request $request)
	{
		$this->validate($request,
			[
			'passwordOld' => 'required',
			'passwordNew' => 'required|min:6',
			'passwordNewConfirm' => 'required|same:passwordNew'
			],
			[
			'passwordOld.required' => 'Vui lòng nhập mật khẩu',
			'passwordNew.required' => 'Vui lòng nhập mật khẩu thay đổi',
			'passwordNewConfirm.required' => 'Vui lòng xác nhận nhập mật khẩu thay đổi',
			'passwordNew.min' => 'Nhập ít nhất 6 ký tự',
			'passwordNewConfirm.same' => 'Xác nhận mật khẩu không đúng'
			]);

		$message = '';
		if (!Hash::check($request->passwordOld, Auth::user()->password)) {
			$message = ['level' => 'success', 'flash_message_password_error' => 'Mật khẩu không đúng'];
		}else{
			$employer = \App\User::find(Auth::user()->id);
			$employer->password = bcrypt($request->passwordNew);
			if ($employer->save()) {
				$message = ['level' => 'success', 'flash_message' => 'Thay đổi mật khẩu thành công'];
			}else{
				$message = ['level' => 'success', 'flash_message' => 'Thay đổi mật khẩu thất bại'];
			}
		}
		 return redirect()->back()->with($message);
	}

	public function getUpdatePostJob($id='')
	{
		if ($id == null || !is_numeric($id)) {
			return redirect()->back();
		}else{
			$listJob = Common::getJob();
			$listProvin = Common::getProvin();
			$listLevel = Common::getLevel();
			$listEmpirical = Common::getEmpirical();
			$listDiploma = Common::getDiploma();
			$listExigency = Common::getExigency();
			$listType = Common::getType();
			$listProbationTime = Common::getProbationTime();
			$listWage = Common::getWage();
			$listAttribute = Common::Attribute();
			$detailJob = DB::select('SELECT * FROM post_jobs WHERE id = ?', [$id])[0];
			return view('page.content.employer.updatePostJob', compact('listJob','listProvin','listLevel','listEmpirical','listDiploma','listExigency','listType','listProbationTime','listWage','listAttribute', 'detailJob'));
		}
	}

	public function postUpdateJob(Request $request)
	{
		$this->validate($request,
						[
						'title' 	=> 'required',
						'wage' 			=> 'required|exists:infocv_user,id,alias,wage',
		 				'level' 		=> 'required|exists:infocv_user,id,alias,level',
		 				'empirical' 	=> 'required|exists:infocv_user,id,alias,empirical',
		 				'job' 			=> 'required|exists:jobs,id',
		 				'type' 			=> 'required|exists:type,id',
		 				'provin' 		=> 'required|exists:provins,id',
		 				'quanlity'		=> 'numeric',
		 				'description'	=> 'required',
		 				'attribute'		=> 'required|exists:infocv_user,id,alias,attribute',
		 				'min_kickback'	=> 'numeric',
		 				'max_kickback'	=> 'numeric',
		 				'probation_time'=> 'required|exists:infocv_user,id,alias,probation_time',
		 				'expired_at'	=> 'required|date|after:today',
		 				'status'	=> 'required|in:1,2',
		 				'sex' 	=> 'in:1,2'
						],
						[
						'title.required' 	=> 'Vui lòng nhập tên công việc',
						'wage.required' 	=> 'Vui lòng nhập mức lương',
						'level.required' 	=> 'Vui lòng nhập cấp bậc',
						'empirical.required' 	=> 'Vui lòng nhập kinh nghiệm',
						'job.required' 	=> 'Vui lòng nhập loại công việc',
						'type.required' 	=> 'Vui lòng nhập kiểu công việc',
						'provin.required' 	=> 'Vui lòng nhập nơi làm việc',
						'description.required' 	=> 'Vui lòng nhập mô tả công việc',
						'attribute.required' 	=> 'Vui lòng nhập tính chất công việc',
						'probation_time.required' 	=> 'Vui lòng nhập thời gian thử việc',
						'expired_at.required' 	=> 'Vui lòng nhập ngày hết hạn',
						'status.required' 	=> 'Vui lòng nhập trạng thái đăng việc',
						'level.exists' 	=> 'Cấp bậc không tồn tại',
						'empirical.exists' 	=> 'Kinh nghiệm không tồn tại',
						'job.exists' 	=> 'Loại công việc không tồn tại',
						'type.exists' 	=> 'Kiểu công việc không tồn tại',
						'wage.exists' 	=> 'Mức lương không tồn tại',
						'provin.exists' 	=> 'Nơi làm việc không tồn tại',
						'probation_time.exists' 	=> 'Thời gian thử việc không tồn tại',
						'attribute.exists' 	=> 'Tính chất không tồn tại',
						'max_kickback.numeric' 	=> ' phải là số',
						'min_kickback.numeric' 	=> ' phải là số',
						'quanlity.numeric' 	=> 'Số lượng phải là số',
						'sex.in' 	=> 'Giới tính không hợp lệ',
						'status.in' 	=> ' không đúng',
						'expired_at.date' 	=> 'Ngày hết hạn không hợp lệ',
						'expired_at.after' 	=> 'Ngày hết hạn không hợp lệ',
						]);


		$job = PostJob::find($request->id);
		$job->title = $request->title;
		$job->quanlity = $request->quanlity;
		if (isset($request->job) && $request->job != NULL) {
			$job->fields = replaceArrayInsert($request->job);
		}
		if (isset($request->provin) && $request->provin != NULL) {
			$job->provin = replaceArrayInsert($request->provin);
		}

		$job->description = $request->description;
		$job->sex = $request->sex;
		$job->alias = convert_vi_to_en($request->title);
		$job->require = $request->require;
		$job->attribute = $request->attribute;
		$job->level = $request->level;
		$job->empirical = $request->empirical;
		$job->wage = $request->wage;
		$job->min_kickback = $request->min_kickback;
		$job->max_kickback = $request->max_kickback;
		$job->type = $request->type;
		$job->probation_time = $request->probation_time;
		$job->benefit = $request->benefit;
		$job->status = $request->status;
		$job->expired_at = $request->expired_at;
		$job->create_date = \Carbon\Carbon::now();
		
		$message = '';
		if($job->save()){
			$message = ['level' => 'success', 'flash_message' => 'Cập nhật thành công'];
		}else{
			$message = ['level' => 'waining', 'flash_message' => 'Cập nhật thất bại'];
		}
		return redirect('nha-tuyen-dung/quan-ly-tin-tuyen-dung')->with($message);
	}

	public function getSaveResume()
	{
		$id_employer = Auth::user()->id;
		$sqlSaveResume = "SELECT ejc.*, pj.title AS pTitle, pj.id AS pId, pj.alias AS pAlias, cu.title AS cTitle, cu.id AS cId, cu.alias AS cAlias, iu.name AS iName  
									FROM employer_jon_candidate AS ejc 
									LEFT JOIN cv_user AS cu 
										ON ejc.id_candidate = cu.user_id 
									LEFT JOIN post_jobs AS pj 
										ON pj.id = ejc.job 
									LEFT JOIN infocv_user AS iu 
										ON cu.level = iu.id 
									WHERE ejc.employer_id = $id_employer ";
		$listSaveResume = DB::select($sqlSaveResume);
		$title = 'Việc làm đã lưu';
		return view('page.content.employer.saveResume', compact('listSaveResume', 'title'));
	}

	public function deleteSaveResume($id='')
	{
		if ($id == null || !is_numeric($id)) {
			return redirect()->back();
		}else{
			$saveResume = DB::select('select * from employer_jon_candidate where id = ?', [$id]);
			$message = '';
			if ($saveResume) {
				DB::delete('DELETE FROM employer_jon_candidate where id = ?', [$id]);
				$message = ['level' => 'success', 'flash_message' => 'Xóa thành công'];
			}else{
				$message = ['level' => 'danger', 'flash_message' => 'Không có thông tin'];
			}
			return redirect('nha-tuyen-dung/ho-so-da-luu')->with($message);
		}
	}

	public function applyResume($id='')
	{
		if ($id == null || !is_numeric($id)) {
			return redirect()->back();
		}else{
			$check = DB::select("select count(*) as checks from employer_jon_candidate where id_candidate = $id")[0]->checks;
			if ($check == 0) {
				DB::insert("insert into employer_jon_candidate (employer_id, id_candidate, create_date) values (?, ?, ?)", [Auth::user()->id, $id, \Carbon\Carbon::now()]);
				$message = ['level' => 'success', 'flash_message' => 'Lưu hồ sơ thành công'];
			}else{
				$message = ['level' => 'danger', 'flash_message' => 'Hồ sơ đã tồn tại'];
			}
			return redirect('nha-tuyen-dung/ho-so-da-luu')->with($message);
		}
	}
	public function updateSaveResume($id='')
	{
		if ($id == null || !is_numeric($id)) {
			return redirect()->back();
		}else{
			$id_employer = Common::getCompanyIdByUserId(Auth::user()->id);
			$listJob = DB::select("SELECT id, title, alias FROM post_jobs WHERE employer_id = $id_employer");
			$infoSaveResume = DB::select("SELECT * FROM employer_jon_candidate WHERE id = $id")[0];
			$title = "Cập nhật hồ hơ đã lưu";
			return view('page.content.employer.updateSaveResume', compact('infoSaveResume', 'title', 'listJob'));
		}
	}
	public function postUpdateSaveResume(Request $request)
	{
		$id = $request->id;
		$update = \App\Employer\EmployerJoinCandidate::find($id);
		if ($update) {
			$update->da_lien_he = $request->da_lien_he;
			$update->da_phong_van = $request->da_phong_van;
			$update->tu_choi = $request->tu_choi;
			$update->da_test = $request->da_test;
			$update->trung_tuyen = $request->trung_tuyen;
			$update->job = $request->job;
			$update->note = $request->note;
			$update->save();
		}
		return redirect('nha-tuyen-dung/ho-so-da-luu');
	}

	public function getResumeApply()
	{
		$id_employer = Common::getCompanyIdByUserId(Auth::user()->id);
		$sqlApplyJobs = "SELECT cj.id as cjId, pj.title, pj.id AS pId, cj.id AS cjId, cj.create_date AS cCreateDate, cv.id AS cvId, cv.title AS cvTitle, cv.alias AS cvAlias  
									FROM candidate_join_jobs AS cj 
									LEFT JOIN post_jobs AS pj 
												ON cj.jobs_id = pj.id 
									LEFT JOIN cv_user AS cv 
												ON cv.user_id = cj.candidate_id 
									WHERE pj.employer_id = $id_employer   
									AND cj.type = 2";
		$listApplyJobs = DB::select($sqlApplyJobs);
		$title = 'Hồ sơ đã ứng tuyển';
		return view('page.content.employer.viewApplyResume', compact('listApplyJobs', 'title'));
	}

	public function getFindResume()
	{
		$title = 'Tìm kiếm ứng viên';
		return view('page.content.employer.findResume', compact('title'));
	}
}

<?php

	Route::controllers([
		'auth' => 'Auth\AuthController',
		'password' => 'Auth\PasswordController',
	]);
	/*get list post*/
	Route::group(['prefix' => 'admin', 'middleware' => 'auth'], function (){

		/*Quản lý tỉnh, thành phố*/
		Route::group(['prefix' => 'provin'], function () {
			Route::get('list', ['as' => 'admin.provin.list', 'uses' => 'Admin\ProvinController@getList']);
			Route::get('add', ['as' => 'admin.provin.getAdd', 'uses' => 'Admin\ProvinController@getAdd']);
			Route::post('add', ['as' => 'admin.provin.postAdd', 'uses' => 'Admin\ProvinController@postAdd']);
			Route::get('delete/{id?}', ['as' => 'admin.provin.getDelete', 'uses' => 'Admin\ProvinController@getDelete']);
			Route::get('edit/{id?}', ['as' => 'admin.provin.getEdit', 'uses' => 'Admin\ProvinController@getEdit']);
			Route::post('edit/{id?}', ['as' => 'admin.provin.postEdit', 'uses' => 'Admin\ProvinController@postEdit']);
			Route::post('action', ['as' => 'admin.provin.action', 'uses' => 'Admin\ProvinController@action']);
		});

		/*Quản lý câu hỏi thường gặp*/
		Route::group(['prefix' => 'a&q'], function () {
			Route::get('list', ['as' => 'admin.aq.list', 'uses' => 'Admin\AqController@getList']);
			Route::get('add', ['as' => 'admin.aq.getAdd', 'uses' => 'Admin\AqController@getAdd']);
			Route::post('add', ['as' => 'admin.aq.postAdd', 'uses' => 'Admin\AqController@postAdd']);
			Route::get('delete/{id?}', ['as' => 'admin.aq.getDelete', 'uses' => 'Admin\AqController@getDelete']);
			Route::get('edit/{id?}', ['as' => 'admin.aq.getEdit', 'uses' => 'Admin\AqController@getEdit']);
			Route::post('edit/{id?}', ['as' => 'admin.aq.postEdit', 'uses' => 'Admin\AqController@postEdit']);
			Route::post('action', ['as' => 'admin.aq.action', 'uses' => 'Admin\AqController@action']);
		});

		/*Quản lý phần nhập thông tin hồ sơ cho người dùng*/
		Route::group(['prefix' => 'info'], function () {
			Route::get('list/level', ['as' => 'admin.infouser.listlevel', 'uses' => 'Admin\InfoUserController@getListLevel']);
			Route::get('list/empirical', ['as' => 'admin.infouser.listempirical', 'uses' => 'Admin\InfoUserController@getListEmpirical']);
			Route::get('list/diploma', ['as' => 'admin.infouser.listdiploma', 'uses' => 'Admin\InfoUserController@getListDiploma']);
			Route::get('list/diploma_wish', ['as' => 'admin.infouser.listdiploma_wish', 'uses' => 'Admin\InfoUserController@getListDiploma_wish']);
			Route::get('list/exigency', ['as' => 'admin.infouser.listexigency', 'uses' => 'Admin\InfoUserController@getListExigency']);
			Route::get('list/type', ['as' => 'admin.infouser.listtype', 'uses' => 'Admin\InfoUserController@getListType']);
			Route::get('list/probation_time', ['as' => 'admin.infouser.listlevel', 'uses' => 'Admin\InfoUserController@getListProbationTime']);
			Route::get('list/attribute', ['as' => 'admin.infouser.listempirical', 'uses' => 'Admin\InfoUserController@getListAttribute']);
			Route::get('list/loai_tn', ['as' => 'admin.infouser.listdiploma', 'uses' => 'Admin\InfoUserController@getListLoaiTn']);
			Route::get('list/language', ['as' => 'admin.infouser.listdiploma_wish', 'uses' => 'Admin\InfoUserController@getListLanguage']);
			Route::get('list/language_level', ['as' => 'admin.infouser.listexigency', 'uses' => 'Admin\InfoUserController@getListLanguageLevel']);
			Route::get('list/quy_mo', ['as' => 'admin.infouser.listtype', 'uses' => 'Admin\InfoUserController@getListQuyMo']);
			Route::get('list/wage', ['as' => 'admin.infouser.listtype', 'uses' => 'Admin\InfoUserController@getListWage']);
			Route::get('add/{alias?}', ['as' => 'admin.infouser.getAdd', 'uses' => 'Admin\InfoUserController@getAdd']);
			Route::post('add', ['as' => 'admin.infouser.postAdd', 'uses' => 'Admin\InfoUserController@postAdd']);
			Route::get('delete/{alias?}/{id?}', ['as' => 'admin.infouser.getDelete', 'uses' => 'Admin\InfoUserController@getDelete']);
			Route::get('edit/{id?}', ['as' => 'admin.infouser.getEdit', 'uses' => 'Admin\InfoUserController@getEdit']);
			Route::post('edit/{id?}', ['as' => 'admin.infouser.postEdit', 'uses' => 'Admin\InfoUserController@postEdit']);
			Route::get('deletetype/{alias?}/{id?}', ['as' => 'admin.infouser.getDeleteType', 'uses' => 'Admin\InfoUserController@getDeleteType']);
			Route::get('edittype/{id?}', ['as' => 'admin.infouser.getEditType', 'uses' => 'Admin\InfoUserController@getEditType']);
			Route::post('edittype/{id?}', ['as' => 'admin.infouser.postEditType', 'uses' => 'Admin\InfoUserController@postEditType']);
			Route::post('action', ['as' => 'admin.infouser.action', 'uses' => 'Admin\InfoUserController@action']);
		});
		
		/*Quản lý các công việc*/
		Route::group(['prefix' => 'job'], function () {
			Route::get('list', ['as' => 'admin.job.list', 'uses' => 'Admin\JobController@getList']);
			Route::get('add', ['as' => 'admin.job.getAdd', 'uses' => 'Admin\JobController@getAdd']);
			Route::post('add', ['as' => 'admin.job.postAdd', 'uses' => 'Admin\JobController@postAdd']);
			Route::get('delete/{id?}', ['as' => 'admin.job.getDelete', 'uses' => 'Admin\JobController@getDelete']);
			Route::get('edit/{id?}', ['as' => 'admin.job.getEdit', 'uses' => 'Admin\JobController@getEdit']);
			Route::post('edit/{id?}', ['as' => 'admin.job.postEdit', 'uses' => 'Admin\JobController@postEdit']);
		});

		/*Quản lý Admin đăng công việc*/
		Route::group(['prefix' => 'post/job'], function () {
			Route::get('list', ['as' => 'admin.postjob.list', 'uses' => 'Admin\PostJobController@getList']);
			Route::get('add', ['as' => 'admin.postjob.getAdd', 'uses' => 'Admin\PostJobController@getAdd']);
			Route::post('add', ['as' => 'admin.postjob.postAdd', 'uses' => 'Admin\PostJobController@postAdd']);
			Route::get('delete/{id?}', ['as' => 'admin.postjob.getDelete', 'uses' => 'Admin\PostJobController@getDelete']);
			Route::get('edit/{id?}', ['as' => 'admin.postjob.getEdit', 'uses' => 'Admin\PostJobController@getEdit']);
			Route::post('edit/{id?}', ['as' => 'admin.postjob.postEdit', 'uses' => 'Admin\PostJobController@postEdit']);
		});

		/*Quản lý Duyệt ho so và đăng việc*/
		Route::group(['prefix' => 'quan-ly-ho-so'], function () {
			Route::get('danh-sach', 'Admin\DuyetHoSoController@getListResume');
			Route::get('xem-nhanh/{alias?}', 'Admin\DuyetHoSoController@viewResume');
			Route::post('sua-nhanh', 'Admin\DuyetHoSoController@action');
		});

		/*Quản lý công việc của nhà tuyển dụng*/
		Route::group(['prefix' => 'quan-ly-cong-viec'], function () {
			Route::get('danh-sach', 'Admin\EmployerController@getListResume');
			Route::get('xem-nhanh/{alias?}', 'Admin\EmployerController@viewJob');
			Route::post('sua-nhanh', 'Admin\EmployerController@action');
		});
		/*Quản lý thành viên*/
		Route::group(['prefix' => 'quan-ly-thanh-vien'], function () {
			Route::get('nha-tuyen-dung', 'Admin\UserController@getListEmployer');
			Route::get('ung-vien', 'Admin\UserController@getListCandidate');
			Route::get('xem-nhanh/{alias?}', 'Admin\UserController@getViewUser');
			Route::post('sua-nhanh', 'Admin\UserController@action');
			Route::get('kich-hoat-cong-ty/{id?}', 'Admin\UserController@active');
			Route::get('bo-kich-hoat-cong-ty/{id?}', 'Admin\UserController@deActive');
		});

		










		Route::group(['prefix' => 'post'], function () {
			Route::get('list', ['as' => 'admin.post.list', 'uses' => 'Admin\PostController@getList']);
			Route::get('add', ['as' => 'admin.post.getAdd', 'uses' => 'Admin\PostController@getAdd']);
			Route::post('add', ['as' => 'admin.post.postAdd', 'uses' => 'Admin\PostController@postAdd']);
			Route::get('delete/{id?}', ['as' => 'admin.post.getDelete', 'uses' => 'Admin\PostController@getDelete']);
			Route::get('edit/{id?}', ['as' => 'admin.post.getEdit', 'uses' => 'Admin\PostController@getEdit']);
			Route::post('edit/{id?}', ['as' => 'admin.post.postEdit', 'uses' => 'Admin\PostController@postEdit']);
		});


		Route::group(['prefix' => 'about'], function () {
			Route::get('list', ['as' => 'admin.about.getList', 'uses' => 'Admin\AboutController@getList']);
			Route::get('add', ['as' => 'admin.about.getAdd', 'uses' => 'Admin\AboutController@getAdd']);
			Route::post('add', ['as' => 'admin.about.postAdd', 'uses' => 'Admin\AboutController@postAdd']);
			Route::get('delete/{id?}', ['as' => 'admin.about.getDelete', 'uses' => 'Admin\AboutController@getDelete']);
			Route::get('edit/{id?}', ['as' => 'admin.about.getEdit', 'uses' => 'Admin\AboutController@getEdit']);
			Route::post('edit/{id?}', ['as' => 'admin.about.postEdit', 'uses' => 'Admin\AboutController@postEdit']);
			Route::get('listshop', ['as' => 'admin.about.getListShop', 'uses' => 'Admin\AboutController@getListShop']);
			Route::get('editshop/{id?}', ['as' => 'admin.about.getEditShop', 'uses' => 'Admin\AboutController@getEditShop']);
			Route::post('editshop/{id?}', ['as' => 'admin.about.postEditShop', 'uses' => 'Admin\AboutController@postEditShop']);
		});

		Route::group(['prefix' => 'catepost'], function () {
			Route::get('list', ['as' => 'admin.catepost.list', 'uses' => 'Admin\CatePostController@getList']);
			Route::get('add', ['as' => 'admin.catepost.getAdd', 'uses' => 'Admin\CatePostController@getAdd']);
			Route::post('add', ['as' => 'admin.catepost.postAdd', 'uses' => 'Admin\CatePostController@postAdd']);
			Route::get('delete/{id?}', ['as' => 'admin.catepost.getDelete', 'uses' => 'Admin\CatePostController@getDelete']);
			Route::get('edit/{id?}', ['as' => 'admin.catepost.getEdit', 'uses' => 'Admin\CatePostController@getEdit']);
			Route::post('edit/{id?}', ['as' => 'admin.catepost.postEdit', 'uses' => 'Admin\CatePostController@postEdit']);
		});

		/*banner, icon, logo*/
		Route::group(['prefix' => 'image'], function () {
			Route::get('list', ['as' => 'admin.image.list', 'uses' => 'Admin\ImageController@getList']);
			Route::get('add', ['as' => 'admin.image.getAdd', 'uses' => 'Admin\ImageController@getAdd']);
			Route::post('add', ['as' => 'admin.image.postAdd', 'uses' => 'ImageController@postAdd']);
			Route::get('delete/{id?}', ['as' => 'admin.image.getDelete', 'uses' => 'Admin\ImageController@getDelete']);
			Route::get('edit/{id?}', ['as' => 'admin.image.getEdit', 'uses' => 'Admin\ImageController@getEdit']);
			Route::post('edit/{id?}', ['as' => 'admin.image.postEdit', 'uses' => 'Admin\ImageController@postEdit']);
		});
		Route::get('change/pass', 'Admin\CandidateController@getChange');
		Route::post('change/pass', 'Admin\CandidateController@postChange');
});



Route::auth();

Route::get('/', 'WelcomeController@index');
Route::get('/about', 'WelcomeController@about');
Route::get('/contact', 'WelcomeController@contact');
Route::post('/contact', 'WelcomeController@postContact');
Route::get('/project', 'WelcomeController@project');
Route::get('detail/{alias?}', 'WelcomeController@detail');
Route::any( '{all?}' , 'WelcomeController@erors') -> where( 'all' , '()' );

/*Đăng ký thành viên*/
Route::get('facebook/redirect', 'Admin\SocialController@redirectFacebookToProvider');
Route::get('facebook/callback', 'Admin\SocialController@handleFacebookProviderCallback');

Route::get('google/redirect', 'Admin\SocialController@redirectGoogleToProvider');
Route::get('google/callback', 'Admin\SocialController@handleGoogleProviderCallback');

Route::post('user/register', 'Admin\SocialController@postRegister');
Route::get('user/register', 'Admin\SocialController@getRegister');
Route::post('user/registerEmployer', 'Admin\SocialController@postRegisterEmployer');
Route::post('user/editProfile', 'Admin\SocialController@postEditProfile');
Route::post('user/editImageAvatar', 'Admin\SocialController@changeImageAvatar');
Route::get('user/active/{id?}',['as' => 'getConfirmUser', 'uses' => 'Admin\SocialController@getConfirmUser']);


/*Quản lý tạo tài khoản và đăng nhập*/
Route::get('dang-ky', 'Admin\SocialController@getRegister');
Route::post('dang-ky', 'Admin\SocialController@postRegister');
Route::get('dang-nhap', 'Admin\SocialController@getLogin');
Route::post('dang-nhap', ['as' => 'admin.postLogin', 'uses' => 'Auth\AuthController@postLogin']);
Route::get('quen-mat-khau', 'Admin\SocialController@getForgotPass');
Route::post('quen-mat-khau', 'Admin\SocialController@postForgotPass');

/*Quản lý Thông Tin Ứng Viên*/
Route::group(['prefix' => 'ung-vien', 'middleware' => 'candidate'], function () {
	Route::get('tai-khoan', 'CandidateController@getInfoCandidate');
	Route::get('cap-nhat', 'CandidateController@getInfoUpdate');
	Route::post('cap-nhat', 'CandidateController@postInfoUpdate');
	Route::get('ho-so', 'CandidateController@getResume');
	Route::post('ho-so', 'CandidateController@postResume');
	Route::get('in-ho-so/{alias?}', 'CandidateController@getInResume');
	Route::post('cap-nhat-ho-so-co-ban', 'CandidateController@postEditResume');
	Route::get('tao-ho-so-chi-tiet/{id?}', 'CandidateController@getDetailResume');
	Route::post('tao-ho-so-chi-tiet/{id?}', 'CandidateController@postDetailResume');
	Route::post('ho-so-ca-nhan/{id?}', 'CandidateController@postEidtDetailResume');
	Route::get('ho-so-ca-nhan', 'CandidateController@getViewDetailResume');
	Route::get('chinh-sua-gioi-thieu/{id?}', 'CandidateController@getEditIntro');
	Route::get('edit/{id?}', ['as' => 'admin.provin.getEdit', 'uses' => 'Admin\ProvinController@getEdit']);
	Route::post('edit/{id?}', ['as' => 'admin.provin.postEdit', 'uses' => 'Admin\ProvinController@postEdit']);
	Route::post('action', ['as' => 'admin.provin.action', 'uses' => 'Admin\ProvinController@action']);
	Route::get('viec-lam-da-luu', 'CandidateController@getViewSaveJobs');
	Route::get('xoa-viec-lam-da-luu/{id?}', 'CandidateController@getDeleteViewSaveJobs');
	Route::get('viec-lam-ung-tuyen', 'CandidateController@getViewApplyJobs');
	Route::get('nha-tuyen-dung-xem', 'CandidateController@getViewEmployerViewResume');
	Route::get('thay-doi-mat-khau', 'CandidateController@getChangePass');
	Route::post('thay-doi-mat-khau', 'CandidateController@postChangePass');
	Route::get('luu-ho-so/{id?}', 'CandidateController@getApply');
	Route::get('nop-ho-so/{id?}', 'CandidateController@getApplyJob');
});



/*Quản lý employer*/
Route::group(['prefix' => 'nha-tuyen-dung', 'middleware' => 'employer'], function () {
	Route::get('tai-khoan', 'EmployerController@getInfoEmployer');
	Route::post('tai-khoan', 'EmployerController@postInfoEmployer');
	Route::get('thay-doi-mat-khau', 'EmployerController@getChangePass');
	Route::post('thay-doi-mat-khau', 'EmployerController@postChangePass');
	Route::get('dang-tin-tuyen-dung', 'EmployerController@getPostJob');
	Route::post('dang-tin-tuyen-dung', 'EmployerController@postJob');
	Route::get('cap-nhat-tin-tuyen-dung/{id?}', 'EmployerController@getUpdatePostJob');
	Route::post('cap-nhat-tin-tuyen-dung', 'EmployerController@postUpdateJob');
	Route::get('xoa-tin-tuyen-dung/{id?}', 'EmployerController@deletePostJob');
	Route::get('quan-ly-tin-tuyen-dung', 'EmployerController@getManagerJob');
	Route::get('ho-so-da-luu', 'EmployerController@getSaveResume');
	Route::get('xoa-ho-so-da-luu/{id?}', 'EmployerController@deleteSaveResume');
	Route::get('nop-ho-so/{id?}', 'EmployerController@applyResume');
	Route::get('cap-nhat-ho-so-da-luu/{alias?}', 'EmployerController@updateSaveResume');
	Route::post('cap-nhat-ho-so-da-luu', 'EmployerController@postUpdateSaveResume');
	Route::get('ho-so-ung-tuyen', 'EmployerController@getResumeApply');
	Route::get('tim-ho-so', 'EmployerController@getFindResume');
});


Route::get('ho-so/{alias?}', 'MainController@viewResume');
Route::get('cong-viec/{alias?}', 'MainController@viewJob');
Route::get('tim-kiem', 'MainController@getSearchJob');
Route::get('cong-ty/{alias?}', 'MainController@findJobByCompany');
Route::get('tinh-thanh/{provin?}', 'MainController@findJobByProvin');
Route::get('viec-lam/{alias?}', 'MainController@findJobByJob');
Route::get('viec-lam-luong-cao', 'WelcomeController@findJobByHighWage');
Route::get('viec-lam-moi', 'WelcomeController@findJobByNew');
Route::get('viec-lam-hot', 'WelcomeController@findJobByHot');
Route::get('viec-lam-dang-gap', 'WelcomeController@findJobByGap');
Route::get('viec-lam-moi-nhat', 'WelcomeController@findFullJob');
Route::get('cong-viec-ban-thoi-gian', 'WelcomeController@findJobByManager');
Route::get('viec-lam-thuc-tap', 'WelcomeController@findJobByStudent');
Route::get('viec-lam-them-ngoai-gio', 'WelcomeController@findJobByCommon');
Route::get('viec-lam-chinh-thuc', 'WelcomeController@findJobBySpecialized');
Route::get('tim-kiem-ho-so', 'MainController@getSearchResume');
Route::get('trang-tuyen-dung', 'MainController@getFullResume');
Route::get('ho-so-tinh-thanh/{alias}', 'MainController@findResumeByProvin');
Route::get('ho-so-cong-viec/{alias?}', 'MainController@findResumeByJob');
Route::get('in-ho-so/{alias?}', 'WelcomeController@getInResume');
Route::get('cau-hoi-thuong-gap', 'WelcomeController@getViewAq');
Route::post('lien-he', 'WelcomeController@postContact');
Route::get('bai-viet/{alias?}', 'WelcomeController@getViewPost');


<?php

namespace App\Http\Middleware;

use Closure, Auth;

class Candidates
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!Auth::check() || Auth::user()->level != 1) {
            Auth::logout();
            $message = ['level' => 'danger', 'flash_message' => 'Bạn chưa đăng nhập, vui lòng đăng nhập'];
            return redirect('dang-nhap')->with($message);
        }elseif(Auth::user()->active != 1){
            Auth::logout();
            $message = ['level' => 'danger', 'flash_message' => 'Tài khoản chưa được kích hoạt, vui lòng kiểm tra mail để kích hoạt tài khoản'];
            return redirect('dang-nhap')->with($message);
        }elseif(Auth::user()->banded != 1){
            Auth::logout();
             $message = ['level' => 'danger', 'flash_message' => 'Tài khoản đã bị cấm hoạt động'];
            return redirect('dang-nhap')->with($message);
        }

        return $next($request);
    }
}

<?php 
namespace App;
use Illuminate\Database\Eloquent\Model;
use DB;
class Search extends Model {

	public static function getProvinSearch()
	{
		return DB::table('provins')->select('name', 'id')->where('search', 1)->get();
	}
	public static function getCountJob()
	{
		return DB::table('post_jobs')->where('active', 1)->where('status', 1)->count();
	}
	public static function getCountNewJob()
	{
		return DB::select('SELECT count(*) as count FROM post_jobs WHERE active =1 AND status = 1 AND create_date > DATE_ADD(CURDATE(),INTERVAL -4 DAY)')[0]->count;
	}

}

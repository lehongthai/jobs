<?php $__env->startSection('body_right'); ?>
    
    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
            <tr align="center">
                <td style="display: none"></td>
                <td style="display: none"></td>
                <th>Tên</th>
                <th>Miền</th>
                <th>Search</th>
                <th>Edit</th>
                <th>Delete</th>   
            </tr>
        </thead>
        <tbody>
        <?php if(isset($data) && $data != NULL): ?>
        <?php foreach($data as $index => $item): ?>
            <tr class="odd gradeX" align="center">
                <td style="display: none"><?php echo $item['id']; ?></td>
                <td style="display: none"><?php echo csrf_token(); ?></td>
                <td><?php echo $item['name']; ?></td>
                <td>
                    <?php if($item['compass'] == 1): ?>
                    Miền Nam
                    <?php elseif($item['compass'] == 2): ?>
                    Miền Trung
                    <?php elseif($item['compass'] == 3): ?>
                    Miền Bắc
                    <?php endif; ?>
                </td>
                 <td>
                 <?php if($item['search'] == 1): ?>
                 Có
                 <?php else: ?>
                 Không
                 <?php endif; ?>
                 </td>
                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo URL::route('admin.provin.getEdit', $item['id']); ?>">Edit</a></td>
                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo URL::route('admin.provin.getDelete', $item['id']); ?>"> Delete</a></td>
            </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

<script src="<?php echo url('public/admin'); ?>/js/jquery.tabledit.js"></script>
<script type="text/javascript">
    $('#dataTables-example').Tabledit({
    url: '<?php echo url('admin/provin/action'); ?>',
    deleteButton: false,
    columns: {
        identifier: [0, 'id'],
        editable: [[1, '_token'],  [4, 'search', '{"1": "Có", "2": "Không"}']]
    },
    action: 'Sửa Nhanh',
    onDraw: function() {
    },

    onSuccess: function(data, textStatus, jqXHR) {
        window.location.href="<?php echo url('admin/provin/list'); ?>";
    },
    onFail: function(jqXHR, textStatus, errorThrown) {
        $(function() {
        $('#dialog-message').empty();
          $('#dialog-message').append(jqXHR['responseJSON']['code']);
          $( "#dialog-message" ).dialog({
                modal: true,
                buttons: [
                          {
                              text: "OK",
                              click: function() {                     
                                  $(this).dialog("close"); 
                                  var row_fail = $('.danger').index();
                                  $('.tabledit-edit-button')[row_fail].click();
                                  $('input[name="'+ jqXHR['responseJSON']['position_error'] +'"]').focus();
                              }
                          }
                        ]
          });
        });
        },
    onAlways: function() {
    },
    onAjax: function(action, serialize) {
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
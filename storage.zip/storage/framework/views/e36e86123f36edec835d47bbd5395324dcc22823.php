<?php $__env->startSection('body_right'); ?>
<?php if($data): ?>
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr align="center">
                                <th>Tên</th>
                                <th>Ảnh</th>
                                <?php if($data->name == 'bannerBelow'): ?>
                                <th>Nộ Dung</th>
                                <?php endif; ?>
                                <th>Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="odd gradeX" align="center">
                                <td><?php echo $data->name; ?></td>
                                <td><img src="<?php echo $data->image_thumb; ?>"></td>
                                <?php if($data->name == 'bannerBelow'): ?>
                                <td><?php echo $data->content; ?></td>
                                <?php endif; ?>
                                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo URL::route('admin.image.getEdit', $data->id); ?>">Edit</a></td>
                            </tr>
                        </tbody>
                    </table>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
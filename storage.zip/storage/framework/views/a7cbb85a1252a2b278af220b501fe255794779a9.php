<div id="slider" class="sl-slider-wrapper">

      <div class="sl-slider">
      
        <div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-25" data-slice2-rotation="-25" data-slice1-scale="2" data-slice2-scale="2">
          <div class="sl-slide-inner">
            <div class="bg-img bg-img-1"></div>
            <div class="tint"></div>
            <div class="slide-content">
              <h2>Looking for a job?</h2>
              <h3>There’s no better place to start</h3>
              <p><a href="jobs.html" class="btn btn-lg btn-default">Find a job</a></p>
            </div>
          </div>
        </div>
      
        <div class="sl-slide" data-orientation="vertical" data-slice1-rotation="10" data-slice2-rotation="-15" data-slice1-scale="1.5" data-slice2-scale="1.5">
          <div class="sl-slide-inner">
            <div class="bg-img bg-img-2"></div>
            <div class="tint"></div>
            <div class="slide-content">
              <h2>Need an employee?</h2>
              <h3>We've got perfect candidates</h3>
              <p><a href="candidates.html" class="btn btn-lg btn-default">Post a job</a></p>
            </div>
          </div>
        </div>
      
        <div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="3" data-slice2-rotation="3" data-slice1-scale="2" data-slice2-scale="1">
          <div class="sl-slide-inner">
            <div class="bg-img bg-img-3"></div>
            <div class="tint"></div>
            <div class="slide-content">
              <h2>Evolving your career?</h2>
              <h3>Find new opportunities here</h3>
              <p><a href="jobs.html" class="btn btn-lg btn-default">Find a job</a></p>
            </div>
          </div>
        </div>
      
        <div class="sl-slide" data-orientation="vertical" data-slice1-rotation="-5" data-slice2-rotation="25" data-slice1-scale="2" data-slice2-scale="1">
          <div class="sl-slide-inner">
            <div class="bg-img bg-img-4"></div>
            <div class="tint"></div>
            <div class="slide-content">
              <h2>Extending your team?</h2>
              <h3>Find a perfect match</h3>
              <p><a href="candidates.html" class="btn btn-lg btn-default">Find a cadidate</a></p>
            </div>
          </div>
        </div>

      </div>

      <nav id="nav-arrows" class="nav-arrows">
        <span class="nav-arrow-prev">Previous</span>
        <span class="nav-arrow-next">Next</span>
      </nav>

      <nav id="nav-dots" class="nav-dots">
        <span class="nav-dot-current"></span>
        <span></span>
        <span></span>
        <span></span>
      </nav>

    </div>
<?php use App\Common; ?>

<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="row" style="margin-top: 100px">
<div class="col-sm-8">
<?php echo $__env->make('page.blocks.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* add info user */ ?>
<?php echo $__env->make('page.blocks.info_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end info user */ ?>

<?php /* add info user */ ?>
<?php echo $__env->make('page.blocks.info_resume_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end info user */ ?>

<?php /* add menu user */ ?>
<?php echo $__env->make('page.blocks.menu_bottom_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end menu user */ ?>
<div class="row">
 <input type="hidden" name="_token" id="_token" value="<?php echo csrf_token(); ?>">
            <div class="panel panel-primary">
              <div class="panel-heading text-center">
                <h3 class="panel-title">Giới Thiệu Công Ty Cũ</h3>
              </div>
              <div class="panel-body">
                <div id="intro_content">
                <p id="intro"><?php echo $detailCompany->intro; ?></p>
                </div>
                <div class="pull-right" id="intro_button_div">
                <button type="button" class="btn btn-xs btn-primary" id="get-modal-intro">Chỉnh Sửa</button>
              </div>
              </div>
            </div>
            <div class="panel panel-primary">
              <div class="panel-heading text-center">
                <h3 class="panel-title">Kinh Nghiệm Làm Việc</h3>
              </div>
              <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-hover table-bordered">
                    <tbody>
                      <tr>
                        <th>Tên Công Ty</th>
                        <th><?php echo $detailCompany->company; ?></th>
                      </tr>
                      <tr>
                        <th>Chức Vụ</th>
                        <th><?php echo $detailCompany->position; ?></th>
                      </tr>
                      <tr>
                        <th>Thời Gian Làm</th>
                        <th>Từ <?php echo $detailCompany->start_time . ' Đến ' .  $detailCompany->end_time; ?></th>
                      </tr>
                      <tr>
                        <th>Lương Được Hưởng</th>
                        <th><?php echo number_format($detailCompany->wage, 0, '.', ','); ?></th>
                      </tr>
                      <tr>
                        <th>Mô Tả Công Việc</th>
                        <th><?php echo $detailCompany->description_job; ?></th>
                      </tr>
                      <tr>
                        <th>Thành Tích</th>
                        <th><?php echo $detailCompany->achieve; ?></th>
                      </tr>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="pull-right">
      <button type="button" id="get-modal-company" class="btn btn-xs btn-primary">Chỉnh Sửa</button>
    </div>
              </div>
              
            </div>
            <div class="panel panel-primary">
              <div class="panel-heading text-center">
                <h3 class="panel-title">Trình Độ & Bằng Cấp</h3>
              </div>
              <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-hover table-bordered">
                    <tbody>
                      <tr>
                        <th>Trình Độ</th>
                        <th><?php echo Common::getNameById($detailCompany->level); ?></th>
                      </tr>
                      <tr>
                        <th>Đơn Vị Đào Tạo</th>
                        <th><?php echo $detailCompany->school_name; ?></th>
                      </tr>
                      <tr>
                        <th>Thời Gian Đào Tạo</th>
                        <th>Từ <?php echo $detailCompany->start_time_school . ' Đến ' . $detailCompany->end_time_school; ?></th>
                      </tr>
                      <tr>
                        <th>Chuyên Ngành</th>
                        <th><?php echo $detailCompany->description_diploma; ?></th>
                      </tr>
                      <tr>
                        <th>Tốt Nghiệp Loại</th>
                        <th><?php echo Common::getNameById($detailCompany->loai_tn); ?></th>
                      </tr>
                      <tr>
                        <th>Bằng Tốt Nghiệp</th>
                        <th><?php if($detailCompany->image_tn != NULL): ?>
                        <img id="target" src="<?php echo url('public\upload\image_tn\\') . $detailCompany->image_tn; ?>"><?php endif; ?></th>
                      </tr>
                      <tr>
                        <th>Ngoại Ngữ</th>
                        <th><?php echo Common::getNameById($detailDiploma->language); ?></th>
                      </tr>
                      <tr>
                        <th>Trình Độ Ngoại Ngữ</th>
                        <th><?php echo Common::getNameById($detailDiploma->language_level); ?></th>
                      </tr>
                      <tr>
                        <th>Chi Tiết Ngoại Ngữ</th>
                        <td>
                          <ul>
                            <li> Nghe : <?php echo Common::getTypeLanguageAndTech($detailDiploma->listen); ?></li>
                            <li> Nói : <?php echo Common::getTypeLanguageAndTech($detailDiploma->speak); ?></li>
                            <li> Đọc : <?php echo Common::getTypeLanguageAndTech($detailDiploma->read ); ?></li>
                            <li> Viết : <?php echo Common::getTypeLanguageAndTech($detailDiploma->write); ?></li>
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <th>Tin Học Văn Phòng</th>
                        <td>
                          <ul>
                            <li> MS Word : <?php echo Common::getTypeLanguageAndTech($detailDiploma->ms_word); ?></li>
                            <li> MS Excel : <?php echo Common::getTypeLanguageAndTech($detailDiploma->ms_excel); ?></li>
                            <li> MS Power Point : <?php echo Common::getTypeLanguageAndTech($detailDiploma->ms_power_point ); ?></li>
                            <li> MS Outlook : <?php echo Common::getTypeLanguageAndTech($detailDiploma->ms_outlook); ?></li>
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <th>Kỹ Năng Khác</th>
                        <td><?php echo $detailDiploma->others; ?></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="pull-right">
      <button type="button" id="get-modal-level" class="btn btn-xs btn-primary">Chỉnh Sửa</button>
    </div>
              </div>

            </div>
            <button type="button" class="btn btn-large btn-block btn-warning" onclick="window.location='<?php echo url('ung-vien/ho-so'); ?>'">Xem bản chi tiết</button>
            </div>
</div>
<div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            </div>
</div>
<div class="modal fade" id="modal-intro">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Chỉnh Sửa Giới Thiệu Bản Thân</h4>
      </div>
      <div class="modal-body">
      <form action="<?php echo url('ung-vien/ho-so-ca-nhan'); ?>" method="POST" class="form-horizontal" role="form">
      <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
      <input type="hidden" name="check_edit" value="edit_company_intro">
      <input type="hidden" name="id_company" value="<?php echo $detailCompany->id; ?>">
        <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="intro">Giới Thiệu</label><span class="require">*</span>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <textarea name="intro" id="intro" class="form-control" rows="3"><?php echo old('intro', $detailCompany->intro); ?></textarea>
                          <span style="color:red"><?php echo $errors->first('intro'); ?></span>
                    </div>
                    </div>
                  </div>
                  <div class="modal-footer text-center">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Hủy</button>
        <button type="submit" class="btn btn-primary">Lưu</button>
      </div>
                  </form>
      </div>
      
    </div>
  </div>
</div>
<div class="modal fade" id="modal-company">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Chỉnh Sửa Kinh Nghiệm Làm Việc</h4>
      </div>
      <div class="modal-body">
      <form action="<?php echo url('ung-vien/ho-so-ca-nhan'); ?>" method="POST" class="form-horizontal" role="form">
      <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
      <input type="hidden" name="check_edit" value="edit_company">
      <input type="hidden" name="id_company" value="<?php echo $detailCompany->id; ?>">
        <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="company">Tên Công Ty <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <input type="text" name="company" id="company" class="form-control" value="<?php echo old('company', $detailCompany->company); ?>">
                          <span style="color:red"><?php echo $errors->first('company'); ?></span>
                        </div>
                      </div>
                    </div> 
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="position">Chức Vụ <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <input type="text" name="position" id="position" class="form-control" value="<?php echo old('position',$detailCompany->position); ?>">
                          <span style="color:red"><?php echo $errors->first('position'); ?></span>
                        </div>
                      </div>
                    </div> 
                    
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label>Thời Gian <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                      <?php 
                        $arr_start = explode('/', $detailCompany->start_time);
                        $arr_end = explode('/', $detailCompany->end_time); 
                      ?>
                        <div class="form-group">
                          <table style="width: 100%">
                            <tr>
                              <td>Từ: </td>
                              <td>
                                <select name="start_month" id="start_month" class="form-control">
                                  <?php for($i = 1; $i < 13; $i++): ?>
                                  <option value="<?php echo $i; ?>" <?php if(old('start_month') == $i || $arr_start[0] == $i): ?> selected <?php endif; ?>>Tháng <?php echo $i; ?></option>
                                  <?php endfor; ?>
                                </select>
                              </td>
                              <td>&nbsp;</td>
                              <td>
                                <select name="start_year" id="start_year" class="form-control">
                                  <?php for($i = 1940; $i <= date('Y'); $i++): ?>
                                  <option value="<?php echo $i; ?>" <?php if(old('start_year') == $i  || $arr_start[1] == $i): ?> selected <?php endif; ?>><?php echo $i; ?></option>
                                  <?php endfor; ?>
                                </select>
                              </td>
                              <td>&nbsp;</td>
                              <td>Đến: </td>
                              <td>
                                <select name="end_month" id="end_month" class="form-control">
                                  <?php for($i = 1; $i < 13; $i++): ?>
                                  <option value="<?php echo $i; ?>" <?php if(old('end_month') == $i  || $arr_end[0] == $i): ?> selected <?php endif; ?>>Tháng <?php echo $i; ?></option>
                                  <?php endfor; ?>
                                </select>
                              </td>
                              <td>&nbsp;</td>
                              <td>
                                <select name="end_year" id="end_year" class="form-control">
                                  <?php for($i = 1940; $i <= date('Y'); $i++): ?>
                                  <option value="<?php echo $i; ?>" <?php if(old('end_year') == $i  || $arr_end[1] == $i): ?> selected <?php endif; ?>><?php echo $i; ?></option>
                                  <?php endfor; ?>
                                </select>
                              </td>
                            </tr>
                          </table>
                        </div>
                      </div>
                    </div>  
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label>Mức Lương</label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <table style="width: 100%">
                            <tr>
                              <td>
                                <select name="type_wage" id="type_wage" class="form-control">
                                  <option value="vnd">VND</option>
                                  <option value="usd">USD</option>
                                </select>
                              </td>
                              <td>&nbsp; &nbsp;</td>
                              <td>
                                <input type="text" name="wage" id="wage" class="form-control" value="<?php echo old('wage',$detailCompany->wage); ?>">
                              </td>
                            </tr>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="description_job">Mô Tả Công Việc</label><span class="require">*</span>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <textarea name="description_job" id="description_job" class="form-control" rows="3"><?php echo old('description_job', $detailCompany->description_job); ?></textarea>
                          <span style="color:red"><?php echo $errors->first('description_job'); ?></span>
                    </div>
                    </div>
                  </div>
                  <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="achieve">Thành Tích</label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <textarea name="achieve" id="achieve" class="form-control" rows="3"><?php echo old('achieve',$detailCompany->achieve); ?></textarea>
                          <span style="color:red"><?php echo $errors->first('achieve'); ?></span>
                    </div>
                    </div>
                  </div>
                  <div class="modal-footer text-center">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Hủy</button>
        <button type="submit" class="btn btn-primary">Lưu</button>
      </div>
                  </form>
      </div>
      
    </div>
  </div>
</div>
<div class="modal fade" id="modal-level">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Cập Nhật Trình Độ & Bằng Cấp</h4>
      </div>
      <div class="modal-body">
      <form action="<?php echo url('ung-vien/ho-so-ca-nhan'); ?>" method="POST" class="form-horizontal" role="form" enctype="multipart/form-data">
      <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
      <input type="hidden" name="check_edit" value="edit_level">
      <input type="hidden" name="id_company" value="<?php echo $detailCompany->id; ?>">
      <input type="hidden" name="id_level" value="<?php echo $detailDiploma->id; ?>">
        <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="level">Trình Độ <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <select name="level" id="level" class="form-control">
                            <option>-- Vui Lòng Chọn Một --</option>
                            <?php foreach($listLevel as $level): ?>
                             <option value="<?php echo $level->id; ?>" <?php if(old('level') == $level->id || $detailCompany->level == $level->id): ?> selected <?php endif; ?>>-- <?php echo $level->name; ?> --</option>
                            <?php endforeach; ?>
                          </select>
                          <span style="color:red"><?php echo $errors->first('level'); ?></span>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="school_name">Đơn Vị Đào Tạo <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <input type="text" name="school_name" id="school_name" class="form-control" value="<?php echo old('school_name', $detailCompany->school_name); ?>">
                          <span style="color:red"><?php echo $errors->first('school_name'); ?></span>
                        </div>
                      </div>
                    </div> 
                    
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label>Thời Gian <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <table style="width: 100%">
                            <tr>
                              <td>Từ: </td>
                              <td>
                                <select name="start_time_school" id="start_time_school" class="form-control">
                                  <?php for($i = 2000; $i < date('Y'); $i++): ?>
                                  <option value="<?php echo $i; ?>" <?php if(old('start_time_school') == $i || $detailCompany->start_time_school == $i): ?> selected <?php endif; ?>><?php echo $i; ?></option>
                                  <?php endfor; ?>
                                </select>
                                <span style="color:red"><?php echo $errors->first('start_time_school'); ?></span>
                              </td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>Đến: </td>
                              <td>
                                <select name="end_time_school" id="end_time_school" class="form-control">
                                  <?php for($i = 2000; $i < date('Y'); $i++): ?>
                                  <option value="<?php echo $i; ?>" <?php if(old('end_time_school') == $i || $detailCompany->end_time_school == $i): ?> selected <?php endif; ?>><?php echo $i; ?></option>
                                  <?php endfor; ?>
                                </select>
                                 <span style="color:red"><?php echo $errors->first('end_time_school'); ?></span>
                              </td>
                            </tr>
                          </table>
                        </div>
                      </div>
                    </div>  
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="description_diploma">Chuyên Ngành <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <input type="text" name="description_diploma" id="description_diploma" class="form-control" value="<?php echo old('description_diploma', $detailCompany->description_diploma); ?>">
                          <span style="color:red"><?php echo $errors->first('description_diploma'); ?></span>
                        </div>
                      </div>
                    </div> 
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label>Loại Tốt Nghiệp <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <select name="loai_tn" id="input" class="form-control">
                            <option>-- Vui Lòng Chọn Một --</option>
                            <?php foreach($listLoaiTn as $loai_tn): ?>
                             <option value="<?php echo $loai_tn->id; ?>" <?php if(old('loai_tn') == $loai_tn->id || $detailCompany->loai_tn == $loai_tn->id): ?> selected <?php endif; ?>>-- <?php echo $loai_tn->name; ?> --</option>
                            <?php endforeach; ?>
                          </select>
                          <span style="color:red"><?php echo $errors->first('loai_tn'); ?></span>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="image_tn">Tải Bằng Tốt Nghiệp <span>(nếu có)</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                         <input type="file" name="image_tn" id="image_tn" class="form-control" value="<?php echo old('image_tn'); ?>">
                         <span style="color:red"><?php echo $errors->first('image_tn'); ?></span>
                        </div>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="language">Ngoại Ngữ </label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <select name="language" id="language" class="form-control">
                            <option>-- Vui Lòng Chọn Một --</option>
                            <?php foreach($listLanguage as $language): ?>
                             <option value="<?php echo $language->id; ?>" <?php if(old('language') == $language->id || $detailDiploma->language == $language->id): ?> selected <?php endif; ?>>-- <?php echo $language->name; ?> --</option>
                            <?php endforeach; ?>
                          </select>
                          <span style="color:red"><?php echo $errors->first('language'); ?></span>
                        </div>
                      </div>
                    </div> 
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="language_level">Trình Độ </label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <select name="language_level" id="language_level" class="form-control">
                            <option>-- Vui Lòng Chọn Một --</option>
                            <?php foreach($listLanguageLevel as $language_level): ?>
                             <option value="<?php echo $language_level->id; ?>" <?php if(old('language_level') == $language_level->id || $detailDiploma->language_level == $language_level->id): ?> selected <?php endif; ?>>-- <?php echo $language_level->name; ?> --</option>
                            <?php endforeach; ?>
                          </select>
                           <span style="color:red"><?php echo $errors->first('language_level'); ?></span>
                        </div>
                      </div>
                    </div> 
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <table style="text-align: center; width: 100%">
                          <tr>
                            <td>&nbsp;</td>
                            <td>Tốt</td>
                            <td>Khá</td>
                            <td>Trung Bình</td>
                            <td>Kém</td>
                          </tr>
                          <tr>
                            <td>Nghe</td>
                            <td><input type="checkbox" value="1" name="listen_language" <?php if(old('listen_language') == 1 || $detailDiploma->listen == 1): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="2" name="listen_language" <?php if(old('listen_language') == 2 || $detailDiploma->listen == 2): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="3" name="listen_language" <?php if(old('listen_language') == 3 ||  $detailDiploma->listen == 3): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="4" name="listen_language" <?php if(old('listen_language') == 4 ||  $detailDiploma->listen == 4): ?> checked <?php endif; ?>></td>
                          </tr>
                          <tr>
                            <td>Nói</td>
                            <td><input type="checkbox" value="1" name="speak_language" <?php if(old('speak_language') == 1 ||  $detailDiploma->speak == 1): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="2" name="speak_language" <?php if(old('speak_language') == 2 ||  $detailDiploma->speak == 2): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="3" name="speak_language" <?php if(old('speak_language') == 3 ||  $detailDiploma->speak == 3): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="4" name="speak_language" <?php if(old('speak_language') == 4 ||  $detailDiploma->speak == 4): ?> checked <?php endif; ?>></td>
                          </tr>
                          <tr>
                            <td>Đọc</td>
                            <td><input type="checkbox" value="1" name="read_language" <?php if(old('read_language') == 1 ||  $detailDiploma->read == 1): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="2" name="read_language" <?php if(old('read_language') == 2 ||  $detailDiploma->read == 2): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="3" name="read_language" <?php if(old('read_language') == 3 ||  $detailDiploma->read == 3): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="4" name="read_language" <?php if(old('read_language') == 4 ||  $detailDiploma->read == 4): ?> checked <?php endif; ?>></td>
                          </tr>
                          <tr>
                            <td>Viết</td>
                            <td><input type="checkbox" value="1" name="write_language" <?php if(old('write_language') == 1 ||  $detailDiploma->write == 1): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="2" name="write_language" <?php if(old('write_language') == 2 ||  $detailDiploma->write == 2): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="3" name="write_language" <?php if(old('write_language') == 3 ||  $detailDiploma->write == 3): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="4" name="write_language" <?php if(old('write_language') == 4 ||  $detailDiploma->write == 4): ?> checked <?php endif; ?>></td>
                          </tr>
                        </table>
                      </div>
                      </div>
                      <hr>
                      <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                      <label>Tin Học Văn Phòng</label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <table style="text-align: center; width: 100%">
                          <tr>
                            <td>&nbsp;</td>
                            <td>Tốt</td>
                            <td>Khá</td>
                            <td>Trung Bình</td>
                            <td>Kém</td>
                          </tr>
                          <tr>
                            <td>MS word</td>
                            <td><input type="checkbox" value="1" name="ms_word" <?php if(old('ms_word') == 1 ||  $detailDiploma->ms_word == 1): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="2" name="ms_word" <?php if(old('ms_word') == 2 ||  $detailDiploma->ms_word == 2): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="3" name="ms_word" <?php if(old('ms_word') == 3 ||  $detailDiploma->ms_word == 3): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="4" name="ms_word" <?php if(old('ms_word') == 4 ||  $detailDiploma->ms_word == 4): ?> checked <?php endif; ?>></td>
                          </tr>
                          <tr>
                            <td>MS Excel</td>
                            <td><input type="checkbox" value="1" name="ms_excel" <?php if(old('ms_excel') == 1 ||  $detailDiploma->ms_excel == 1): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="2" name="ms_excel" <?php if(old('ms_excel') == 2 || $detailDiploma->ms_excel == 2): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="3" name="ms_excel" <?php if(old('ms_excel') == 3 || $detailDiploma->ms_excel == 3): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="4" name="ms_excel" <?php if(old('ms_excel') == 4 || $detailDiploma->ms_excel == 4): ?> checked <?php endif; ?>></td>
                          </tr>
                          <tr>
                            <td>MS Power Point</td>
                            <td><input type="checkbox" value="1" name="ms_power_point" <?php if(old('ms_power_point') == 1 || $detailDiploma->ms_power_point == 1): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="2" name="ms_power_point" <?php if(old('ms_power_point') == 2 || $detailDiploma->ms_power_point == 2): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="3" name="ms_power_point" <?php if(old('ms_power_point') == 3 || $detailDiploma->ms_power_point == 3): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="4" name="ms_power_point" <?php if(old('ms_power_point') == 4 || $detailDiploma->ms_power_point == 4): ?> checked <?php endif; ?>></td>
                          </tr>
                          <tr>
                            <td>MS Outlook</td>
                            <td><input type="checkbox" value="1" name="ms_outlook" <?php if(old('ms_outlook') == 1 || $detailDiploma->ms_outlook == 1): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="2" name="ms_outlook" <?php if(old('ms_outlook') == 2 || $detailDiploma->ms_outlook == 2): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="3" name="ms_outlook" <?php if(old('ms_outlook') == 3 || $detailDiploma->ms_outlook == 3): ?> checked <?php endif; ?>></td>
                            <td><input type="checkbox" value="4" name="ms_outlook"> <?php if(old('ms_outlook') == 4 || $detailDiploma->ms_outlook == 4): ?> checked <?php endif; ?></td>
                          </tr>
                        </table>
                      </div>
                      </div>
                      <hr>
                      <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                      <label for="others">Kỹ Năng Khác</label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                      <div class="form-group">
                          <input type="text" name="others" id="others" class="form-control" value="<?php echo old('others',$detailDiploma->others); ?>">
                          <span style="color:red"><?php echo $errors->first('others'); ?></span>
                        </div>
                      </div>
                </div>
                <div class="modal-footer text-center">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Hủy</button>
        <button type="submit" class="btn btn-primary">Lưu</button>
      </div>
                </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<?php if($errors->first('company') || $errors->first('position') || $errors->first('wage') || $errors->first('description_job') || $errors->first('achieve')): ?>
<script type="text/javascript">
  $('#modal-company').modal('show');
</script>
<?php endif; ?>

<?php if($errors->first('level') || $errors->first('school_name') || $errors->first('description_diploma') || $errors->first('loai_tn') || $errors->first('language') || $errors->first('language_level')): ?>
<script type="text/javascript">
  $('#modal-level').modal('show');
</script>
<?php endif; ?>

<?php if($errors->first('intro')): ?>
<script type="text/javascript">
  $('#modal-intro').modal('show');
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
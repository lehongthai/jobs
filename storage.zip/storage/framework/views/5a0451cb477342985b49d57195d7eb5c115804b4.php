<?php $__env->startSection('body_right'); ?>

<?php if(Session::has('flash_message_action')): ?>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <div class="alert alert-success">
        <?php echo Session::get('flash_message_action'); ?>

    </div>
</div>
<?php endif; ?>
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example-tags">
                        <thead>
                            <tr align="center">
                                <th>STT</th>
                                <th>Tên</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($data as $index => $item): ?>
                            <tr class="odd gradeX" align="center">
                                <td><?php echo $index + 1; ?></td>
                                <td><?php echo $item['name']; ?></td>
                                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo route('admin.catepost.getDelete', $item['id']); ?>"> Delete</a></td> 
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
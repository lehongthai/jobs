<?php
use App\Info;
$footer = Info::getFooter();
?>

<div class="row copyright">
  <div class="col-md-12 text-center">
          <p>
            <small class="block">&copy; 2016 By ThaiLe.</small> 
            <small class="block">Designed by ThaiLe</small>
          </p>
          <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
            Địa chỉ: <?php echo $footer->location; ?>

          </div>
          <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
            <ul style="list-style: none">
              <li>Phone: <?php echo $footer->phone; ?></li>
              <li>Email: <?php echo $footer->email; ?></li>
              <li>FB: <?php echo $footer->facebook; ?></li>
          </ul>
          </div>
          
          
  </div>
</div>
<?php use App\Common; ?>

<?php $__env->startSection('title', 'Hồ sơ ' . Auth::user()->fullname); ?>
<?php $__env->startSection('content'); ?>
<?php /* add menu user */ ?>
<?php echo $__env->make('page.blocks.menu_bottom_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end menu user */ ?>
<div class="row" style="margin-top: 100px">
<section id="title">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 text-center">
				<h3><?php echo $infoResume->title; ?></h3>
				<h6>Duyệt tin: <?php echo Carbon\Carbon::parse($infoResume->time_duyet)->format('d/m/Y'); ?> - Lượt xem: <?php echo $infoResume->view; ?></h6>
			</div>
		</div>
	</div>
</section>
<hr>
	<div class="col-sm-8">
		<article>
		<h2>Chi tiết hồ sơ</h2>
		<div class="col-sm-4">
			<a onclick="return false;" class="thumbnail">
				<img src="<?php echo url('public\upload\avatar\\') . Auth::user()->avatar; ?>" alt="" class="pull-left" />
			</a>
		</div>
		<div class="col-sm-8">
		<table>
			<tr>
				<th>Họ Tên:</th>
				<td><?php echo Auth::user()->fullname; ?></td>
			</tr>
			<tr>
				<th>Ngày sinh:</th>
				<td><?php echo Carbon\Carbon::parse($infoResume->birthday)->format('d/m/Y'); ?></td>
			</tr>
			<tr>
				<th>Giới Tính:</th>
				<td>
				<?php if(Auth::user()->sex == 1): ?>
				Nam
				<?php elseif(Auth::user()->sex == 2): ?>
				Nữ
				<?php else: ?>
				Chưa xác định
				<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th>Email liên hệ: </th>
				<td><?php echo Auth::user()->email; ?></td>
			</tr>
			<tr>
				<th>Điện Thoại:</th>
				<td><?php echo Auth::user()->phone; ?></td>
			</tr>
			<tr>
				<th>Địa chỉ:</th>
				<td><?php echo Auth::user()->address; ?></td>
			</tr>
		</table>
		</div>
		<hr><hr><hr>
			<h3>Thông tin chung</h3>
			<ul>
				<li><strong>Ngành nghề: </strong><?php echo Common::getTypeNameById($infoResume->type); ?>.</li>
				<li><strong>Loại việc làm: </strong>
				<?php $arrJob = explode(',', str_replace('^', '', $infoResume->jobs_wish)); ?>
				<?php foreach($arrJob as $k => $job): ?>
					<?php echo Common::getJobNameById($job); ?>

					<?php if($k != (count($arrJob) - 1)): ?>
                    ,
                    <?php endif; ?>
                 <?php endforeach; ?>
				.</li>
				<li><strong>Nơi làm việc</strong>
				<?php $arrProvin = explode(',', str_replace('^', '', $infoResume->provin_wish)); ?>
				<?php foreach($arrProvin as $k => $provin): ?>
					<?php echo Common::getProvinNameById($provin); ?>

					<?php if($k != (count($arrProvin) - 1)): ?>
                    ,
                    <?php endif; ?>
                 <?php endforeach; ?>
				.</li>
				<li><strong>Số năm kinh nghiệm: </strong><?php echo Common::getNameById($infoResume->empirical); ?>.</li>
				<li><strong>Cấp bậc hiện tại: </strong><?php echo Common::getNameById($infoResume->diploma); ?>.</li>
				<li><strong>Cấp bậc mong muốn: </strong><?php echo Common::getNameById($infoResume->diploma_wish); ?>.</li>
				<li><strong>Trình độ cao nhất: </strong><?php echo Common::getNameById($infoResume->level); ?>.</li>
				<li><strong>Nhu cầu làm việc: </strong><?php echo Common::getNameById($infoResume->exigency); ?>.</li>
				<li><strong>Tiền lương mong muốn: </strong><?php echo number_format($infoResume->wage,0,",","."); ?>.</li>
			</ul>
			<h3>Giới thiệu về bản thân</h3>
				<div class="row work-experience">
				<p style="margin-left: 15px;"><?php echo $infoResume->description; ?></p>
				</div>
				<h3>Trình độ học vấn</h3>
					<div class="row work-experience">
						<div class="col-sm-2">
							<div class="img-circle">
								<i class="fa fa-graduation-cap"></i>
							</div>
						</div>
						<div class="col-sm-10">
						<ul>
							<li> <strong>Trình độ: </strong><span><?php echo Common::getNameById($infoDetailResume->level);; ?></span></li>
							<li> <strong>Đơn vị đào tạo: </strong><span><?php echo $infoDetailResume->school_name; ?></span></h6>
							<li> <strong>Thời gian đào tạo: </strong><?php echo $infoDetailResume->start_time_school . 'Đến' . $infoDetailResume->end_time_school; ?></li>
							<li> <strong>Chuyên ngành: </strong><?php echo $infoDetailResume->description_diploma; ?></li>
							<li> <strong>Loại tốt nghiệp: </strong><?php echo Common::getNameById($infoDetailResume->loai_tn);; ?></li>
							<?php if(isset($infoDetailResumeDiploma->language) && $infoDetailResumeDiploma->language != NULL): ?>
							<li><strong>Ngoại ngữ: </strong><?php echo Common::getNameById($infoDetailResumeDiploma->language);; ?><br>
								<strong>Trình độ ngoại ngữ: </strong><?php echo Common::getNameById($infoDetailResumeDiploma->language_level);; ?><br>
								<table class="table table-bordered">
								<tr>
									<th>Nghe</th>
									<th>Nói</th>
									<th>Đọc</th>
									<th>Viết</th>
								</tr>
								<tr>
									<td><?php echo Common::getTypeLanguageAndTech($infoDetailResumeDiploma->listen);; ?></td>
									<td><?php echo Common::getTypeLanguageAndTech($infoDetailResumeDiploma->speak);; ?></td>
									<td><?php echo Common::getTypeLanguageAndTech($infoDetailResumeDiploma->read);; ?></td>
									<td><?php echo Common::getTypeLanguageAndTech($infoDetailResumeDiploma->write);; ?></td>
								</tr>
							</table>
							</li>
							<?php endif; ?>

							<li><strong>Tin học văn phòng: </strong>
							<table class="table table-bordered">
								<tr>
									<?php if($infoDetailResumeDiploma->ms_word != NULL): ?> <th>MS word</th> <?php endif; ?>
									<?php if($infoDetailResumeDiploma->ms_excel != NULL): ?> <th>MS Excel</th> <?php endif; ?>
									<?php if($infoDetailResumeDiploma->ms_power_point != NULL): ?> <th>MS Power Point</th> <?php endif; ?>
									<?php if($infoDetailResumeDiploma->ms_outlook != NULL): ?> <th>MS Outlook</th> <?php endif; ?>
								</tr>
								<tr>
									<?php if($infoDetailResumeDiploma->ms_word != NULL): ?> <td><?php echo Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_word);; ?></td> <?php endif; ?>
									<?php if($infoDetailResumeDiploma->ms_excel != NULL): ?> <td><?php echo Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_excel);; ?></td> <?php endif; ?>
									<?php if($infoDetailResumeDiploma->ms_power_point != NULL): ?> <td><?php echo Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_power_point);; ?></td> <?php endif; ?>
									<?php if($infoDetailResumeDiploma->ms_outlook != NULL): ?> <td><?php echo Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_outlook);; ?></td> <?php endif; ?>
								</tr>
							</table>
							</li>
							<li><strong>Kỹ năng khác: </strong><?php echo $infoDetailResumeDiploma->others;; ?></li>
						</ul>
						</div>
					</div>
				<h3>Kinh nghiệm làm việc</h3>
					<div class="row work-experience">
						<div class="col-sm-2">
							<div class="img-circle">
								<i class="fa fa-briefcase"></i>
							</div>
						</div>
						<div class="col-sm-10">
						<h4>Tên công ty: </h4><h5><?php echo $infoDetailResume->company;; ?></h5>
						<h4>Giới thiệu công ty: </h4><p><?php echo $infoDetailResume->intro;; ?></p>
						<ul>
							<li><strong>Vị trí: </strong><?php echo $infoDetailResume->position;; ?></li>
							<li><strong>Thời gian: </strong><?php echo $infoDetailResume->start_time . ' Đến ' . $infoDetailResume->end_time;; ?></li>
							<?php if($infoDetailResume->wage != NULL): ?>
							<li><strong>Mức Lương: </strong><?php echo number_format($infoDetailResume->wage,0,",",".");; ?></li>
							<?php endif; ?>
						</ul>
						<strong>Mô tả công việc: </strong><p><?php echo $infoDetailResume->description_job;; ?></p>
						<strong>Thành tích công việc: </strong><p><?php echo $infoDetailResume->achieve;; ?></p>
						</div>
					</div>
							<p>&nbsp;</p>
							<a href="<?php echo url('ung-vien/in-ho-so/'. $infoResume->user_id); ?>" class="btn btn-primary btn-lg" target="_blank"><i class="fa fa-arrow-down"></i>In hồ sơ</a>
							<?php if(isset($message) && $message == 'success'): ?>
							<a href="<?php echo url('ung-vien/ho-so-ca-nhan'); ?>" class="btn btn-warning btn-lg pull-right" target="_blank">Cập nhật hồ sơ</a>
							<?php endif; ?>
						</article>
					</div>
					<div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('page.blocks.loginInline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* add menu user */ ?>
<?php echo $__env->make('page.blocks.menu_bottom_employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end menu user */ ?>
<div class="row" style="margin-top: -100px">
<div class="col-sm-8">
<form action="<?php echo url('nha-tuyen-dung/cap-nhat-ho-so-da-luu'); ?>" method="POST" class="form-horizontal" role="form">
 <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
  <input type="hidden" name="id" value="<?php echo $infoSaveResume->id; ?>">
        <div class="form-group">
            <legend>Cập nhật hồ sơ đã lưu</legend>
        </div>
        <div class="form-group">
            <label>Công Việc</label>
            <select name="job" class="form-control">
                <option value="">-- Chọn công việc --</option>
                <?php foreach($listJob as $k => $job): ?>
                <option value="<?php echo $job->id; ?>">-- <?php echo $job->title; ?> --</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Trạng thái</label>
            <table>
                        <ul>
                            <li><div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="1" <?php if($infoSaveResume->da_lien_he == 1): ?> checked <?php endif; ?> name="da_lien_he">
                                        Đã liên hệ
                                    </label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="1" <?php if($infoSaveResume->da_phong_van == 1): ?> checked <?php endif; ?> name="da_phong_van">
                                        Đã phỏng vấn
                                    </label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="1" <?php if($infoSaveResume->da_test == 1): ?> checked <?php endif; ?> name="da_test">
                                        Đã test
                                    </label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="1" <?php if($infoSaveResume->trung_tuyen == 1): ?> checked <?php endif; ?> name="trung_tuyen">
                                        Trúng tuyển
                                    </label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="1" <?php if($infoSaveResume->tu_choi == 1): ?> checked <?php endif; ?> name="tu_choi">
                                        Từ chối
                                    </label>
                                </div>
                            </li>
                        </ul>
                    </table>
        </div>
        <div class="form-group">
        <label>Ghi chú</label>
        <textarea name="note" class="form-control" rows="3"><?php echo old('note', $infoSaveResume->note); ?></textarea>
        </div>
        <div class="form-group">
            <div class="col-sm-10 col-sm-offset-2">
                <button type="submit" class="btn btn-primary">Cập nhật</button>
            </div>
        </div>
</form>

</div>
 <div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindResume', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo url('public/admin'); ?>/js/select2.min.js"></script>
<script type="text/javascript">
    $('.multiple-select2').select2({
        maximumSelectionLength: 3,
        "language": "pt-BR"
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section id="companies" class="color1">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h2>Doanh Nghiệp Tuyển Dụng</h2>
            <ul id="featured-companies" class="row">
              <li class="col-sm-4 col-md-3">
                <a href="company.html">
                  <img src="images/logo01.jpg" alt="" />
                  <span class="badge">12</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('page.blocks.loginInline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* add menu user */ ?>
<?php echo $__env->make('page.blocks.menu_bottom_employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end menu user */ ?>
<div class="row" style="margin-top: -100px">
<div class="col-sm-8">
<?php echo $__env->make('page.blocks.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<form enctype="multipart/form-data" method="post" action="<?php echo url('nha-tuyen-dung/tai-khoan'); ?>" id="form-register-employer">
        <input type="hidden" name="_token" id="input_token" class="form-control" value="<?php echo csrf_token(); ?>">

<div class="row">
  <h4>Thông Tin Đăng Nhập</h4>
  <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
    <label>Email</label><span class="require">*</span>
  </div>
  <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
    <div class="form-group">
                  <p style="color:red"><strong><?php echo $infoEmployer->email; ?></strong></p>
    </div>
  </div>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
  <div class="form-group">
 <button type="button" class="btn btn-large btn-block btn-danger" onclick="window.location='<?php echo url('nha-tuyen-dung/thay-doi-mat-khau'); ?>'">Đổi mật khẩu</button>
              </div>
</div>
</div>
<div class="row">
<h4>Thông Tin Công Ty</h4>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Tên Công Ty</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">
                <p style="color:red"><strong><?php echo $infoCompany->name; ?></strong></p>
</div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Địa Chỉ</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="companyAddress" class="form-control" value="<?php echo old('companyAddress', $infoCompany->address); ?>">
                <span style="color:red"><?php echo $errors->first('companyAddress'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Số Điện Thoại</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="companyPhone" class="form-control" value="<?php echo old('companyPhone', $infoCompany->phone); ?>">
                <span style="color:red"><?php echo $errors->first('companyPhone'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Tỉnh / Thành Phố</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">
                <select name="companyProvin" class="form-control">
                  <option value="">-- Vui lòng chọn --</option>
                  <?php foreach($listProvin as $key => $provin): ?>
                  <option value="<?php echo $provin->id; ?>" <?php if(old('companyProvin') == $provin->id || $infoCompany->provin == $provin->id): ?> selected <?php endif; ?>>-- <?php echo $provin->name; ?> --</option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('companyProvin'); ?></span>
               
  </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Quy Mô</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">
<select name="companyQuyMo" class="form-control">
                  <option value="">-- Vui lòng chọn --</option>
                  <?php foreach($listQuyMo as $key => $quymo): ?>
                  <option value="<?php echo $quymo->id; ?>" <?php if(old('companyQuyMo') == $quymo->id || $infoCompany->quy_mo == $quymo->id): ?> selected <?php endif; ?>>-- <?php echo $quymo->name; ?> --</option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('companyQuyMo'); ?></span>
  </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Sơ Lượt Về Công Ty</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

  <textarea name="companyIntro" id="inputCompanyIntro" class="form-control" rows="8" ><?php echo old('companyIntro', $infoCompany->so_luot); ?></textarea>
    <span style="color:red"><?php echo $errors->first('companyIntro'); ?></span>
  </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Fax</label>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="companyFax" class="form-control" value="<?php echo old('companyFax', $infoCompany->fax); ?>">
                <span style="color:red"><?php echo $errors->first('companyFax'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>WebSite</label>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="companyWebsite" class="form-control" value="<?php echo old('companyWebsite', $infoCompany->website); ?>">
                <span style="color:red"><?php echo $errors->first('companyWebsite'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Logo công ty</label>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">
  <a class="thumbnail">
    <img id="targetLogo1" alt="logo" src="<?php echo url('public\upload\company\\'). $infoCompany->logo; ?>" alt="<?php echo $infoCompany->name; ?>" />
  </a>
    <input type='file' id="imgLogo" name="imageLogo" value="<?php echo old('imageLogo'); ?>" />
     <span style="color:red"><?php echo $errors->first('imageLogo'); ?></span>
  </div>
</div>

</div>
<hr>
<div class="row">
<h4>Thông Tin Liên Hệ</h4>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Tên Người Liên Hệ</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="addName" class="form-control" value="<?php echo old('addName', $infoAddCompany->name); ?>">
                <span style="color:red"><?php echo $errors->first('addName'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Email</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="email" name="addEmail" class="form-control" value="<?php echo old('addEmail', $infoAddCompany->email); ?>">
                <span style="color:red"><?php echo $errors->first('addEmail'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Điện Thoại</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="addPhone" class="form-control" value="<?php echo old('addPhone', $infoAddCompany->phone); ?>">
                <span style="color:red"><?php echo $errors->first('addPhone'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Điạ chỉ</label>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">
<textarea name="addAddress" class="form-control" rows="8" ><?php echo old('addAddress', $infoAddCompany->address); ?></textarea>
                <span style="color:red"><?php echo $errors->first('addAddress'); ?></span>
              </div>
</div>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
  <div class="form-group">
 <button type="submit" class="btn btn-large btn-block btn-success">Cập nhật</button>
</div>
</div>
</div>
</form>
</div>
 <div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindResume', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo url('public/admin'); ?>/js/select2.min.js"></script>
<script type="text/javascript">
    /*logo company*/
function readURL(input) {
  if (input.files && input.files[0]) {
            var reader = new FileReader();            
            reader.onload = function (e) {
                $('#targetLogo1').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imgLogo").change(function(){
        readURL(this);
    });
</script>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
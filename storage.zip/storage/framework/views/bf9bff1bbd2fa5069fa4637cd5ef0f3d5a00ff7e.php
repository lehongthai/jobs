<?php $__env->startSection('content'); ?>

<div class="row" style="margin-top: 100px">
<div class="col-sm-8">
<?php echo $__env->make('page.blocks.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div role="tabpanel">
<ul class="nav nav-pills nav-justified">
								<li role="presentation" class="active"><a href="#work" aria-controls="work" role="tab" data-toggle="tab">Người tìm việc</a></li>
								<li role="presentation"><a href="#fun" aria-controls="fun" role="tab" data-toggle="tab">Nhà tuyển dụng</a></li>
							</ul>
<div class="text-center"><span class="text-center" style="color:red" id="info-register"></span></div>
 <hr>
							<!-- Tab panes -->
							<div class="tab-content">
								<div role="tabpanel" class="tab-pane active" id="work">
									
 <ul class="social-login">
            <li><a href="<?php echo url('facebook/redirect'); ?>" class="btn btn-facebook"><i class="fa fa-facebook"></i>Đăng Ký Với Facebook</a></li>
            <li><a href="<?php echo url('google/redirect'); ?>" class="btn btn-google"><i class="fa fa-google-plus"></i>Đăng Ký Với Google</a></li>
          </ul>
        <form method="post" action="<?php echo url('user/register'); ?>" id="form-register">
        <input type="hidden" name="_token" id="input_token" class="form-control" value="<?php echo csrf_token(); ?>">
        <input type="hidden" name="typeUser" class="form-control" value="1">
         
          <div class="text-center"><h3>Người Tìm Việc Đăng Ký</h3></div>

          <div class="row">
            <div class="col-sm-6">
            <div class="form-group">
                <label>Họ Tên</label><span class="require">*</span>
                <input type="text" class="form-control" id="login-username" name="fullname" value="<?php echo old('fullname'); ?>">
                <span style="color:red"><?php echo $errors->first('fullname'); ?></span>
              </div>
              <div class="form-group">
                <label>Số Điện Thoại</label><span class="require">*</span>
                <input type="text" class="form-control" name="phone" value="<?php echo old('phone'); ?>">
                <span style="color:red"><?php echo $errors->first('phone'); ?></span>
              </div>
              <div class="form-group">
                <label>Email</label><span class="require">*</span>
                <input type="email" class="form-control" name="email" value="<?php echo old('email'); ?>">
                <span style="color:red"><?php echo $errors->first('email'); ?></span>
              </div>
              <div class="form-group">
                <label for="login-password">Mật Khẩu</label><span class="require">*</span>
                <input type="password" class="form-control" id="login-password" name="passwordRegister" >
                <span style="color:red"><?php echo $errors->first('passwordRegister'); ?></span>
              </div>
              <div class="form-group">
                <label>Nhập Lại Mật Khẩu</label><span class="require">*</span>
                <input type="password" class="form-control" name="password_confirm" >
                <span style="color:red"><?php echo $errors->first('password_confirm'); ?></span>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label>Ngày Sinh</label><span class="require">*</span>

                <input type="date" name="birthday" class="form-control" value="<?php echo old('birthday'); ?>">
                <span style="color:red"><?php echo $errors->first('birthday'); ?></span>
              </div>
              <div class="form-group">
                <label>Giới Tính</label><span class="require">*</span>
                <select name="sex" id="inputSex" class="form-control">
                  <option value="">-- Select One --</option>
                  <option value="1" <?php if(old('sex') == 1): ?> selected <?php endif; ?>>-- Nam --</option>
                  <option value="2" <?php if(old('sex') == 2): ?> selected <?php endif; ?>>-- Nữ --</option>
                </select>
                <span style="color:red"><?php echo $errors->first('sex'); ?></span>
              </div>
              <div class="form-group">
                <label>Tỉnh/ Thành Phố</label><span class="require">*</span>
                <select name="provin" id="inputSex" class="form-control">
                  <option value="">-- Vui lòng chọn --</option>
                  <?php foreach($listProvin as $key => $provin): ?>
                  <option value="<?php echo $provin->id; ?>" <?php if(old('provin') == $provin->id): ?> selected <?php endif; ?>>-- <?php echo $provin->name; ?> --</option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('provin'); ?></span>
              </div>
              <div class="form-group">
                <label>Địa Chỉ</label><span class="require">*</span>
                <textarea name="address" id="input" class="form-control" rows="3"><?php echo old('address'); ?></textarea>
                <span style="color:red"><?php echo $errors->first('address'); ?></span>
              </div>
            </div>
            
          </div>
          <h5 style="color: red">Điều khoản dịch vụ</h5>
          <div class="demo-scroll">
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>

              <div class="checkbox">
                <label>
                  <input type="checkbox" value="1" name="rules" id="isAgeSelected">
                  Tôi đồng ý
                </label>
              </div>
            </div>
          <div class="text-center">
	          <button type="button" id="button-register" class="btn btn-primary">Đăng ký</button>
	        </div>
        </form>
								</div>
								<div role="tabpanel" class="tab-pane" id="fun">
		<form enctype="multipart/form-data" method="post" action="<?php echo url('user/registerEmployer'); ?>" id="form-register-employer">
        <input type="hidden" name="_token" id="input_token" class="form-control" value="<?php echo csrf_token(); ?>">
<input type="hidden" name="typeUser" class="form-control" value="2">
         
          <div class="text-center"><h3>Nhà Tuyển Dụng Đăng Ký</h3><span class="require" id="info-register"></span></div>
<div class="row">
  <h4>Thông Tin Đăng Nhập</h4>
  <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
    <label>Email</label><span class="require">*</span>
  </div>
  <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
    <div class="form-group">

                  <input type="email" name="emailEmployer" class="form-control" value="<?php echo old('emailEmployer'); ?>">
                  <span style="color:red"><?php echo $errors->first('emailEmployer'); ?></span>
    </div>
  </div>
  <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
    <label>Mật Khẩu</label><span class="require">*</span>
  </div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="password" name="passwordEmployer" class="form-control" value="<?php echo old('passwordEmployer'); ?>">
                <span style="color:red"><?php echo $errors->first('passwordEmployer'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Nhập Lại Mật Khẩu</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="password" name="passwordEmployerConfirm" class="form-control" value="<?php echo old('passwordEmployerConfirm'); ?>">
                <span style="color:red"><?php echo $errors->first('passwordEmployerConfirm'); ?></span>
              </div>
</div>
</div>
<hr>
<div class="row">
<h4>Thông Tin Công Ty</h4>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Tên Công Ty</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="companyName" class="form-control" value="<?php echo old('companyName'); ?>">
                <span style="color:red"><?php echo $errors->first('companyName'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Địa Chỉ</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="companyAddress" class="form-control" value="<?php echo old('companyAddress'); ?>">
                <span style="color:red"><?php echo $errors->first('companyAddress'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Số Điện Thoại</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="companyPhone" class="form-control" value="<?php echo old('companyPhone'); ?>">
                <span style="color:red"><?php echo $errors->first('companyPhone'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Tỉnh / Thành Phố</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">
                <select name="companyProvin" class="form-control">
                  <option value="">-- Vui lòng chọn --</option>
                  <?php foreach($listProvin as $key => $provin): ?>
                  <option value="<?php echo $provin->id; ?>" <?php if(old('companyProvin') == $provin->id): ?> selected <?php endif; ?>>-- <?php echo $provin->name; ?> --</option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('companyProvin'); ?></span>
               
  </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Quy Mô</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">
<select name="companyQuyMo" class="form-control">
                  <option value="">-- Vui lòng chọn --</option>
                  <?php foreach($listQuyMo as $key => $quymo): ?>
                  <option value="<?php echo $quymo->id; ?>" <?php if(old('companyQuyMo') == $quymo->id): ?> selected <?php endif; ?>>-- <?php echo $quymo->name; ?> --</option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('companyQuyMo'); ?></span>
  </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Sơ Lượt Về Công Ty</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

  <textarea name="companyIntro" id="inputCompanyIntro" class="form-control" rows="8" ><?php echo old('companyIntro'); ?></textarea>
    <span style="color:red"><?php echo $errors->first('companyIntro'); ?></span>
  </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Fax</label>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="companyFax" class="form-control" value="<?php echo old('companyFax'); ?>">
                <span style="color:red"><?php echo $errors->first('companyFax'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>WebSite</label>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="companyWebsite" class="form-control" value="<?php echo old('companyWebsite'); ?>">
                <span style="color:red"><?php echo $errors->first('companyWebsite'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Logo công ty</label>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">
  <a class="thumbnail">
    <img id="targetLogo1" alt="logo" src="">
  </a>
    <input type='file' id="imgLogo" name="imageLogo" value="<?php echo old('imageLogo'); ?>" />
     <span style="color:red"><?php echo $errors->first('imageLogo'); ?></span>
  </div>
</div>

</div>
<hr>
<div class="row">
<h4>Thông Tin Liên Hệ</h4>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Tên Người Liên Hệ</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="addName" class="form-control" value="<?php echo old('addName'); ?>">
                <span style="color:red"><?php echo $errors->first('addName'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Email</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="email" name="addEmail" class="form-control" value="<?php echo old('addEmail'); ?>">
                <span style="color:red"><?php echo $errors->first('addEmail'); ?></span>
              </div>
</div>
<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
  <label>Điện Thoại</label><span class="require">*</span>
</div>
<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
  <div class="form-group">

                <input type="text" name="addPhone" class="form-control" value="<?php echo old('addPhone'); ?>">
                <span style="color:red"><?php echo $errors->first('addPhone'); ?></span>
              </div>
</div>
</div>
<h5 style="color: red">Điều khoản dịch vụ cho nhà tuyển dụng</h5>
          <div class="demo-scroll">
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>
              <p>Donec sodales nunc libero, placerat finibus felis suscipit a. Vestibulum dignissim augue non urna porta posuere. Nam aliquet augue nec orci porttitor posuere. Nunc egestas pulvinar est bibendum hendrerit.</p>

              <div class="checkbox">
                <label>
                  <input type="checkbox" value="1" name="rulesCompany" <?php if(old('rulesCompany') == 1): ?> checked <?php endif; ?> id="isAgeSelectedCompany">
                  Tôi đồng ý
                </label>
              </div>
            </div>
          <div class="text-center">
            <button type="button" id="button-register-company" class="btn btn-primary">Đăng ký</button>
          </div>
        </form>
								</div>
							</div>

						</div>


    </div>
<div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
$( "#button-register" ).click(function() {
  $('#isAgeSelected').each(function () {
        if($(this).is(':checked')){
            $('#form-register').submit();
        }
    });
    document.getElementById("info-register").innerHTML = "Chưa chấp nhận điều khoản của chúng tôi";
});

$( "#button-register-company" ).click(function() {
  $('#isAgeSelectedCompany').each(function () {
        if($(this).is(':checked')){
            $('#form-register-employer').submit();
        }
    });
    document.getElementById("info-register").innerHTML = "Chưa chấp nhận điều khoản của chúng tôi";
});

function activaTab(tab){
    $('.nav-pills a[href="#' + tab + '"]').tab('show');
};
<?php if(old('typeUser') == 2): ?>
activaTab('fun');
<?php else: ?>
activaTab('work');
<?php endif; ?>

/*logo company*/
function readURL(input) {
  if (input.files && input.files[0]) {
            var reader = new FileReader();            
            reader.onload = function (e) {
                $('#targetLogo1').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imgLogo").change(function(){
        readURL(this);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
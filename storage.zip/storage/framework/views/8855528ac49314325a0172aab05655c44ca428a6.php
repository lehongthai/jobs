<?php
$uri = Request::segment(2);
?>
<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation" style="height: 10px;">
  <div class="container">
    <ul class="nav navbar-nav">
    <li <?php if($uri == 'tai-khoan'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('nha-tuyen-dung/tai-khoan'); ?>">Tài Khoản</a>
      </li>
    <li <?php if($uri == 'tim-ho-so'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('nha-tuyen-dung/tim-ho-so'); ?>">Tìm Hồ Hơ</a>
      </li>
      <li <?php if($uri == 'trang-tuyen-dung'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('trang-tuyen-dung'); ?>" target="_blank">Trang Tuyển Dụng</a>
      </li>
      <li <?php if($uri == 'dang-tin-tuyen-dung'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('nha-tuyen-dung/dang-tin-tuyen-dung'); ?>">Đăng Tin Tuyển Dụng</a>
      </li>
      <li <?php if($uri == 'quan-ly-tin-tuyen-dung'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('nha-tuyen-dung/quan-ly-tin-tuyen-dung'); ?>">Quản Lý Tin Tuyển Dụng</a>
      </li>
      <li <?php if($uri == 'ho-so-da-luu'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('nha-tuyen-dung/ho-so-da-luu'); ?>">Hồ Sơ Đã Lưu</a>
      </li>
      <li <?php if($uri == 'ho-so-ung-tuyen'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('nha-tuyen-dung/ho-so-ung-tuyen'); ?>">Hồ Sơ Ứng Tuyển</a>
      </li>
      <li <?php if($uri == 'giay-phep-kinh-doanh'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('nha-tuyen-dung/giay-phep-kinh-doanh'); ?>">Giấy Phép Kinh Doanh</a>
      </li>
      <li <?php if($uri == 'trang-tuyen-dung'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('logout'); ?>">Đăng Xuất</a>
      </li>
    </ul>
  </div>
</nav>
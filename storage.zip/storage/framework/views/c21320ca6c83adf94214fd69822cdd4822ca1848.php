<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('page.blocks.loginInline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* add menu user */ ?>
<?php echo $__env->make('page.blocks.menu_bottom_employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end menu user */ ?>
<div class="row" style="margin-top: -100px">
<div class="col-sm-8">
<?php echo $__env->make('page.blocks.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<form method="post" action="<?php echo url('ung-vien/thay-doi-mat-khau'); ?>">
  <input type="hidden" name="_token" id="input_token" class="form-control" value="<?php echo csrf_token(); ?>">

<div class="row">
  <h2>Thay đổi mật khẩu</h2>
  <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
    <label>Mật khẩu cũ</label><span class="require">*</span>
  </div>
  <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
    <div class="form-group">
        <input type="password" name="passwordOld" class="form-control">
        <span style="color:red"><?php echo $errors->first('passwordOld'); ?></span>
        <?php if(Session::has('flash_message_password_error')): ?>
        <span style="color:red"><?php echo Session::get('flash_message_password_error'); ?></span>
        <?php endif; ?>
    </div>
  </div>
  <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
    <label>Mật khẩu mới</label><span class="require">*</span>
  </div>
  <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
    <div class="form-group">
        <input type="password" name="passwordNew" class="form-control">
        <span style="color:red"><?php echo $errors->first('passwordNew'); ?></span>
    </div>
  </div>
  <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
    <label>Nhập lại mật khẩu</label><span class="require">*</span>
  </div>
  <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
    <div class="form-group">
        <input type="password" name="passwordNewConfirm" class="form-control">
        <span style="color:red"><?php echo $errors->first('passwordNewConfirm'); ?></span>
    </div>
  </div>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
  <div class="form-group">
 <button type="submit" class="btn btn-large btn-block btn-danger">Đổi mật khẩu</button>
</div>
</div>
</div>
</form>
</div>
  <div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('body_right'); ?>

    <div class="col-lg-11" style="padding-bottom:120px">
        <form action="<?php echo route('admin.provin.postEdit'); ?>" method="POST">
        <div class="pull-right">
            <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon glyphicon-floppy-save" aria-hidden="true"></span> Lưu Lại</button>
            <button type="button" class="btn btn-primary" onclick="window.location='<?php echo url('admin/provin/list'); ?>'"><span class="glyphicon glyphicon-backward" aria-hidden="true"></span> Cancel</button>
        </div>
        <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
            <div class="form-group">
                <label>Tên</label>
                <input class="form-control" name="txtName" placeholder="Vui lòng nhập tiêu đề" value="<?php echo old('txtName', $data['name']); ?>" />
                <div style="color:red"><?php echo $errors->first('txtName'); ?></div>
            </div>
            <div class="form-group">
                <label>Chọn Miền</label>
                <select class="form-control" name="txtCompass">
                    <option value="">Vui Lòng Chọn</option>
                    <option value="1" <?php if(old('txtCompass') == 1 || $data['compass'] == 1): ?> selected  <?php endif; ?>>Miền Nam</option>
                    <option value="2" <?php if(old('txtCompass') == 2 || $data['compass'] == 2): ?> selected  <?php endif; ?>>Miền Trung</option>
                    <option value="3" <?php if(old('txtCompass') == 3 || $data['compass'] == 3): ?> selected  <?php endif; ?>>Miền Bắc</option>
                </select>
                <div style="color:red"><?php echo $errors->first('txtCompass'); ?></div>
             </div>
            <div class="form-group">
                <label>Keywords</label>
                <input class="form-control" name="txtKeyword" placeholder="Vui lòng nhập Keywords" value="<?php echo old('txtKeyword', $data['keywords']); ?>" />
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" rows="3" name="txtDescription"><?php echo old('txtDescription', $data['description']); ?></textarea>
            </div>
            <div class="form-group">
                <div class="radio">
                    <label>
                        <input type="radio" name="txtSearch" id="inputSearch" value="1" <?php if(old('search') == 1 || $data['search'] == 1): ?> checked="checked" <?php endif; ?>>
                        Search
                    </label>
                    <label>
                        <input type="radio" name="txtSearch" id="inputSearch" value="0"  <?php if(old('search') == 2 || $data['search'] == 2): ?> checked="checked" <?php endif; ?>>
                        Không Search
                    </label>
                </div>
                
            </div>
        <form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
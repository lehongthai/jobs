<?php
use App\Common; 
?>

<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('page.blocks.loginInline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row" style="margin-top: -180px">
          <div class="col-sm-8">
            <h2>Câu hỏi thường gặp</h2>

           <div class="panel-group" id="accordion">
           <?php foreach($listAq as $k => $aq): ?>
              <div class="panel panel-primary">
                <div class="panel-heading">
                  <h4 class="panel-title">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne<?php echo $k+1; ?>">
                      <?php echo $k+1 . '  -  ' . $aq->answer; ?>

                      <i class="indicator glyphicon <?php if($k == 0): ?> glyphicon-chevron-up <?php else: ?> glyphicon-chevron-down <?php endif; ?> pull-right"></i>
                    </a>
                  </h4>
                </div>
                <div id="collapseOne<?php echo $k+1; ?>" class="panel-collapse collapse <?php if($k == 0): ?> in <?php endif; ?>">
                  <div class="panel-body">
                    <?php echo $aq->question; ?>

                  </div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>

          </div>
          <div class="col-sm-4" id="sidebar">
            <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <!-- Find a Job End -->

          </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
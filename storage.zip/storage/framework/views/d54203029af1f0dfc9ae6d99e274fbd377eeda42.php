<?php $__env->startSection('body_right'); ?>
    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
            <tr align="center">
                <th>STT</th>
                <th>Tên</th>
                <th>Danh Mục</th>
                <th>Giá</th>
                <th>Ngày</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
        <?php if($data && $data != NULL): ?>
        <?php foreach($data as $index => $product): ?>
            <tr class="odd gradeX" align="center">
                <td><?php echo $index + 1; ?></td>
                <td><?php echo $product['pName']; ?></td>
                <td><?php echo $product['cName']; ?>

                <td><?php echo number_format($product['price']) ?></td>
                <td><?php echo \Carbon\Carbon::createFromTimeStamp(strtotime($product['created_at']))->diffForHumans();?></td>
                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo route('admin.product.getEdit', $product['id']); ?>">Edit</a></td>
                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo route('admin.product.getDelete', $product['id']); ?>"> Delete</a></td>
            </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
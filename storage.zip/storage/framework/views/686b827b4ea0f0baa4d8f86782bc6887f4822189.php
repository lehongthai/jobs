<?php
use App\Common; 
?>

<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('page.blocks.loginInline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row" style="margin-top: -180px">
          <div class="col-sm-8">
            <h2><?php echo $title; ?></h2>

            <div class="jobs">
             <?php foreach($listJob as $k => $sJob): ?>
             <div class="custom-find-job">
                <div class="title">
                <a href="<?php echo url('cong-viec/'. $sJob->alias . '-' . $sJob->id . '.html'); ?>">
                  <h5><?php echo $sJob->title; ?></h5>
                  </a>
                  <a href="<?php echo url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($sJob->employer_id)) . '-' . $sJob->employer_id . '.html'); ?>">
                  <p><?php echo Common::getCompanyNameById($sJob->employer_id);; ?></p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                  <?php $arrProvinRelated = explode(',', str_replace('^', '', $sJob->provin)); ?>
                  <?php foreach($arrProvinRelated as $ke => $provin): ?>
                    <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                    <?php echo Common::getProvinNameById($provin); ?>

                    </a>
                    <?php if($ke != (count($arrProvinRelated) - 1)): ?>,<?php endif; ?>
                  <?php endforeach; ?>
                  </span>
                  <span class="type part-time"><i class="fa fa-clock-o"></i>
                  <?php echo Common::getTypeNameById($sJob->type); ?>

                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i><?php echo Common::getNameById($sJob->wage); ?></span>
                </div>
              </div>
              <?php endforeach; ?>
              
            </div>

            <nav>
              <ul class="pagination">
                <li <?php if($listJob->currentPage() == 1): ?> class="disabled" onclick="return false;" <?php endif; ?>><a href="<?php echo str_replace('/?', '?', $listJob->url($listJob->currentPage() - 1)); ?>" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
              
              <?php for($i=1; $i<=$listJob->lastPage(); $i++): ?>
                <li class="<?php echo ($listJob->currentPage() == $i) ? 'active' : ''; ?>">
                <a href="<?php echo str_replace('/?', '?', $listJob->url($i)); ?>"><?php echo $i; ?></a></li>
              <?php endfor; ?>
             
                <li <?php if($listJob->currentPage() == $listJob->lastPage()): ?> class="disabled" onclick="return false;" <?php endif; ?>>
                <a href="<?php echo str_replace('/?', '?', $listJob->url($listJob->currentPage() + 1)); ?>" aria-label="Next"><span aria-hidden="true">&raquo;</span></a>
                </li>
              
              </ul>
            </nav>

          </div>
          <div class="col-sm-4" id="sidebar">
           
            <!-- Featured Jobs End -->

            <!-- Find a Job Start -->
            <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <!-- Find a Job End -->

          </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
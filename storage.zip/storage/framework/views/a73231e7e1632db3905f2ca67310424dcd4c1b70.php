<?php $__env->startSection('body_right'); ?>
                    <div class="col-lg-7" style="padding-bottom:120px">
                        <form action="<?php echo route('admin.catepost.getEdit'); ?>" method="POST">
                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                        <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
                            <div class="form-group">
                                <label>Tên Danh Mục</label>
                                <input class="form-control" name="txtCateName" placeholder="Tên Danh Mục" value="<?php echo old('txtCateName', $data['name']); ?>" />
                                <div style="color:red"><?php echo $errors->first('txtCateName'); ?></div>
                            </div>
                            <div class="form-group">
                                <label>Đường Dẫnc</label>
                                <input class="form-control" name="txtUrl" placeholder="Đường Dẫn" value="<?php echo old('txtUrl', $data['url']); ?>" />
                                <div style="color:red"><?php echo $errors->first('txtUrl'); ?></div>
                            </div>
                            <div class="form-group">
                                <label>Vị Trí</label>
                                <input class="form-control" name="txtOrder" placeholder="Vị Trí" value="<?php echo old('txtOrder', $data['order']); ?>" />
                            </div>
                            <!-- <div class="form-group">
                                <label>Keywords</label>
                                <input class="form-control" name="txtKeywords" placeholder="Keywords" value="<?php echo old('txtKeywords', $data['meta_key']); ?>" />
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea class="form-control" rows="3" name="txtDescription"><?php echo old('txtDescription', $data['meta_desc']); ?></textarea>
                            </div>
                             -->
                            <button type="submit" class="btn btn-default">Cập Nhật</button>
                            <button type="reset" class="btn btn-default">Reset</button>
                        <form>
                    </div>
<?php $__env->stopSection(); ?>            
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
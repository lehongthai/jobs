<?php $__env->startSection('title', $project->title); ?>
<?php $__env->startSection('description', $project->description); ?>
<?php $__env->startSection('keywords', $project->keywords); ?>
<?php $__env->startSection('about'); ?>
<div class="row">
        <div class="col-md-10">
              <div class="inner">
                <div class="desc">
                <h2 class="text-center" ><?php echo $project->title; ?></h2>
                <h4><?php echo $project->intro; ?></h4>
                <p><?php echo $project->content; ?></p>
              </div>
              </div>
          </a>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php
use App\Info, App\Common;
$seo = Info::getSeo();
?>



<?php $__env->startSection('title', $seo->title); ?>
<?php $__env->startSection('description', $seo->meta_desc); ?>
<?php $__env->startSection('keywords', $seo->meta_key); ?>

<?php /* Start Slider */ ?>
<?php $__env->startSection('slider'); ?>
<div id="slider" class="sl-slider-wrapper">

      <div class="sl-slider">
      <?php foreach($listSlider as $k => $slider): ?>
      <?php if($k%2 == 0): ?>
        <div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-25" data-slice2-rotation="-25" data-slice1-scale="2" data-slice2-scale="2">
          <div class="sl-slide-inner">
            <div class="bg-img" style="background-image:url(<?php echo $slider->image_link; ?>)"></div>
            <div class="tint"></div>
            <div class="slide-content">
              <h2><?php echo $slider->title; ?></h2>
              <h3><?php echo $slider->intro; ?></h3>
              <p><a href="<?php echo url('bai-viet/' . $slider->alias . '-' . $slider->id . '.html'); ?>" class="btn btn-lg btn-default">Xem chi tiết</a></p>
            </div>
          </div>
        </div>
      <?php else: ?>
        <div class="sl-slide" data-orientation="vertical" data-slice1-rotation="10" data-slice2-rotation="-15" data-slice1-scale="1.5" data-slice2-scale="1.5">
          <div class="sl-slide-inner">
            <div class="bg-img" style="background-image:url(<?php echo $slider->image_link; ?>)"></div>
            <div class="tint"></div>
            <div class="slide-content">
              <h2><?php echo $slider->title; ?></h2>
              <h3><?php echo $slider->intro; ?></h3>
              <p><a href="<?php echo url('bai-viet/' . $slider->alias . '-' . $slider->id . '.html'); ?>" class="btn btn-lg btn-default">Xem chi tiết</a></p>
            </div>
          </div>
        </div>
        <?php endif; ?>
        <?php endforeach; ?>
      </div>

      <nav id="nav-arrows" class="nav-arrows">
        <span class="nav-arrow-prev">Previous</span>
        <span class="nav-arrow-next">Next</span>
      </nav>

      <nav id="nav-dots" class="nav-dots">
        <span class="nav-dot-current"></span>
        <span></span>
        <span></span>
        <span></span>
      </nav>

    </div>
<?php $__env->stopSection(); ?>
<?php /* End Slider */ ?>

<?php /* Start News Jobs */ ?>
<?php $__env->startSection('newsJobs'); ?>
<?php echo $__env->make('page.blocks.news_job', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php /* End News Jobs */ ?>

<?php /* Start colRight */ ?>
<?php $__env->startSection('colRight'); ?>
<?php echo $__env->make('page.blocks.colRight', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php /* End colRight */ ?>

<?php $__env->startSection('content'); ?>
<div class="row">
          <div class="col-sm-8">
  <div role="tabpanel">

              <!-- Nav pills -->
              <ul class="nav nav-pills nav-justified">
                <li role="presentation" class="active"><a href="#work" aria-controls="work" role="tab" data-toggle="tab">Việc Hot</a></li>
                <li role="presentation"><a href="#fun" aria-controls="fun" role="tab" data-toggle="tab">Việc Lương Cao</a></li>
                <li role="presentation"><a href="#life" aria-controls="life" role="tab" data-toggle="tab">Việc Gấp</a></li>
                <li role="presentation"><a href="#life2" aria-controls="life" role="tab" data-toggle="tab">Việc Mới</a></li>
              </ul>

              <!-- Tab panes -->
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="work">

            <div class="jobs">
              <?php foreach($hotJob as $k => $hJob): ?>
              <!-- Job offer 1 -->
              <?php if($k <= 2): ?>
              <div class="custom-find-job">
              <?php endif; ?>
                <div class="featured"></div>
                <div class="title">
                <a href="<?php echo url('cong-viec/'. $hJob->alias . '-' . $hJob->id . '.html'); ?>">
                  <h5><?php echo $hJob->title; ?></h5>
                  </a>
                  <a href="<?php echo url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($hJob->employer_id)) . '-' . $hJob->employer_id . '.html'); ?>">
                  <p><?php echo Common::getCompanyNameById($hJob->employer_id); ?></p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                    <?php $arrProvinRelated = explode(',', str_replace('^', '', $hJob->provin)); ?>
                    <?php foreach($arrProvinRelated as $ke => $provin): ?>
                   <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                    <?php echo Common::getProvinNameById($provin); ?>

                    </a>
                    <?php if($ke != (count($arrProvinRelated) - 1)): ?>
                    ,
                    <?php endif; ?>
                  <?php endforeach; ?>
                  </span>
                  <span class="type full-time"><i class="fa fa-clock-o"></i>
                  <?php echo Common::getTypeNameById($hJob->type); ?>

                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i>
                  <?php echo Common::getNameById($hJob->wage); ?>

                  </span>
                </div>
              </div>
              <?php endforeach; ?>
            </div>

            <a class="btn btn-primary" href="<?php echo url('viec-lam-hot'); ?>">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="fun">
                  <div class="jobs">
              <?php foreach($highJob as $k => $hwJob): ?>
              <!-- Job offer 1 -->
              <?php if($k <= 2): ?>
              <div class="custom-find-job">
              <?php endif; ?>
                <div class="featured"></div>
                <div class="title">
                <a href="<?php echo url('cong-viec/'. $hwJob->alias . '-' . $hwJob->id . '.html'); ?>">
                  <h5><?php echo $hwJob->title; ?></h5>
                  </a>
                  <a href="<?php echo url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($hwJob->employer_id)) . '-' . $hwJob->employer_id . '.html'); ?>">
                  <p><?php echo Common::getCompanyNameById($hwJob->employer_id); ?></p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                    <?php $arrProvinRelated = explode(',', str_replace('^', '', $hwJob->provin)); ?>
                    <?php foreach($arrProvinRelated as $ke => $provin): ?>
                   <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                    <?php echo Common::getProvinNameById($provin); ?>

                    </a>
                    <?php if($ke != (count($arrProvinRelated) - 1)): ?>
                    ,
                    <?php endif; ?>
                  <?php endforeach; ?>
                  </span>
                  <span class="type full-time"><i class="fa fa-clock-o"></i>
                  <?php echo Common::getTypeNameById($hwJob->type); ?>

                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i>
                  <?php echo Common::getNameById($hwJob->wage); ?>

                  </span>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
            <a class="btn btn-primary" href="<?php echo url('viec-lam-luong-cao'); ?>">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="life">
                  <div class="jobs">
              <?php foreach($gapJob as $k => $gJob): ?>
              <!-- Job offer 1 -->
              <?php if($k <= 2): ?>
              <div class="custom-find-job">
              <?php endif; ?>
                <div class="featured"></div>
                <div class="title">
                <a href="<?php echo url('cong-viec/'. $gJob->alias . '-' . $gJob->id . '.html'); ?>">
                  <h5><?php echo $gJob->title; ?></h5>
                  </a>
                  <a href="<?php echo url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($gJob->employer_id)) . '-' . $gJob->employer_id . '.html'); ?>">
                  <p><?php echo Common::getCompanyNameById($gJob->employer_id); ?></p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                    <?php $arrProvinRelated = explode(',', str_replace('^', '', $gJob->provin)); ?>
                    <?php foreach($arrProvinRelated as $ke => $provin): ?>
                   <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                    <?php echo Common::getProvinNameById($provin); ?>

                    </a>
                    <?php if($ke != (count($arrProvinRelated) - 1)): ?>
                    ,
                    <?php endif; ?>
                  <?php endforeach; ?>
                  </span>
                  <span class="type full-time"><i class="fa fa-clock-o"></i>
                  <?php echo Common::getTypeNameById($gJob->type); ?>

                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i>
                  <?php echo Common::getNameById($gJob->wage); ?>

                  </span>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
            <a class="btn btn-primary" href="<?php echo url('viec-lam-dang-gap'); ?>">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="life2">
                  <div class="jobs">
              <?php foreach($newJob as $k => $nJob): ?>
              <!-- Job offer 1 -->
              <?php if($k <= 2): ?>
              <div class="custom-find-job">
              <?php endif; ?>
                <div class="featured"></div>
                <div class="title">
                <a href="<?php echo url('cong-viec/'. $nJob->alias . '-' . $nJob->id . '.html'); ?>">
                  <h5><?php echo $nJob->title; ?></h5>
                  </a>
                  <a href="<?php echo url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($nJob->employer_id)) . '-' . $nJob->employer_id . '.html'); ?>">
                  <p><?php echo Common::getCompanyNameById($nJob->employer_id); ?></p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                    <?php $arrProvinRelated = explode(',', str_replace('^', '', $nJob->provin)); ?>
                    <?php foreach($arrProvinRelated as $ke => $provin): ?>
                   <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                    <?php echo Common::getProvinNameById($provin); ?>

                    </a>
                    <?php if($ke != (count($arrProvinRelated) - 1)): ?>
                    ,
                    <?php endif; ?>
                  <?php endforeach; ?>
                  </span>
                  <span class="type full-time"><i class="fa fa-clock-o"></i>
                  <?php echo Common::getTypeNameById($nJob->type); ?>

                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i>
                  <?php echo Common::getNameById($nJob->wage); ?>

                  </span>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
            <a class="btn btn-primary" href="<?php echo url('viec-lam-moi'); ?>">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
              </div>

            </div>

</div>
          <div class="col-sm-4">
          <h2>Nhà tuyển dụng nổi bật</h2>
          <?php foreach($companyJobs as $k => $company): ?>
            <div> 
            
              <div class="featured-job">
              <a href="<?php echo url('cong-ty/'. $company->alias . '-' . $company->id . '.html'); ?>">
                <p class="thumbnail">
                <img src="<?php echo url('public\upload\company\\'). $company->logo; ?>" alt="<?php echo $company->name; ?>" />
                </p>
                <div class="title">
                  <h5><?php echo $company->name; ?></h5>
                </div>
                </a>
                <div class="data">
                  <strong>Điạ Chỉ: </strong><p><?php echo $company->address; ?></p>
                  <strong>Điện Thoại: </strong><p><?php echo $company->phone; ?></p>
                  <strong>Website: </strong><a href="http://<?php echo $company->website; ?>" target="_blank"><?php echo $company->website; ?></a>
                </div>
                <div class="description"><?php echo $company->so_luot; ?></div>
              </div>
            </div>
            <hr>
            <?php endforeach; ?>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php /* DOANH NGHIỆP TUYỂN DỤNG */ ?>
<?php $__env->startSection('companies'); ?>
<section id="companies" class="color1">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h2>Doanh Nghiệp Tuyển Dụng</h2>
            <ul id="featured-companies" class="row">
            <?php foreach($companyTuyenDung as $k => $tuyenDung): ?>
              <li class="col-sm-4 col-md-3">
                <a href="<?php echo url('cong-ty/'. $tuyenDung->alias . '-' . $tuyenDung->id . '.html'); ?>">
                  <img src="<?php echo url('public\upload\company\\'). $tuyenDung->logo; ?>" alt="<?php echo $tuyenDung->name; ?>" />
                  <span class="badge"><?php echo $tuyenDung->total; ?></span>
                </a>
              </li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>
      </div>
</section>
<?php $__env->stopSection(); ?>
<?php /* END DOANH NGHIỆP TUYỂN DỤNG */ ?>


<?php /* JOBSEEK STATS */ ?>
<?php $__env->startSection('stats'); ?>
<?php echo $__env->make('page.blocks.stats', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php /* END JOBSEEK STATS */ ?>

<?php /* Start Client */ ?>
<?php $__env->startSection('clients'); ?>
<?php echo $__env->make('page.blocks.clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php /* END Client */ ?>
<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
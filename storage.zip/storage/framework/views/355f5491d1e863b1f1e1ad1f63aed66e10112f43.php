<?php
use App\Common; 
$listJob = Common::getJob();
$listProvin = Common::getProvin();
$listLevel = Common::getLevel();
$listEmpirical = Common::getEmpirical();
$listWage = Common::getWage();
$listExigency = Common::getExigency();
$listType = Common::getType();
?>

<h2>Tìm kiếm việc làm</h2>
<form action="<?php echo url('tim-kiem'); ?>" method="get" role="form">
<input type="hidden" name="_token" id="input_token" class="form-control" value="<?php echo csrf_token(); ?>">
  <div class="form-group">
    <input type="text" class="form-control" name="title" placeholder="Nhập từ khóa" <?php if(isset($_GET['title'])): ?> value="<?php echo $_GET['title']; ?>" <?php endif; ?>>
  </div>
  <div class="form-group">
    <select name="job" class="form-control">
      <option value="">-- Công Việc --</option>
      <?php foreach($listJob as $job): ?>
      <option value="<?php echo $job->id; ?>" <?php if(isset($_GET['job']) && $_GET['job'] == $job->id): ?> selected <?php endif; ?>>-- <?php echo $job->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('job'); ?></span>
  </div>
  <div class="form-group">
    <select name="provin" class="form-control">
      <option value="">-- Địa Điểm --</option>
      <?php foreach($listProvin as $provin): ?>
      <option value="<?php echo $provin->id; ?>" <?php if(isset($_GET['provin']) && $_GET['provin'] == $provin->id): ?> selected <?php endif; ?>>-- <?php echo $provin->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('provin'); ?></span>
  </div>
  <div class="form-group">
    <select name="level" class="form-control">
      <option value="">-- Bằng Cấp --</option>
      <?php foreach($listLevel as $level): ?>
      <option value="<?php echo $level->id; ?>" <?php if(isset($_GET['level']) && $_GET['level'] == $level->id): ?> selected <?php endif; ?>>-- <?php echo $level->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('level'); ?></span>
  </div>
  <div class="form-group">
    <select name="wage" class="form-control">
      <option value="">-- Mức Lương --</option>
      <?php foreach($listWage as $wage): ?>
      <option value="<?php echo $wage->id; ?>" <?php if(isset($_GET['wage']) && $_GET['wage'] == $wage->id): ?> selected <?php endif; ?>>-- <?php echo $wage->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('wage'); ?></span>
  </div>
  <div class="form-group">
    <select name="sex" class="form-control">
      <option value="0">-- Không yêu cầu --</option>
      <option value="1" <?php if(isset($_GET['sex']) && $_GET['sex'] == 1): ?> selected <?php endif; ?>>-- Nam --</option>
      <option value="2" <?php if(isset($_GET['sex']) && $_GET['sex'] == 2): ?> selected <?php endif; ?>>-- Nữ --</option>
    </select>
    <span style="color:red"><?php echo $errors->first('sex'); ?></span>
  </div>
  <div class="form-group">
    <select name="type" class="form-control">
      <option value="">-- Hình Thức làm Việc --</option>
      <?php foreach($listType as $type): ?>
      <option value="<?php echo $type->id; ?>" <?php if(isset($_GET['type']) && $_GET['type'] == $type->id): ?> selected <?php endif; ?>>-- <?php echo $type->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('type'); ?></span>
  </div>
  <div class="form-group">
    <select name="empirical" class="form-control">
      <option value="">-- Kinh Nghiệm --</option>
      <?php foreach($listEmpirical as $empirical): ?>
      <option value="<?php echo $empirical->id; ?>" <?php if(isset($_GET['empirical']) && $_GET['empirical'] == $empirical->id): ?> selected <?php endif; ?>>-- <?php echo $empirical->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('empirical'); ?></span>
  </div>
  <button type="submit" class="btn btn-primary">Tìm Kiếm</button>
</form>
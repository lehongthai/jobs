  <!-- ============ CONTACT START ============ -->

    <section id="contact" class="color2">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <h2>Liên hệ với chúng tôi</h2>
            <form role="form" action="<?php echo url('lien-he'); ?>" method="post">
            <input type="hidden" name="_token" id="input_token" class="form-control" value="<?php echo csrf_token(); ?>">
              <div class="form-group" id="contact-name-group">
                <label for="contact_name" class="sr-only">Họ và tên</label>
                <input type="text" class="form-control" id="contact_name" name="contact_name" placeholder="Họ và tên" value="<?php echo old('contact_name'); ?>">
                <span style="color:red"><?php echo $errors->first('contact_name'); ?></span>
              </div>
              <div class="form-group" id="contact-email-group">
                <label for="contact_email" class="sr-only">Email</label>
                <input type="email" class="form-control" id="contact_email" name="contact_email" placeholder="Email" value="<?php echo old('contact_email'); ?>">
                <span style="color:red"><?php echo $errors->first('contact_email'); ?></span>
              </div>
              <div class="form-group" id="contact-subject-group">
                <label for="contact_subject" class="sr-only">Tiêu đề</label>
                <input type="text" class="form-control" id="contact_subject" name="contact_subject" placeholder="Tiêu đề" value="<?php echo old('contact_subject'); ?>">
                <span style="color:red"><?php echo $errors->first('contact_subject'); ?></span>
              </div>
              <div class="form-group" id="contact-message-group">
                <label for="contact_message" class="sr-only">Nội dung</label>
                <textarea class="form-control" rows="3" id="contact_message" name="contact_message"><?php echo old('contact_message'); ?></textarea>
                <span style="color:red"><?php echo $errors->first('contact_message'); ?></span>
              </div>
              <button type="submit" class="btn btn-default">Gửi</button>
            </form>
          </div>
          <div class="col-sm-6">
            <h2>Visit our office</h2>
            <div class="row">
              <div class="col-sm-6">
                <h5>New York</h5>
                <p>5 Park Avenue<br>
                New York, NY 10016<br>
                USA</p>
                <p><i class="fa fa-phone"></i>+1 718.242.5555<br>
                <i class="fa fa-fax"></i>+1 718.242.5556<br>
                <i class="fa fa-envelope"></i><a href="mailto:ny@jobseek.com">ny@jobseek.com</a></p>
                <p><i class="fa fa-clock-o"></i>Mon-Fri 9am - 5pm<br>
                <i class="fa fa-clock-o"></i>Sat 10am - 2pm<br>
                <i class="fa fa-clock-o"></i>Sun Closed</p>
              </div>
              <div class="col-sm-6">
                <h5>Los Angeles</h5>
                <p>8605 Santa Monica Blvd<br>
                Los Angeles, CA 90069-4109<br>
                USA</p>
                <p><i class="fa fa-phone"></i>+1 985.562.5555<br>
                <i class="fa fa-fax"></i>+1 985.562.5556<br>
                <i class="fa fa-envelope"></i><a href="mailto:la@jobseek.com">la@jobseek.com</a></p>
                <p><i class="fa fa-clock-o"></i>Mon-Fri 9am - 5pm<br>
                <i class="fa fa-clock-o"></i>Sat 10am - 2pm<br>
                <i class="fa fa-clock-o"></i>Sun Closed</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ============ CONTACT END ============ -->

    

    <!-- ============ FOOTER START ============ -->

    <footer>
      <div id="prefooter">
        <div class="container">
          <div class="row">
            <div class="col-sm-6" id="newsletter">
              <h2>Newsletter</h2>
              <form class="form-inline">
                <div class="form-group">
                  <label class="sr-only" for="newsletter-email">Email address</label>
                  <input type="email" class="form-control" id="newsletter-email" placeholder="Email address">
                </div>
                <button type="submit" class="btn btn-primary">Sign up</button>
              </form>
            </div>
            <div class="col-sm-6" id="social-networks">
              <h2>Get in touch</h2>
              <a href="#"><i class="fa fa-2x fa-facebook-square"></i></a>
              <a href="#"><i class="fa fa-2x fa-twitter-square"></i></a>
              <a href="#"><i class="fa fa-2x fa-google-plus-square"></i></a>
              <a href="#"><i class="fa fa-2x fa-youtube-square"></i></a>
              <a href="#"><i class="fa fa-2x fa-vimeo-square"></i></a>
              <a href="#"><i class="fa fa-2x fa-pinterest-square"></i></a>
              <a href="#"><i class="fa fa-2x fa-linkedin-square"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div id="credits">
        <div class="container text-center">
          <div class="row">
            <div class="col-sm-12">
              &copy; 2015 Jobseek - Responsive Job Board HTML Template<br>
              Designed &amp; Developed by <a href="http://themeforest.net/user/Coffeecream" target="_blank">Coffeecream Themes</a>
            </div>
          </div>
        </div>
      </div>
    </footer>

    <!-- ============ FOOTER END ============ -->

    <!-- ============ LOGIN START ============ -->

    <div class="popup" id="login">
      <?php echo $__env->make('page.blocks.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <!-- ============ LOGIN END ============ -->

    <!-- ============ REGISTER START ============ -->

      <?php echo $__env->make('page.blocks.register', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- ============ REGISTER END ============ -->
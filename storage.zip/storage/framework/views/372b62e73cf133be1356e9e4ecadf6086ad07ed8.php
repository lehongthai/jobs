<?php $__env->startSection('body_right'); ?>

                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr align="center">
                                <th>ID</th>
                                <th>Vị Trí</th>
                                <th>Email</th>
                                <th>Số Bàn</th>
                                <th>Di Động</th>
                                <th>FB</th>
                                <th>Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($shop as $index => $item): ?>
                            <tr class="odd gradeX" align="center">
                                <td><?php echo $index + 1; ?></td>
                                <td><?php echo $item['location']; ?></td>
                                <td><?php echo $item['email']; ?></td>
                                <td><?php echo $item['tel']; ?></td>
                                <td><?php echo $item['phone']; ?></td>
                                <td><?php echo $item['facebook']; ?></td>
                                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo URL::route('admin.about.getEditShop', $item['id']); ?>">Edit</a></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
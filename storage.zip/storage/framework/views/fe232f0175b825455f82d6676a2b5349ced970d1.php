<?php
$uri = Request::segment(2);
?>
<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation" style="height: 10px;">
  <div class="container">
    <a class="navbar-brand" href="<?php echo url('ung-vien/tai-khoan'); ?>"><?php echo Auth::user()->fullname; ?></a>
    <ul class="nav navbar-nav">
      <li <?php if($uri == 'ho-so-ca-nhan' || $uri == 'ho-so'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('ung-vien/ho-so'); ?>">Hồ Sơ</a>
      </li>
      <li <?php if($uri == 'viec-lam-da-luu'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('ung-vien/viec-lam-da-luu'); ?>">Việc Làm Đã Lưu</a>
      </li>
      <li <?php if($uri == 'viec-lam-ung-tuyen'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('ung-vien/viec-lam-ung-tuyen'); ?>">Việc Làm Ứng Tuyển</a>
      </li>
      <li <?php if($uri == 'nha-tuyen-dung-xem'): ?> class="active" <?php endif; ?>>
        <a href="<?php echo url('ung-vien/nha-tuyen-dung-xem'); ?>">Nhà Tuyển Dụng Xem</a>
      </li>
      <li <?php if($uri == 'trang-tuyen-dung'): ?> class="active" <?php endif; ?>>
        <a href="#">Thông Báo Việc Làm</a>
      </li>
      <li>
        <a href="<?php echo url('logout'); ?>">Đăng Xuất</a>
      </li>
    </ul>
  </div>
</nav>
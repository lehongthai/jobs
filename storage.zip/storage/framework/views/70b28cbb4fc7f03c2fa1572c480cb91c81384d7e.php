<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('body_right'); ?>   
    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
            <tr align="center">
                <td style="display: none"></td>
                <td style="display: none"></td>
                <th>Thứ tự</th>
                <th>Email</th>
                <?php if($url == 'nha-tuyen-dung'): ?>
                <th>Tên công ty</th>
                <?php elseif($url == 'ung-vien'): ?>
                <th>Tên ứng viên</th>
                <?php endif; ?>
                <th>Trạng thái tài khoản</th>
                <th>Trạng thái kích hoạt</th>
                <th>Ngày tạo</th>
                <th>Delete</th>   
            </tr>
        </thead>
        <tbody>
        <?php if(isset($listUser) && $listUser != NULL): ?>
        <?php foreach($listUser as $index => $item): ?>
            <tr class="odd gradeX" align="center">
                <td style="display: none"><?php echo $item->id; ?></td>
                <td style="display: none"><?php echo csrf_token(); ?></td>
                <td><?php echo $index+1; ?></td>
                <td><?php echo $item->email; ?></td>
                <?php if($url == 'nha-tuyen-dung'): ?>
                <td>
                    <a href="<?php echo url('admin/quan-ly-thanh-vien/xem-nhanh/') . '/' . $item->alias . '-' . $item->cId . '.html'; ?>" target="_blank">
                        <?php echo $item->name; ?>

                    </a>
                </td>
                <?php elseif($url == 'ung-vien'): ?>
                <td><?php echo $item->fullname; ?></td>
                <?php endif; ?>
                <td>
                    <?php if($item->banded == 1): ?>
                    Đang hoạt động
                    <?php else: ?>
                    Cấm hoạt động
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($item->active == 1): ?>
                    Đã kích hoạt
                    <?php else: ?>
                    Chưa kích hoạt
                    <?php endif; ?>
                </td>
                <td><?php echo Carbon\Carbon::parse($item->create_date)->format('d/m/Y');; ?></td>
                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo url('admin/quan-ly-thanh-vien/xoa-thanh-vien/') . '/' . $item->id; ?>"> Delete</a></td>
            </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

<script src="<?php echo url('public/admin'); ?>/js/jquery.tabledit.js"></script>
<script type="text/javascript">
    $('#dataTables-example').Tabledit({
    url: '<?php echo url('admin/quan-ly-thanh-vien/sua-nhanh'); ?>',
    deleteButton: false,
    columns: {
        identifier: [0, 'id'],
        editable: [[1, '_token'],  [5, 'banded', '{"1": "Hoạt động", "2": "Cấm hoạt động"}']]
    },
    action: 'Sửa Nhanh',
    onDraw: function() {
    },

    onSuccess: function(data, textStatus, jqXHR) {
        window.location.href="<?php echo url('admin/quan-ly-thanh-vien/' . $url); ?>";
    },
    onFail: function(jqXHR, textStatus, errorThrown) {
        $(function() {
        $('#dialog-message').empty();
          $('#dialog-message').append(jqXHR['responseJSON']['code']);
          $( "#dialog-message" ).dialog({
                modal: true,
                buttons: [
                          {
                              text: "OK",
                              click: function() {                     
                                  $(this).dialog("close"); 
                                  var row_fail = $('.danger').index();
                                  $('.tabledit-edit-button')[row_fail].click();
                                  $('input[name="'+ jqXHR['responseJSON']['position_error'] +'"]').focus();
                              }
                          }
                        ]
          });
        });
        },
    onAlways: function() {
    },
    onAjax: function(action, serialize) {
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
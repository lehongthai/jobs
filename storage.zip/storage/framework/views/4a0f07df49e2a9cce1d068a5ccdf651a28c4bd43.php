<?php $__env->startSection('name'); ?>
Danh mục
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
	
@media  screen and (min-width: 940px) {
    .postcontent {
    width: 800px;
	}
}
</style>
			<!-- Post Content
			============================================= -->
			<div class="postcontent nobottommargin col_last" >
				<div class="collection-name">
					Tăng cường sinh lý
				</div>
				<!-- Shop
				============================================= -->
				<div id="shop" class="product-3 clearfix">
					<div class="row sort-wrapper">
</div>
<div id="grid_pagination">
<?php foreach($product as $prod): ?>
	<div class="col-md-3 col-sm-6 col-xs-6">
		<div class="product-item ">
			<div class="product-image">
				<a href="<?php echo e(url('')); ?>/san-pham/<?php echo e($prod->alias); ?>id<?php echo e($prod->id); ?>">

					<img alt="<?php echo e($prod->alt); ?>" data-srcset="<?php echo e($prod->image_link); ?>, <?php echo e($prod->alt); ?>" src="<?php echo e($prod->image_link); ?>" >
				</a>
			</div>
			<div class="product-desc center">
				<div class="product-title"><h3><a href="<?php echo e(url('')); ?>/san-pham/<?php echo e($prod->alias); ?>id<?php echo e($prod->id); ?>"><?php echo e($prod->name); ?></a></h3></div>
				<div class="product-price">
					<ins> <?php echo e(number_format($prod->price, 0,",",".")); ?>đ </ins>
				</div>
				<div class="product-cart">
					<a href="<?php echo e(url('')); ?>/addCartid<?php echo e($prod->id); ?>" class="product_quick_add" title="Mua ngay"> Mua ngay</a>
				</div>
			</div>
		</div>
	</div>
<?php endforeach; ?>



</div>
</div><!-- #shop end -->

</div><!-- .postcontent end -->
			<!-- Sidebar
			============================================= -->
			<div class="sidebar nobottommargin  left-sidebar hidden-sm hidden-xs">
				<div class="sidebar-widgets-wrap">
					<!-- begin: filters -->
					<!-- end: filters -->
					<!-- categories -->



					<!-- <div class="widget widget_links clearfix" id="collection-sub">
						<h4>Danh mục sản phẩm</h4>
						<ul class="sidebar_menu">


							<li class="level0 active"><a href="gel-titan-developpe-sex.html">GEL TITAN SỈ VÀ LẺ</a>
								<i class="icon-angle-down"></i>
								<ul class="sidebar_submenu">

									<li class="level1">
										<a href="gel-titan-developpe-sex.html">Gel titan Developpe sex</a>
									</li>

									<li class="level1">
										<a href="cham-soc-sac-dep.html">Chăm sóc sắc đẹp</a>
									</li>

								</ul>
							</li>

						</ul>
					</div> -->


					<!-- end categories -->

					<!-- recent product -->

					<div class="widget clearfix">

						<h4><a href="sextoy-cho-nu.html">Sản phẩm bán chạy</a></h4>
						<div id="post-list-footer">
						<?php foreach($bestPro as $best): ?>
						
							<div class="spost clearfix">
								<div class="entry-image">
									<a href="<?php echo e(url('')); ?>/san-pham/<?php echo e($best->alias); ?>id<?php echo e($best->id); ?>"><img src="<?php echo e($best->image_link); ?>" alt="<?php echo e($best->name); ?>"></a>
								</div>
								<div class="entry-c">
									<div class="entry-title">
										<h4><a href="<?php echo e(url('')); ?>/san-pham/<?php echo e($best->alias); ?>id<?php echo e($best->id); ?>"><?php echo e($best->name); ?></a></h4>
									</div>
									<ul class="entry-meta">
										<li class="color">
											<ins><?php echo e(number_format($best->price, 0,",",".")); ?>₫</ins>

										</li>
										
									</ul>
								</div>
							</div>
						<?php endforeach; ?>

						</div>
					</div>

					<!-- end recent product -->


					<!-- most popular -->

					<div class="widget clearfix">

						<h4><a href="gel-titan-developpe-sex.html">Sản phẩm nổi bật</a></h4>
						<div id="Popular-item">

						<?php foreach($newPro as $best): ?>
						
							<div class="spost clearfix">
								<div class="entry-image">
									<a href="<?php echo e(url('')); ?>/san-pham/<?php echo e($best->alias); ?>id<?php echo e($best->id); ?>"><img src="<?php echo e($best->image_link); ?>" alt="<?php echo e($best->name); ?>"></a>
								</div>
								<div class="entry-c">
									<div class="entry-title">
										<h4><a href="<?php echo e(url('')); ?>/san-pham/<?php echo e($best->alias); ?>id<?php echo e($best->id); ?>"><?php echo e($best->name); ?></a></h4>
									</div>
									<ul class="entry-meta">
										<li class="color">
											<ins><?php echo e(number_format($best->price, 0,",",".")); ?>₫</ins>

										</li>
										
									</ul>
								</div>
							</div>
						<?php endforeach; ?>

						</div>
					</div>

					<!-- end most popular -->

					<!-- recent view -->

					

					<script>
						var $strHTML = get_viewed_items_html('');    
						$('.widget .widget-last-view').html($strHTML);   

					</script>

					<!-- end recent view -->
					
				</div>
			</div>
			<!-- .sidebar end -->

			<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
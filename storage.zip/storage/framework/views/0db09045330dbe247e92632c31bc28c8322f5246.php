<?php
use App\Common; 
?>


<?php if(isset($detailCompany) && $detailCompany != NULL): ?>
<?php $__env->startSection('title', 'Công việc của ' . $detailCompany->name); ?>
<?php elseif(isset($detailProvin) && $detailProvin != NULL): ?>
<?php $__env->startSection('title', 'Tỉnh-Thành Phố ' . $detailProvin->name); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('page.blocks.loginInline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="row" style="margin-top: -180px">
    <div class="col-sm-8">
    <?php if(isset($detailCompany) && $detailCompany != NULL): ?>
      <h2><?php echo $detailCompany->name; ?></h2>
        <a onclick="return false;" class="thumbnail">
          <img src="<?php echo url('public\upload\company\\') . $detailCompany->logo; ?>" alt="<?php echo $detailCompany->name; ?>">
        </a>
        <strong>Điạ Chỉ: </strong>
        <span><?php echo $detailCompany->address; ?></span><br>
        <strong>Điện Thoại: </strong>
        <span><?php echo $detailCompany->phone; ?></span><br>
        <strong>Website: </strong>
        <a href="http://<?php echo $detailCompany->website; ?>" target="_blank"><?php echo $detailCompany->website; ?></a><br>
        <p><?php echo $detailCompany->so_luot; ?></p>
    <?php endif; ?>
    <?php if(count($listJob) <= 0): ?>
    Không cói mẹ gì cả
    <?php else: ?>
    <div class="jobs">
    <?php foreach($listJob as $k => $sJob): ?>
      <div class="custom-find-job">
        <div class="title">
          <a href="<?php echo url('cong-viec/'. $sJob->alias . '-' . $sJob->id . '.html'); ?>">
            <h5><?php echo $sJob->title; ?></h5>
          </a>
          <a href="<?php echo url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($sJob->employer_id)) . '-' . $sJob->employer_id . '.html'); ?>">
            <p><?php echo Common::getCompanyNameById($sJob->employer_id);; ?></p>
          </a>
        </div>
        <div class="data">
          <span class="city"><i class="fa fa-map-marker"></i>
          <?php $arrProvinRelated = explode(',', str_replace('^', '', $sJob->provin)); ?>
          <?php foreach($arrProvinRelated as $ke => $provin): ?>
            <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
              <?php echo Common::getProvinNameById($provin); ?>

            </a>
            <?php if($ke != (count($arrProvinRelated) - 1)): ?>,<?php endif; ?>
          <?php endforeach; ?>
          </span>
          <span class="sallary"><i class="fa fa-dollar"></i><?php echo Common::getNameById($sJob->wage); ?></span>
          <span class="sallary"><i class="fa fa-calendar"></i><?php echo Carbon\Carbon::parse($sJob->expired_at)->format('d/m/Y'); ?></span>
        </div>
      </div>
    <?php endforeach; ?>
    </div>
<?php 
if (isset($_GET['page'])) 
{
  $page = $_GET['page'];
}

if (!isset($page) || $page == 0) 
{
  $page = 1;
}
?>
            <nav>
              <ul class="pagination">
                <li <?php if($page == 1): ?> class="disabled" onclick="return false;" <?php endif; ?>><a href="<?php echo $url; ?>page=<?php echo $page-1; ?>" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
                <?php for($i = 1; $i <= $totalPagination; $i++): ?>
                <li <?php if($i == $page): ?> class="active" <?php endif; ?>><a href="<?php echo $url; ?>page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                <?php endfor; ?>
                <li <?php if($page >= $totalPagination): ?> class="disabled" onclick="return false;" <?php endif; ?>><a href="<?php echo $url; ?>page=<?php echo $page+1; ?>" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
              </ul>
            </nav>
<?php endif; ?>
          </div>
          <div class="col-sm-4" id="sidebar">

            <!-- Find a Job Start -->
            <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              <?php echo $__env->make('page.blocks.fullFindJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <!-- Find a Job End -->

          </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
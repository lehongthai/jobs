<section id="stats" class="parallax text-center">
      <div class="tint"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h1>Jobseek Stats</h1>
            <h4>How many people we’ve helped</h4>
          </div>
        </div>
        <div class="row" id="counter">
          
          <div class="counter">
            <div class="number">4,329</div>
            <div class="description">Members</div>
          </div>
        
          <div class="counter">
            <div class="number">894</div>
            <div class="description">Jobs</div>
          </div>
        
          <div class="counter">
            <div class="number">1,482</div>
            <div class="description">Resumes</div>
          </div>
        
          <div class="counter">
            <div class="number">83</div>
            <div class="description">Companies</div>
          </div>

        </div>
        <div class="row">
          <div class="col-sm-12">
            <p><a class="link-register btn btn-primary">Join Us</a></p>
          </div>
        </div>
      </div>
    </section>
<?php  
use App\Common;
$infoCompany = Common::getInfoCompanyById($detailJob->employer_id);
$getJobCompany = Common::getJobCompanyById($detailJob->employer_id);
?>
<?php $__env->startSection('title', $detailJob->title); ?>



<?php $__env->startSection('content'); ?>

<div class="row" style="margin-top: 100px">
<section id="title">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <h1><?php echo $detailJob->title; ?></h1><br>
            <h4>
              <span><i class="fa fa-map-marker"></i>
              <?php $arrProvin = explode(',', str_replace('^', '', $detailJob->provin)); ?>
              <?php foreach($arrProvin as $key => $provin): ?>
                  <?php echo Common::getProvinNameById($provin); ?>

                  <?php if($key != (count($arrProvin) - 1)): ?>
                  -
                  <?php endif; ?>
              <?php endforeach; ?>
              </span>
              <span><i class="fa fa-clock-o"></i>
                  <?php echo Common::getTypeNameById($detailJob->type); ?>

              </span>
              <span><i class="fa fa-dollar"></i><?php echo Common::getNameById($detailJob->wage); ?></span>
            </h4>
          </div>
        </div>
      </div>
    </section><hr>
          <div class="col-sm-8">
            <article>
            <div class="alert alert-info">
              <strong>Cập nhật ngày</strong> <?php echo Carbon\Carbon::parse($detailJob->create_date)->format('d/m/Y'); ?> &nbsp; |  &nbsp;
              <strong>Lượt xem</strong> <?php echo $detailJob->view; ?>

            </div>
            <div class="text-center">
              <h3><?php echo $infoCompany->name; ?></h3>
              <p><?php echo $infoCompany->address; ?></p>
            </div>
              <h2>Chi tiết công việc</h2>
              <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                  <ul>
                    <li><strong>Mức lương:</strong> <?php echo $detailJob->wage; ?></li>
                    <li><strong>Kinh nghiệm:</strong> <?php echo Common::getNameById($detailJob->empirical); ?></li>
                    <li><strong>Trình độ:</strong> <?php echo Common::getNameById($detailJob->level); ?></li>
                    <li><strong>Tỉnh/ Thành phố:</strong> 
                    <?php foreach($arrProvin as $key => $provins): ?>
                    <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                        <?php echo Common::getProvinNameById($provins); ?>

                        </a>
                        <?php if($key != (count($arrProvin) - 1)): ?>
                        -
                        <?php endif; ?>
                    <?php endforeach; ?>
                  </li>
                    <li><strong>Ngành nghề:</strong>
                    <?php $arrJobs = explode(',', str_replace('^', '', $detailJob->fields)); ?> 
                    <?php foreach($arrJobs as $key => $jobs): ?>
                    <a href="<?php echo url('viec-lam/'. convert_vi_to_en(Common::getJobNameById($jobs)) . '-' . $jobs . '.html'); ?>">
                        <?php echo Common::getJobNameById($jobs); ?>

                        </a>
                        <?php if($key != (count($arrJobs) - 1)): ?>
                        ,
                        <?php endif; ?>
                    <?php endforeach; ?>
                    </li>
                  </ul>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                  <ul>
                    <li><strong>Số lượng tuyển dụng:</strong> <?php echo $detailJob->quanlity; ?></li>
                    <li><strong>Giới tính:</strong> 
                    <?php if($detailJob->sex == NULL): ?>
                    Không yêu cầu
                    <?php elseif($detailJob->sex == 1): ?>
                    Nam
                    <?php elseif($detailJob->sex == 2): ?>
                    Nữ
                    <?php endif; ?>
                    </li>
                    <li><strong>Tính chất công việc:</strong> <?php echo Common::getNameById($detailJob->attribute); ?></li>
                    <li><strong>Hình thức làm việc:</strong> 
                    <?php echo Common::getTypeNameById($detailJob->type); ?>

                    </li>
                    <li><strong>Hạn chốt:</strong> <?php echo Carbon\Carbon::parse($detailJob->expired_at)->format('d/m/Y'); ?></li>
                  </ul>
                </div>
              </div>
              <h3>Mô tả</h3>
              <?php echo $detailJob->description; ?>

              <h3>Yêu cầu</h3>
              <?php echo $detailJob->require; ?>

              <h3>Lợi ích</h3>
              <?php echo $detailJob->benefit; ?>

              <hr>
              <p>
                <a href="<?php echo url('ung-vien/luu-ho-so/' . $detailJob->id); ?>" class="btn btn-primary btn-lg">Lưu Công Việc</a>
                &nbsp;
                <a href="<?php echo url('ung-vien/nop-ho-so/' . $detailJob->id); ?>" class="btn btn-success btn-lg pull-right">Nộp Hồ Sơ</a>
                &nbsp;
              </p>
            </article>
            <article>
              <h2>Việc làm liên quan</h2>
              <div class="jobs">
              <?php foreach($listRelatedJob as $k => $relatedJob): ?>
              <div class="custom-find-job">
                <div class="title">
                <a href="<?php echo url('cong-viec/'. $relatedJob->alias . '-' . $relatedJob->id . '.html'); ?>">
                  <h5><?php echo $relatedJob->title; ?></h5>
                  </a>
                   <a href="<?php echo url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($relatedJob->employer_id)) . '-' . $relatedJob->employer_id . '.html'); ?>">
                  <p><?php echo Common::getCompanyNameById($relatedJob->employer_id);; ?></p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                  <?php $arrProvinRelated = explode(',', str_replace('^', '', $relatedJob->provin)); ?>
                  <?php foreach($arrProvinRelated as $ke => $provin): ?>
                  <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                    <?php echo Common::getProvinNameById($provin); ?>

                    </a>
                    <?php if($ke != (count($arrProvinRelated) - 1)): ?>,<?php endif; ?>
                  <?php endforeach; ?>
                  </span>
                  <span class="type part-time"><i class="fa fa-clock-o"></i>
                  <?php echo Common::getTypeNameById($relatedJob->type); ?>

                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i><?php echo Common::getNameById($relatedJob->wage); ?></span>
                </div>
              </a>
              </div>
              <?php endforeach; ?>
              </div>
            </article>
          </div>
          <div class="col-sm-4" id="sidebar">
            <div class="sidebar-widget" id="share">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <a onclick="return false;" class="thumbnail">
                <img src="<?php echo url('public\upload\company\\'). $infoCompany->logo; ?>" alt="<?php echo $infoCompany->name; ?>">
              </a>
              <h4><?php echo $infoCompany->name; ?></h4>
              <strong>Điạ Chỉ: </strong><p><?php echo $infoCompany->address; ?></p>
              <strong>Điện Thoại: </strong><p><?php echo $infoCompany->phone; ?></p>
              <strong>Website: </strong><a href="<?php echo $infoCompany->website; ?>" target="_blank"><?php echo $infoCompany->website; ?></a>
            </div>
            </div>
            <div class="sidebar-widget" id="company">
              <h2>Chúng tôi đang tuyển dụng</h2>
              <?php foreach($getJobCompany as $key => $job): ?>
              <a href="<?php echo url('cong-viec/'. $job->alias . '-' . $job->id . '.html'); ?>"><h5><?php echo $job->title; ?></h5></a>
              <ul>
                <li><i class="fa fa-map-marker"></i>
                <?php $arrProvinCompany = explode(',', str_replace('^', '', $job->provin)); ?>
                  <?php foreach($arrProvinCompany as $k => $provins): ?>
                  <?php echo Common::getProvinNameById($provins); ?>

                  <?php if($k != (count($arrProvinCompany) - 1)): ?>
                  ,
                  <?php endif; ?>
              <?php endforeach; ?>
                </li>
                <li style="float: right"><i class="fa fa-dollar"></i><?php echo Common::getNameById($job->wage); ?></li>
              </ul>
              <?php endforeach; ?>
            </div>
            <hr>
            <div class="sidebar-widget" id="company-jobs">
              <?php echo $__env->make('page.blocks.fullFindJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
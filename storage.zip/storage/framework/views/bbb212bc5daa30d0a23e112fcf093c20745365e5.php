<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('body_right'); ?>
    <button type="button" onclick="window.location='<?php echo url('admin/info/add/'.$check); ?>'" class="btn btn-success">Thêm mới</button>
    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
            <tr align="center">
                <th>Thứ tự</th>
                <th>Tên</th>
                <th>Danh mục</th>
                <th>Edit</th>
                <th>Delete</th>   
            </tr>
        </thead>
        <tbody>
        <?php if(isset($data) && $data != NULL): ?>
        <?php foreach($data as $index => $item): ?>
            <tr class="odd gradeX" align="center">
            <td><?php echo $index+1; ?></td>
                <td><?php echo $item->name; ?></td>
                <td>Loại việc làm</td>
                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo URL::route('admin.infouser.getEdit', $item->id); ?>">Edit</a></td>
                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo URL::route('admin.infouser.getDelete', $item->id); ?>"> Delete</a></td>
            </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
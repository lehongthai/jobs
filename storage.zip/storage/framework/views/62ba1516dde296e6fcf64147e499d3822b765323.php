<?php $__env->startSection('body_right'); ?>

                    <table class="table table-striped table-bordered table-hover" id="dataTables-example-tags">
                        <thead>
                            <tr align="center">
                                <th>STT</th>
                                <th>Mã Đơn Hàng</th>
                                <th>Tên</th>
                                <th>SĐT</th>
                                <th>Email</th>
                                <th>Tiền</th>
                                <th>Trạng Thái</th>
                                <th>Xem</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($listCustomer as $index => $customer): ?>
                            <tr class="odd gradeX" align="center">
                                <td><?php echo $index + 1; ?></td>
                                <td><?php echo $customer->code; ?></td>
                                <td><?php echo $customer->fullname .' '. $customer->lastname; ?></td>
                                <td><?php echo $customer->phone; ?></td>
                                <td><?php echo $customer->email; ?></td>
                                <td><?php echo number_format($customer->price); ?></td>
                                <?php if($customer->active != '0' && $customer->active != '1'): ?>
                                <td>Chưa kích hoạt</td>
                                <?php elseif($customer->active != '0' && $customer->active == '1'): ?>
                                <td class="center"><i class="glyphicon glyphicon-ok-circle"></i><a onclick="return confirm_delete('Bạn chắc chắn kích hoạt !')" href="<?php echo route('admin.customer.getActive', $customer->id); ?>">Thanh Toán</a></td>
                                <?php elseif($customer->active == '0'): ?>
                                <td>Đã Thanh Toán</td>
                                <?php else: ?>
                                <td>Không Xác Định</td>
                                <?php endif; ?> 

                                <?php if($customer->viewed == 1): ?>
                                <td>Xem</td>
                                <?php elseif($customer->viewed == 0): ?>
                                <td><a href="<?php echo route('admin.customer.getView', $customer->id); ?>">Chưa</a></td>
                                <?php endif; ?>
                                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo URL::route('admin.customer.getDelete', $customer->id); ?>"> Delete</a></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
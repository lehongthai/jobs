<?php
use App\Common; 
?>

<?php $__env->startSection('title', 'Quản lý tin tuyển dụng'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('page.blocks.loginInline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* add menu user */ ?>
<?php echo $__env->make('page.blocks.menu_bottom_employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end menu user */ ?>
<div class="row" style="margin-top: -100px">
<?php echo $__env->make('page.blocks.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<table class="table table-bordered" id="datatable-savejob">
		<thead>
			<tr style="background-color: #14B1BB">
				<th>Thứ tự</th>
				<th>Tên</th>
				<th>Trạng Thái</th>
				<th>Hết hạn</th>
				<th>Cập Nhật</th>
				<th>Ứng tuyển</th>
				<th>Lượt Xem</th>
				<th>Cập nhật</th>
				<th>Xóa</th>
			</tr>
		</thead>
		<tbody>
		<?php foreach($listPostJob as $key => $postJob): ?>
			<tr>
				<td><?php echo $key + 1; ?></td>
				<td><a href="<?php echo url('cong-viec/' . $postJob->alias . '-' . $postJob->id . '.html'); ?>" target="_blank"><?php echo $postJob->title; ?></a></td>
				<td><?php if($postJob->active == 1): ?>
				Đã Duyệt
				<?php else: ?>
				Chờ Duyệt
				<?php endif; ?>
				</td>
				<td><?php echo Carbon\Carbon::parse($postJob->expired_at)->format('d/m/Y'); ?></td>
				<td><?php echo Carbon\Carbon::parse($postJob->create_date)->format('d/m/Y'); ?></td>
				<td><?php echo Common::countViewJob($postJob->id); ?></td>
				<td><?php echo $postJob->view; ?></td>
				<td><a href="<?php echo url('nha-tuyen-dung/cap-nhat-tin-tuyen-dung/' . $postJob->id); ?>">Cập nhật</a></td>
				<td><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo url('nha-tuyen-dung/xoa-tin-tuyen-dung/' . $postJob->id); ?>">Xóa</a></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo url('public/admin'); ?>/bower_components/DataTables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo url('public/admin'); ?>/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    $('#datatable-savejob').DataTable({
    	"language": {
            "lengthMenu": "Display _MENU_ records per page",
            "zeroRecords": "Không có kết quả nào",
            "info": "Showing page _PAGE_ of _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtered from _MAX_ total records)"
        }
    });
    $(".input-sm").css({
    	height: '40px'
  	});
});
	
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
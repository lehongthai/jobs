<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<?php /* add menu user */ ?>
<?php echo $__env->make('page.blocks.menu_bottom_employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end menu user */ ?>
<div class="row" style="margin-top: 100px">
<?php echo $__env->make('page.blocks.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<table class="table table-bordered" id="datatable-savejob">
		<thead>
			<tr style="background-color: #14B1BB">
				<th>Thứ tự</th>
				<th>Công việc</th>
				<th>Hồ sơ</th>
				<th>Trình độ</th>
				<th>Ngày lưu</th>
				<th>Trạng thái</th>
				<th>Cập nhật</th>
				<th>Xóa</th>
			</tr>
		</thead>
		<tbody>
		<?php foreach($listSaveResume as $key => $saveResume): ?>
			<tr>
				<td><?php echo $key + 1; ?></td>
				<td><a href="<?php echo url('cong-viec/' . $saveResume->pAlias . '-' . $saveResume->pId . '.html'); ?>"><?php echo $saveResume->pTitle; ?></a></td>
				<td><a href="<?php echo url('ho-so/' . $saveResume->cAlias . '-' . $saveResume->cId . '.html'); ?>"><?php echo $saveResume->cTitle; ?></a></td>
				<td><?php echo $saveResume->iName; ?></td>
				<td><?php echo Carbon\Carbon::parse($saveResume->create_date)->format('d/m/Y'); ?></td>
				<td>
					<table>
						<ul>
							<li><div class="checkbox">
									<label>
										<input type="checkbox" <?php if($saveResume->da_lien_he == 1): ?> checked <?php endif; ?>>
										Đã liên hệ
									</label>
								</div>
							</li>
							<li>
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($saveResume->da_phong_van == 1): ?> checked <?php endif; ?>>
										Đã phỏng vấn
									</label>
								</div>
							</li>
							<li>
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($saveResume->da_test == 1): ?> checked <?php endif; ?>>
										Đã test
									</label>
								</div>
							</li>
							<li>
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($saveResume->trung_tuyen == 1): ?> checked <?php endif; ?>>
										Trúng tuyển
									</label>
								</div>
							</li>
							<li>
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($saveResume->tu_choi == 1): ?> checked <?php endif; ?>>
										Từ chối
									</label>
								</div>
							</li>
						</ul>
					</table>
				</td>
				<td><a href="<?php echo url('nha-tuyen-dung/cap-nhat-ho-so-da-luu/' . $saveResume->id); ?>">Cập nhật</a></td>
				<td><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo url('nha-tuyen-dung/xoa-ho-so-da-luu/' . $saveResume->id); ?>">Xóa</a></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo url('public/admin'); ?>/bower_components/DataTables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo url('public/admin'); ?>/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    $('#datatable-savejob').DataTable({
    	"language": {
            "lengthMenu": "Display _MENU_ records per page",
            "zeroRecords": "Không có kết quả nào",
            "info": "Showing page _PAGE_ of _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtered from _MAX_ total records)"
        }
    });
    $(".input-sm").css({
    	height: '40px'
  	});
});
	
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
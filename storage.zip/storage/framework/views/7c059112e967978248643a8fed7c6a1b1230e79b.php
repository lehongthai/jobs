<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('body_right'); ?>   
    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
            <tr align="center">
                <td style="display: none"></td>
                <td style="display: none"></td>
                <th>Tên công việc</th>
                <th>Nhà tuyển dụng</th>
                <th>Kiểm duyệt</th>
                <th>Kiểu việc làm</th>
                <th>Ngày tạo</th>
                <th>Delete</th>   
            </tr>
        </thead>
        <tbody>
        <?php if(isset($listJob) && $listJob != NULL): ?>
        <?php foreach($listJob as $index => $item): ?>
            <tr class="odd gradeX" align="center">
                <td style="display: none"><?php echo $item->id; ?></td>
                <td style="display: none"><?php echo csrf_token(); ?></td>
                <td>
                    <a href="<?php echo url('admin/quan-ly-cong-viec/xem-nhanh/') . '/' . $item->alias . '-' . $item->id . '.html'; ?>" target="_blank"><?php echo $item->title; ?>

                    </a>
                </td>
                <td>
                  <a href="<?php echo url('admin/quan-ly-thanh-vien/xem-nhanh/') . '/' . $item->cAlias . '-' . $item->employer_id . '.html'; ?>" target="_blank">
                    <?php echo $item->name; ?>

                  </a>
                </td>
                <td>
                    <?php if($item->active == 1): ?>
                    Đã duyệt
                    <?php elseif($item->active == 2): ?>
                    Ẩn
                    <?php else: ?>
                    Chưa kích hoạt
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($item->type_job == 1): ?>
                    Hot
                    <?php elseif($item->type_job == 2): ?>
                    Lương cao
                    <?php elseif($item->type_job == 3): ?>
                    Gấp
                    <?php elseif($item->type_job == 4): ?>
                    Mới
                    <?php else: ?>
                    Không xác định
                    <?php endif; ?>
                </td>
                <td><?php echo Carbon\Carbon::parse($item->create_date)->format('d/m/Y');; ?></td>
                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo url('admin/quan-ly-ho-so/xoa-cong-viec/') . '/' . $item->id; ?>"> Delete</a></td>
            </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

<script src="<?php echo url('public/admin'); ?>/js/jquery.tabledit.js"></script>
<script type="text/javascript">
    $('#dataTables-example').Tabledit({
    url: '<?php echo url('admin/quan-ly-cong-viec/sua-nhanh'); ?>',
    deleteButton: false,
    columns: {
        identifier: [0, 'id'],
        editable: [[1, '_token'],  [4, 'active', '{"1": "Duyệt", "2": "Ẩn"}'],  [5, 'type_job', '{"1": "Hot", "2": "Lương cao", "3": "Gấp", "4": "Mới", "5": "Không xác định"}']]
    },
    action: 'Sửa Nhanh',
    onDraw: function() {
    },

    onSuccess: function(data, textStatus, jqXHR) {
        window.location.href="<?php echo url('admin/quan-ly-cong-viec/danh-sach'); ?>";
    },
    onFail: function(jqXHR, textStatus, errorThrown) {
        $(function() {
        $('#dialog-message').empty();
          $('#dialog-message').append(jqXHR['responseJSON']['code']);
          $( "#dialog-message" ).dialog({
                modal: true,
                buttons: [
                          {
                              text: "OK",
                              click: function() {                     
                                  $(this).dialog("close"); 
                                  var row_fail = $('.danger').index();
                                  $('.tabledit-edit-button')[row_fail].click();
                                  $('input[name="'+ jqXHR['responseJSON']['position_error'] +'"]').focus();
                              }
                          }
                        ]
          });
        });
        },
    onAlways: function() {
    },
    onAjax: function(action, serialize) {
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
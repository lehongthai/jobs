<?php $__env->startSection('body_right'); ?>
    <div class="col-lg-11" style="padding-bottom:120px">
        <form action="<?php echo route('admin.post.getEdit'); ?>" method="POST">
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
            <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
           <div class="form-group">
                <label>Tiêu đề</label>
                <input class="form-control" name="txtTitle" placeholder="Vui lòng nhập tiêu đề" value="<?php echo old('txtTitle', $data['title']); ?>" />
                <div style="color:red"><?php echo $errors->first('txtTitle'); ?></div>
            </div>
            <div class="form-group">
                <label>Danh Mục Bài Viết</label>
                <select class="form-control" name="cate_id">
                    <option value="0">Vui Lòng Chọn</option>
                    <?php foreach($parent as $catePost): ?>
                    <option value="<?php echo $catePost['id']; ?>" <?php if(old('cate_id') == $catePost['id'] || $data['cate_id'] == $catePost['id']): ?> selected  <?php endif; ?>><?php echo $catePost['name']; ?></option>
                    <?php endforeach; ?>
                </select>
                <div style="color:red"><?php echo $errors->first('cate_id'); ?></div>
            </div>
            <div class="form-group">
                <label>Ảnh hiển thị</label>
                <div class="col-xs-12 thumbnail">
                    <img src="<?php echo old('image_link', $data['image_link']); ?>" id="image_link">
                    <hr>
                <input class="form-control" name="txtAltImage" placeholder="Chú thích ảnh" value="<?php echo old('txtAltImage', $data['alt']); ?>"  />
                </div>
                <input type="hidden" name="image_link" id="link_avatar" value="<?php echo old('image_link', $data['image_link']); ?>" >
                <button type="button" class="btn btn-large btn-block btn-default" onclick="BrowseServer();">Chọn Ảnh</button>
                <div style="color:red"><?php echo $errors->first('image_link'); ?></div>
            </div>
            <div class="form-group">
                <label>Giới thiệu</label>
                <textarea class="form-control" rows="3" name="txtIntro"><?php echo old('txtIntro', $data['intro']); ?></textarea>
                <div style="color:red"><?php echo $errors->first('txtIntro'); ?></div>
            </div>
            <div class="form-group">
                <label>Keywords</label>
                <input class="form-control" name="txtKeyword" placeholder="Vui lòng nhập Keywords" value="<?php echo old('txtKeyword', $data['keywords']); ?>" />
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" rows="3" name="txtDescription"><?php echo old('txtDescription', $data['description']); ?></textarea>
            </div>
            <div class="form-group">
                <label>Nội Dung</label>
                <textarea class="form-control" rows="3" name="txtContent"><?php echo old('txtContent', $data['content']); ?></textarea>
                <script type="text/javascript">ckeditor('txtContent')</script>
            </div>
            <div class="form-group">
                <label>Xem ở trang chủ</label>
                <div class="checkbox">
                    <label>
                    <?php if($data['views'] == 1): ?>
                        <input name="view" type="checkbox" value="1" checked>
                    <?php else: ?>
                        <input name="view" type="checkbox" value="1">
                    <?php endif; ?>
                        Cho xem
                    </label>
                </div>
            </div>
            <button type="submit" class="btn btn-default">Edit</button>
            <button type="reset" class="btn btn-default" onclick="window.location='<?php echo URL('admin/post/list'); ?>'">Cancel</button>
        <form>
    </div>
<script type="text/javascript">
    function BrowseServer()
    {
        // You can use the "CKFinder" class to render CKFinder in a page:
        var finder = new CKFinder();
        finder.basePath = '../';    // The path for the installation of CKFinder (default = "/ckfinder/").
        finder.selectActionFunction = SetFileField;
        finder.popup();
    }
    // This is a sample function which is called when a file is selected in CKFinder.
    function SetFileField( fileUrl )
    {
      document.getElementById( 'link_avatar' ).value = fileUrl;
      document.getElementById( 'image_link' ).src = document.getElementById( 'link_avatar' ).value;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', 'Tất cả dự án'); ?>
<?php $__env->startSection('about'); ?>
<div class="row">
<h2 class="text-center fh5co-heading">Các Dự Án</h2>
<?php foreach($listProject as $key => $project): ?>
        <div class="col-md-4 text-center animate-box">
          <a class="work" href="<?php echo URL('/detail'). '/' . $project->alias; ?>">
            <div class="work-grid" style="background-image:url(<?php echo $project->image_link; ?>);">
              <div class="inner">
                <div class="desc">
                <h3><?php echo $project->title; ?></h3>
                <span class="cart"><?php echo $project->intro; ?></span>
              </div>
              </div>
            </div>
          </a>
        </div>
<?php endforeach; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('body_right'); ?>

    <div class="col-lg-11" style="padding-bottom:120px">
        <form action="<?php echo route('admin.aq.getEdit'); ?>" method="POST">
        <div class="pull-right">
            <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon glyphicon-floppy-save" aria-hidden="true"></span> Lưu Lại</button>
            <button type="button" class="btn btn-primary" onclick="window.location='<?php echo url('admin/a&q/list'); ?>'"><span class="glyphicon glyphicon-backward" aria-hidden="true"></span> Cancel</button>
        </div>
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
            <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
            <div class="form-group">
                <label>Câu hỏi</label>
                <input class="form-control" name="txtAnswer" placeholder="Câu hỏi" value="<?php echo old('txtAnswer', $data['answer']); ?>" />
                <div style="color:red"><?php echo $errors->first('txtAnswer'); ?></div>
            </div>
            <div class="form-group">
                <label>Keywords</label>
                <input class="form-control" name="txtKeyword" placeholder="Vui lòng nhập Keywords" value="<?php echo old('txtKeyword', $data['keywords']); ?>" />
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" rows="3" name="txtDescription"><?php echo old('txtDescription', $data['description']); ?></textarea>
            </div>
            <div class="form-group">
                <label>Vị trí</label>
                <input class="form-control" name="txtOrder" placeholder="Vị trí" value="<?php echo old('txtOrder', $data['orders']); ?>" />
                <div style="color:red"><?php echo $errors->first('txtOrder'); ?></div>
            </div>
            <div class="form-group">
                <label>Trả lời</label>
                <textarea class="form-control" rows="3" name="txtQuestion"><?php echo old('txtQuestion', $data['question']); ?></textarea>
                <div style="color:red"><?php echo $errors->first('txtQuestion'); ?></div>
                <script type="text/javascript">ckeditor('txtQuestion')</script>
            </div>
        <form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
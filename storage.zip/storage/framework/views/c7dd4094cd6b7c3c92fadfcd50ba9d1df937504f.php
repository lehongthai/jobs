<?php $__env->startSection('body_right'); ?>
    <div class="col-lg-11" style="padding-bottom:120px">
        <form action="<?php echo route('admin.infouser.postEdit'); ?>" method="POST">
        <div class="pull-right">
            <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon glyphicon-floppy-save" aria-hidden="true"></span> Lưu Lại</button>
            <button type="button" class="btn btn-primary" onclick="window.location='<?php echo url('admin/info/list/'.$data['alias']); ?>'"><span class="glyphicon glyphicon-backward" aria-hidden="true"></span> Cancel</button>
        </div>

            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
            <input type="hidden" name="alias" value="<?php echo $data['alias']; ?>">
            <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
            <div class="form-group">
                <label>Tên</label>
                <input class="form-control" name="txtName" placeholder="Vui lòng nhập tên" value="<?php echo old('txtName', $data['name']); ?>" />
                <div style="color:red"><?php echo $errors->first('txtName'); ?></div>
            </div>
            <div class="form-group">
                <label>Vị trí</label>
                <input class="form-control" name="txtOrder" placeholder="Vui lòng nhập vị trí" value="<?php echo old('txtOrder', $data['orders']); ?>" />
                <div style="color:red"><?php echo $errors->first('txtOrder'); ?></div>
            </div>
        <form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>

<section id="jobs" style="margin-top: 100px">
      <div class="container">
        <div class="row">
          <div class="col-sm-8">
            <h2>Danh sách ứng viên</h2>

            <div class="jobs">
              
             <?php foreach($listResume as $k => $resume): ?>
              <div class="custom-find-job">
                <div class="title">
                <a href="<?php echo url('ho-so/' . $resume->alias . '-' . $resume->id . '.html'); ?>">
                  <h5><?php echo $resume->title; ?></h5>
                </a>
                  <p><?php echo $resume->fullname; ?></p>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                  <?php $arrProvin = explode(',', str_replace('^', '', $resume->provin_wish)); ?>
                  <?php foreach($arrProvin as $ke => $provin): ?>
                  <a href="<?php echo url('ho-so-tinh-thanh/'. convert_vi_to_en(\App\Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                    <?php echo \App\Common::getProvinNameById($provin); ?>

                  </a>
                    <?php if($ke != (count($arrProvin) - 1)): ?>,<?php endif; ?>
                  <?php endforeach; ?>
                  </span>
                  <span class="experience" style="width: 155px"><i class="fa fa-trophy"></i><?php echo \App\Common::getNameById($resume->empirical); ?></span>
                  <span class="sallary"><i class="fa fa-dollar"></i><?php echo number_format($resume->wage,0,",","."); ?></span>
                </div>
             </div>
              <?php endforeach; ?>
              

            </div>

           <nav>
              <ul class="pagination">
                <li <?php if($listResume->currentPage() == 1): ?> class="disabled" onclick="return false;" <?php endif; ?>><a href="<?php echo str_replace('/?', '?', $listResume->url($listResume->currentPage() - 1)); ?>" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
              
              <?php for($i=1; $i<=$listResume->lastPage(); $i++): ?>
                <li class="<?php echo ($listResume->currentPage() == $i) ? 'active' : ''; ?>">
                <a href="<?php echo str_replace('/?', '?', $listResume->url($i)); ?>"><?php echo $i; ?></a></li>
              <?php endfor; ?>
             
                <li <?php if($listResume->currentPage() == $listResume->lastPage()): ?> class="disabled" onclick="return false;" <?php endif; ?>>
                <a href="<?php echo str_replace('/?', '?', $listResume->url($listResume->currentPage() + 1)); ?>" aria-label="Next"><span aria-hidden="true">&raquo;</span></a>
                </li>
              
              </ul>
            </nav>

          </div>
          
           <div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindResume', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            </div>
        </div>
      </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
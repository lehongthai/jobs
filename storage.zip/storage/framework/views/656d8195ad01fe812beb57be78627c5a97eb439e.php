<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('body_right'); ?>
    <button type="button" onclick="window.location='<?php echo url('admin/info/add/'.$check); ?>'" class="btn btn-success">Thêm mới</button>
    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
            <tr align="center">
                <td style="display: none"></td>
                <td style="display: none"></td>
                <th>Tên</th>
                <th>Vị trí</th>
                <th>Danh mục</th>
                <th>Edit</th>
                <th>Delete</th>   
            </tr>
        </thead>
        <tbody>
        <?php if(isset($data) && $data != NULL): ?>
        <?php foreach($data as $index => $item): ?>
            <tr class="odd gradeX" align="center">
                <td style="display: none"><?php echo $item->id; ?></td>
                <td style="display: none"><?php echo csrf_token(); ?></td>
                <td><?php echo $item->name; ?></td>
                <td><?php echo $item->orders; ?></td>
                <td>
                    <?php if($item->alias == 'level'): ?>
                    Bằng Cấp
                    <?php elseif($item->alias == 'empirical'): ?>
                    Kinh nghiệm 
                    <?php elseif($item->alias == 'diploma'): ?>
                    Cấp bậc hiện tại
                    <?php elseif($item->alias == 'diploma_wish'): ?>
                    Cấp bậc mong muốn
                    <?php elseif($item->alias == 'exigency'): ?>
                    Nhu cầu làm việc
                    <?php elseif($item->alias == 'language_level'): ?>
                    Trình độ ngôn ngữ
                    <?php elseif($item->alias == 'probation_time'): ?>
                    Thời gian thử việc
                    <?php elseif($item->alias == 'wage'): ?>
                    Mức lương
                    <?php elseif($item->alias == 'attribute'): ?>
                    Tính chất công việc
                    <?php elseif($item->alias == 'loai_tn'): ?>
                    Loại tốt nghiệp
                    <?php elseif($item->alias == 'language'): ?>
                    Ngôn ngữ
                    <?php elseif($item->alias == 'quy_mo'): ?>
                    Quy mô công ty
                    <?php endif; ?>
                </td>
                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo URL::route('admin.infouser.getEdit', $item->id); ?>">Edit</a></td>
                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo URL::route('admin.infouser.getDelete', $item->id); ?>"> Delete</a></td>
            </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

<script src="<?php echo url('public/admin'); ?>/js/jquery.tabledit.js"></script>
<script type="text/javascript">
    $('#dataTables-example').Tabledit({
    url: '<?php echo url('admin/info/action'); ?>',
    deleteButton: false,
    columns: {
        identifier: [0, 'id'],
        editable: [[1, '_token'],  [3, 'orders']]
    },
    action: 'Sửa Nhanh',
    onDraw: function() {
    },

    onSuccess: function(data, textStatus, jqXHR) {
        //window.location.href="<?php echo url('admin/info/list/'); ?>";
    },
    onFail: function(jqXHR, textStatus, errorThrown) {
        $(function() {
        $('#dialog-message').empty();
          $('#dialog-message').append(jqXHR['responseJSON']['code']);
          $( "#dialog-message" ).dialog({
                modal: true,
                buttons: [
                          {
                              text: "OK",
                              click: function() {                     
                                  $(this).dialog("close"); 
                                  var row_fail = $('.danger').index();
                                  $('.tabledit-edit-button')[row_fail].click();
                                  $('input[name="'+ jqXHR['responseJSON']['position_error'] +'"]').focus();
                              }
                          }
                        ]
          });
        });
        },
    onAlways: function() {
    },
    onAjax: function(action, serialize) {
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
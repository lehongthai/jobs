<?php
use App\Common; 
$listJob = Common::getJob();
$listProvin = Common::getProvin();
$listLevel = Common::getLevel();
$listEmpirical = Common::getEmpirical();
$listExigency = Common::getExigency();
$listType = Common::getType();
?>

<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<?php /* add menu user */ ?>
<?php echo $__env->make('page.blocks.menu_bottom_employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end menu user */ ?>
<div class="row" style="margin-top: 100px">
<div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-md-offset-2">
<h2>Tìm kiếm ứng viên</h2>
<form action="<?php echo url('tim-kiem-ho-so'); ?>" method="get" role="form">
  <div class="form-group">
    <input type="text" class="form-control" name="title" placeholder="Nhập từ khóa" <?php if(isset($_GET['title'])): ?> value="<?php echo $_GET['title']; ?>" <?php endif; ?>>
  </div>
  <div class="form-group">
    <select name="job" class="form-control">
      <option value="">-- Công Việc --</option>
      <?php foreach($listJob as $job): ?>
      <option value="<?php echo $job->id; ?>" <?php if(isset($_GET['job']) && $_GET['job'] == $job->id): ?> selected <?php endif; ?>>-- <?php echo $job->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('job'); ?></span>
  </div>
  <div class="form-group">
    <select name="provin" class="form-control">
      <option value="">-- Địa Điểm --</option>
      <?php foreach($listProvin as $provin): ?>
      <option value="<?php echo $provin->id; ?>" <?php if(isset($_GET['provin']) && $_GET['provin'] == $provin->id): ?> selected <?php endif; ?>>-- <?php echo $provin->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('provin'); ?></span>
  </div>
  <div class="form-group">
    <select name="level" class="form-control">
      <option value="">-- Bằng Cấp --</option>
      <?php foreach($listLevel as $level): ?>
      <option value="<?php echo $level->id; ?>" <?php if(isset($_GET['level']) && $_GET['level'] == $level->id): ?> selected <?php endif; ?>>-- <?php echo $level->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('level'); ?></span>
  </div>
  <div class="form-group">
    <select name="sex" class="form-control">
      <option value="0">-- Không yêu cầu --</option>
      <option value="1" <?php if(isset($_GET['sex']) && $_GET['sex'] == 1): ?> selected <?php endif; ?>>-- Nam --</option>
      <option value="2" <?php if(isset($_GET['sex']) && $_GET['sex'] == 2): ?> selected <?php endif; ?>>-- Nữ --</option>
    </select>
    <span style="color:red"><?php echo $errors->first('sex'); ?></span>
  </div>
  <div class="form-group">
    <select name="type" class="form-control">
      <option value="">-- Hình Thức làm Việc --</option>
      <?php foreach($listType as $type): ?>
      <option value="<?php echo $type->id; ?>" <?php if(isset($_GET['type']) && $_GET['type'] == $type->id): ?> selected <?php endif; ?>>-- <?php echo $type->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('type'); ?></span>
  </div>
  <div class="form-group">
    <select name="empirical" class="form-control">
      <option value="">-- Kinh Nghiệm --</option>
      <?php foreach($listEmpirical as $empirical): ?>
      <option value="<?php echo $empirical->id; ?>" <?php if(isset($_GET['empirical']) && $_GET['empirical'] == $empirical->id): ?> selected <?php endif; ?>>-- <?php echo $empirical->name; ?> --</option>
      <?php endforeach; ?>
    </select>
    <span style="color:red"><?php echo $errors->first('empirical'); ?></span>
  </div>
  <button type="submit" class="btn btn-primary">Tìm Kiếm</button>
</form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
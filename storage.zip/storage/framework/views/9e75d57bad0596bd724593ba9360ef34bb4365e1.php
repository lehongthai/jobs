<?php 
use App\Common;
$jobHot = Common::getHotJob(); 
$jobNew = Common::getNewJob(); 
$jobHight = Common::getHighWageJob(); 
$jobGap = Common::getGapJob(); 
?>
<h2>Công Việc Nổi Bật</h2>
<div role="tabpanel">

              <!-- Nav pills -->
              <ul class="nav nav-pills">
                <li role="presentation" class="active"><a href="#about" aria-controls="about" role="tab" data-toggle="tab" aria-expanded="true">Hot</a></li>
                <li role="presentation" class=""><a href="#services" aria-controls="services" role="tab" data-toggle="tab" aria-expanded="false">Gấp</a></li>
                <li role="presentation" class=""><a href="#sales" aria-controls="sales" role="tab" data-toggle="tab" aria-expanded="false">Lương Cao</a></li>
                <li role="presentation" class=""><a href="#sales_new" aria-controls="sales" role="tab" data-toggle="tab" aria-expanded="false">Mới</a></li>
              </ul>

              <!-- Tab panes -->
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="about">
                <?php foreach($jobHot as $jh => $hJob): ?>
                 <a href="<?php echo url('cong-viec') . '/' . $hJob->alias . '-' . $hJob->id . '.html'; ?>">
                  <h5><?php echo $hJob->title; ?></h5>
                 </a>
                 <ul>
                  <li>
                  <i class="fa fa-map-marker"></i>
                  <?php $arrProvinHot = explode(',', str_replace('^', '', $hJob->provin)); ?>
                    <?php foreach($arrProvinHot as $ke => $provin): ?>
                      <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                        <?php echo Common::getProvinNameById($provin); ?>

                      </a>
                      <?php if($ke != (count($arrProvinHot) - 1)): ?>,<?php endif; ?>
                    <?php endforeach; ?>                       
                  </li>
                  <li style="float: right"><i class="fa fa-dollar"></i><?php echo Common::getNameById($hJob->wage); ?></li>
                
              </ul>
              <?php endforeach; ?>
              <a class="btn btn-primary" href="<?php echo url('viec-lam-hot'); ?>">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="services">
                  <?php foreach($jobGap as $jg => $gJob): ?>
                 <a href="<?php echo url('cong-viec') . '/' . $gJob->alias . '-' . $gJob->id . '.html'; ?>">
                  <h5><?php echo $gJob->title; ?></h5>
                 </a>
                 <ul>
                  <li>
                  <i class="fa fa-map-marker"></i>
                  <?php $arrProvinGap = explode(',', str_replace('^', '', $gJob->provin)); ?>
                    <?php foreach($arrProvinGap as $ke => $provin): ?>
                      <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                        <?php echo Common::getProvinNameById($provin); ?>

                      </a>
                      <?php if($ke != (count($arrProvinGap) - 1)): ?>,<?php endif; ?>
                    <?php endforeach; ?>                       
                  </li>
                  <li style="float: right"><i class="fa fa-dollar"></i><?php echo Common::getNameById($gJob->wage); ?></li>
                
              </ul>
              <?php endforeach; ?>
              <a class="btn btn-primary" href="<?php echo url('viec-lam-dang-gap'); ?>">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="sales">
                  <?php foreach($jobHight as $jhw => $hwJob): ?>
                 <a href="<?php echo url('cong-viec') . '/' . $hwJob->alias . '-' . $hwJob->id . '.html'; ?>">
                  <h5><?php echo $hwJob->title; ?></h5>
                 </a>
                 <ul>
                  <li>
                  <i class="fa fa-map-marker"></i>
                  <?php $arrProvinHigh = explode(',', str_replace('^', '', $hwJob->provin)); ?>
                    <?php foreach($arrProvinHigh as $ke => $provin): ?>
                      <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                        <?php echo Common::getProvinNameById($provin); ?>

                      </a>
                      <?php if($ke != (count($arrProvinHigh) - 1)): ?>,<?php endif; ?>
                    <?php endforeach; ?>                       
                  </li>
                  <li style="float: right"><i class="fa fa-dollar"></i><?php echo Common::getNameById($hwJob->wage); ?></li>
                
              </ul>
              <?php endforeach; ?>
              <a class="btn btn-primary" href="<?php echo url('viec-lam-luong-cao'); ?>">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="sales_new">
                  <?php foreach($jobNew as $jn => $nJob): ?>
                 <a href="<?php echo url('cong-viec') . '/' . $nJob->alias . '-' . $nJob->id . '.html'; ?>">
                  <h5><?php echo $nJob->title; ?></h5>
                 </a>
                 <ul>
                  <li>
                  <i class="fa fa-map-marker"></i>
                  <?php $arrProvinNew = explode(',', str_replace('^', '', $nJob->provin)); ?>
                    <?php foreach($arrProvinNew as $ke => $provin): ?>
                      <a href="<?php echo url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html'); ?>">
                        <?php echo Common::getProvinNameById($provin); ?>

                      </a>
                      <?php if($ke != (count($arrProvinNew) - 1)): ?>,<?php endif; ?>
                    <?php endforeach; ?>                       
                  </li>
                  <li style="float: right"><i class="fa fa-dollar"></i><?php echo Common::getNameById($nJob->wage); ?></li>
                
              </ul>
              <?php endforeach; ?>
              <a class="btn btn-primary" href="<?php echo url('viec-lam-moi'); ?>">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
              </div>

            </div>
<?php
use App\Common; 
$info = Common::getInfoResume(Auth::user()->id); 
$listJob = Common::getJob();
$listProvin = Common::getProvin();
$listLevel = Common::getLevel();
$listEmpirical = Common::getEmpirical();
$listDiploma = Common::getDiploma();
$listDiplomaWish = Common::getDiplomaWish();
$listExigency = Common::getExigency();
$listType = Common::getType();
$uri = Request::segment(2);
?>
<div class="panel panel-default">
  <div class="panel-heading text-center">
    <h3 class="panel-title">Thông Tin Hồ Sơ</h3>
  </div>

  <div class="panel-body">
    <div class="table-responsive">
    <table class="table table-hover">
      <tr>
        <th>Tiêu Đề Hồ Sơ</th>
        <td style="color:red"><?php echo $info->title; ?></td>   
        <th>Trình Độ Cao Nhất</th>
        <td><?php echo Common::getNameById($info->level); ?></td>
      </tr>
      <tr>
        <th>Năm Kinh Nghiệm</th>
        <td><?php echo Common::getNameById($info->empirical); ?></td>  
        <th>Cấp Bậc Hiện Tại</th>
        <td><?php echo Common::getNameById($info->diploma); ?></td> 
      </tr>
      <tr>
        <th>Cấp Bậc Mong Muốn</th>
        <td><?php echo Common::getNameById($info->diploma_wish); ?></td>   
        <th>Lương Mong Muốn</th>
        <td><?php echo number_format($info->wage,0,",","."); ?></td>
      </tr>
      <tr>
        <th>Kiểu Làm Việc</th>
        <td>
        <?php foreach(explode(',', $info->type) as $jobType): ?>
          <?php echo Common::getTypeNameById($jobType); ?><br>
        <?php endforeach; ?>
        </td>   
        <th>Cho Phép Tìm Kiếm</th>
        <td>
        <?php if($info->status == 1): ?>  
          Có
        <?php else: ?> 
        Không
        <?php endif; ?>
        </td>
      </tr>
    </table>
    </div>
    <div class="pull-right">
      <button type="button" id="get-modal-info-cv" class="btn btn-xs btn-primary">Chỉnh Sửa</button>
    </div>
  </div>
</div>

<div class="modal fade" id="modal-info-cv">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Chỉnh Sửa Thông Tin CV Cơ Bản</h4>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo url('ung-vien/cap-nhat-ho-so-co-ban'); ?>">
<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
<input type="hidden" name="id_resume" value="<?php echo $info->id; ?>">
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group" id="resume-title-group">
                <label for="resume-title">Tiêu Đề Hồ Sơ</label><span class="require">*</span>
                <input type="text" class="form-control" id="resume-title" placeholder="Tiêu Đề Hồ Sơ" name="title" value="<?php echo old('title', $info->title); ?>">
                <span style="color:red"><?php echo $errors->first('title'); ?></span>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group" id="resume-category-group">
                <label for="resume-category">Trình Độ Cao Nhất</label><span class="require">*</span>
                <select class="form-control select-level" id="resume-category" name="levelInfo">
                  <option>-- Vui Lòng Chọn Một --</option>
                  <?php foreach($listLevel as $level): ?>
                  <option value="<?php echo $level->id; ?>" <?php if(old('levelInfo') == $level->id || $info->level == $level->id): ?> selected <?php endif; ?>>-- <?php echo $level->name; ?> --</option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('levelInfo'); ?></span>
              </div>
            </div>
          
          </div>
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group" id="resume-category-group">
                <label for="resume-category">Số Năm Kinh Nghiệm</label><span class="require">*</span>
                <select name="empirical" class="form-control select-level" id="resume-category">
                  <option>-- Vui Lòng Chọn Một --</option>
                  <?php foreach($listEmpirical as $empirical): ?>
                  <option value="<?php echo $empirical->id; ?>" <?php if(old('empirical') == $empirical->id || $info->empirical == $empirical->id): ?> selected <?php endif; ?>>-- <?php echo $empirical->name; ?> --</option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('empirical'); ?></span>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group" id="resume-category-group">
                <label for="resume-category">Cấp Bậc Hiện Tại</label><span class="require">*</span>
                <select name="diploma" class="form-control select-level" id="resume-category">
                  <option>-- Vui Lòng Chọn Một --</option>
                  <?php foreach($listDiploma as $diploma): ?>
                  <option value="<?php echo $diploma->id; ?>" <?php if(old('diploma') == $diploma->id || $info->diploma == $diploma->id): ?> selected <?php endif; ?>>-- <?php echo $diploma->name; ?> --</option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('diploma'); ?></span>
              </div>
            </div>
          
          </div>
          
          <div class="row social-network">
          <div class="col-sm-6">
              <div class="form-group" id="resume-category-group">
                <label for="resume-category">Cấp Bậc Mong Muốn</label><span class="require">*</span>
                <select name="diploma_wish" class="form-control select-level" id="resume-category">
                  <option>-- Vui Lòng Chọn Một --</option>
                  <?php foreach($listDiplomaWish as $diploma_wish): ?>
                  <option value="<?php echo $diploma_wish->id; ?>" <?php if(old('diploma_wish') == $diploma_wish->id || $info->diploma_wish == $diploma_wish->id): ?> selected <?php endif; ?>>-- <?php echo $diploma_wish->name; ?> --</option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('diploma_wish'); ?></span>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group" id="resume-social-network-group">
              <?php $jobs = explode(',', str_replace('^', '', $info->jobs_wish)); ?>
                <label for="resume-social-network">Ngành Nghề Mong Muốn</label><span class="require">*</span><br>
                <select name="job[]" multiple="multiple" class="form-control js-example-basic-multiple-limit" data-tags="true" data-placeholder="Chọn công việc (tối đa 3 việc)" data-allow-clear="true">
                  <?php foreach($listJob as $job): ?>
                  <option value="<?php echo $job->id; ?>"
                  <?php if(old('job') != NULL): ?> 
                    <?php if(in_array($job->id, old('job'))): ?> selected 
                    <?php endif; ?> 
                  <?php else: ?> 
                    <?php if(in_array($job->id, $jobs)): ?> selected
                    <?php endif; ?> 
                  <?php endif; ?>><?php echo $job->name; ?></option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('job'); ?></span>
              </div>
            </div>
            
          </div>
          <div class="row social-network">
          <div class="col-sm-6">
              <div class="form-group" id="resume-category-group">
                <label for="resume-category">Nhu Cầu Làm Việc</label><span class="require">*</span>
                <select name="exigency" class="form-control select-level" id="resume-category">
                  <option>-- Vui Lòng Chọn Một --</option>
                  <?php foreach($listExigency as $exigency): ?>
                  <option value="<?php echo $exigency->id; ?>" <?php if(old('exigency') == $exigency->id || $info->exigency == $exigency->id): ?> selected <?php endif; ?>>-- <?php echo $exigency->name; ?> --</option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('exigency'); ?></span>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group" id="resume-social-network-group">
              <?php $provins = explode(',', str_replace('^', '', $info->provin_wish)); ?>
                <label for="resume-social-network">Nơi Làm Việc Mong Muốn</label><span class="require">*</span>
                <select name="provin[]" multiple class="form-control js-example-basic-multiple-limit" data-tags="true" data-placeholder="Chọn Nơi Làm Việc" data-allow-clear="true">
                  <?php foreach($listProvin as $provin): ?>
                  <option value="<?php echo $provin->id; ?>" 
                  <?php if(old('provin') != NULL): ?>
                    <?php if(in_array($provin->id, old('provin'))): ?> selected 
                    <?php endif; ?>
                  <?php else: ?>
                    <?php if(in_array($provin->id, $provins)): ?> selected 
                    <?php endif; ?>
                  <?php endif; ?>><?php echo $provin->name; ?></option>
                  <?php endforeach; ?>
                  <option value="100" <?php if(old('provin') == 100): ?> selected <?php endif; ?>>Tất cả</option>
                </select>
                <span style="color:red"><?php echo $errors->first('provin'); ?></span>
              </div>
            </div>
            
          </div>
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group" id="resume-social-network-group">
                <label for="resume-social-network">Kiểu Làm Việc</label><span class="require">*</span>
                <select name="type" class="form-control" data-tags="true" data-placeholder="Chọn Kiểu Làm Việc">
                <?php foreach($listType as $k => $lType): ?>
                  <option value="<?php echo $lType->id; ?>" <?php if(old('type') == $lType->id || $info->type == $lType->id): ?> selected <?php endif; ?>><?php echo $lType->name; ?></option>
                  <?php endforeach; ?>
                </select>
                <span style="color:red"><?php echo $errors->first('type'); ?></span>
              </div>
            </div>
            <div class="col-sm-6">
            <div class="form-group" id="resume-wage-group">
                <label for="resume-wage">Tiền Lương Mong Muốn</label><span class="require">*</span>
                <input type="text" class="form-control" id="resume-wage" placeholder="Vui Lòng Nhập Số" name="wage" value="<?php echo old('wage', $info->wage); ?>">
                <span style="color:red"><?php echo $errors->first('wage'); ?></span>
              </div>
            </div>
          
          </div>
          <div class="row">
            <div class="col-sm-12">
              <div class="form-group wysiwyg" id="resume-content-group">
                <label>Giới Thiệu Bản Thân</label>

                <div class="btn-toolbar" data-role="editor-toolbar" data-target="#resume-content">
                  <div class="btn-group">
                    <a class="btn" data-edit="bold" title="" data-original-title="Bold (Ctrl/Cmd+B)"><i class="fa fa-bold"></i></a>
                    <a class="btn" data-edit="italic" title="" data-original-title="Italic (Ctrl/Cmd+I)"><i class="fa fa-italic"></i></a>
                  </div>
                  <div class="btn-group">
                    <a class="btn" data-edit="insertunorderedlist" title="" data-original-title="Bullet list"><i class="fa fa-list-ul"></i></a>
                    <a class="btn" data-edit="insertorderedlist" title="" data-original-title="Number list"><i class="fa fa-list-ol"></i></a>
                  </div>
                  <div class="btn-group">
                    <a class="btn" data-edit="justifyleft" title="" data-original-title="Align Left (Ctrl/Cmd+L)"><i class="fa fa-align-left"></i></a>
                    <a class="btn" data-edit="justifycenter" title="" data-original-title="Center (Ctrl/Cmd+E)"><i class="fa fa-align-center"></i></a>
                    <a class="btn" data-edit="justifyright" title="" data-original-title="Align Right (Ctrl/Cmd+R)"><i class="fa fa-align-right"></i></a>
                  </div>
                  <div class="btn-group">
                    <a class="btn dropdown-toggle" data-toggle="dropdown" title="" data-original-title="Hyperlink"><i class="fa fa-link"></i></a>
                    <div class="dropdown-menu input-append">
                      <input class="form-control pull-left" placeholder="http://" type="text" data-edit="createLink">
                      <button class="btn btn-primary" type="button">Add</button>
                    </div>
                    <a class="btn" data-edit="unlink" title="" data-original-title="Remove Hyperlink"><i class="fa fa-unlink"></i></a>
                  </div>
                  <input type="text" data-edit="inserttext" id="voiceBtn" style="display: none;">
                </div>

                <div class="editor" id="resume-content" contenteditable="true"><?php echo $info->description; ?></div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-12">
              <hr class="dashed">
            </div>
          </div>
          <div class="checkbox">
            <label style="color:red">
              <input type="checkbox" value="1" name="status" <?php if(old('status') == 1 || $info->status == 1): ?> checked <?php endif; ?>>
              Cho phép nhà tuyển dụng xem hồ sơ
            </label>
          </div>
          <input type="hidden" name="description" id="inputIntro" value="">
          <div class="row text-center">
            <div class="col-sm-12">
              <button type="submit" class="btn btn-primary" onclick="return getIntro();">Cập Nhật Hồ Sơ</button>
              <button type="button" class="btn btn-warning" data-dismiss="modal">Hủy</button>
            </div>
          </div>
          <input type="hidden" name="returnUrl" class="form-control" value="<?php echo $uri; ?>">
  </form>
      </div>
    </div>
  </div>
</div>
<?php if($errors->first('title') || $errors->first('levelInfo') || $errors->first('empirical') || $errors->first('diploma') || $errors->first('diploma_wish') || $errors->first('job') || $errors->first('exigency') || $errors->first('provin') || $errors->first('type')): ?>
<script type="text/javascript">
  $('#modal-info-cv').modal('show');
</script>
<?php endif; ?>

<script type="text/javascript">
  function getIntro() {
    var intro = $('#resume-content').html();
    document.getElementById("inputIntro").value = intro;
  }
</script>
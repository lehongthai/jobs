<section id="title" style="margin-top: 100px">
      <div class="container">
      <?php if(!Auth::check()): ?>
        <div class="row" id="form-custom-post">
        <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" style="border-right: 2px solid #fff">
              <a href="<?php echo url('dang-nhap'); ?>" class="button-login" id="button-login">
              <i class="glyphicon glyphicon-user" aria-hidden="true"></i><br>
                <span>Đăng Nhập</span>
              </a>
            </div>
            <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
              <a href="<?php echo url('dang-ky'); ?>" class="button-login">
              <i class="fa fa-user-plus" aria-hidden="true"></i><br>
              <span>Đăng Ký</span>
              </a>
            </div>
            
            <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
              <div class="post-cv">
              <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <button type="button" style="width: 100%;height:100px;margin-bottom: 10px" class="btn btn-lg btn-primary" onclick="window.location='<?php echo url('ung-vien/ho-so'); ?>'">Tạo hồ sơ miễn phí</button></div><div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <button type="button" style="width: 100%;height:100px;" class="btn btn-lg btn-success" onclick="window.location='<?php echo url('nha-tuyen-dung/dang-tin-tuyen-dung'); ?>'">Đăng Tin Miễn Phí</button></div>
              </div>
            </div>
        </div>
        <?php else: ?>
        <div class="row" id="form-custom-post">
            <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-md-offset-2">
              <div class="post-cv">
              <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <button type="button" style="width: 100%;height:100px;margin-bottom: 10px" class="btn btn-lg btn-primary" onclick="window.location='<?php echo url('ung-vien/ho-so'); ?>'">Tạo hồ sơ miễn Phí</button></div><div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <button type="button" style="width: 100%;height:100px;" class="btn btn-lg btn-success" onclick="window.location='<?php echo url('nha-tuyen-dung/dang-tin-tuyen-dung'); ?>'">Đăng Tin Miễn Phí</button></div>
              </div>
            </div>
        </div>
        <?php endif; ?>
      </div>
    </section>
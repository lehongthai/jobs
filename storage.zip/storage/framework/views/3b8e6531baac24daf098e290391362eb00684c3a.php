<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>

<div>
    <h3>Lấy lại mật khẩu</h3>
    
</div>
<p>Bạn đã lấy lại mật khẩu thành công. </p>
<span>Mật khẩu của bạn là : </span><strong><?php echo $pass; ?></strong><p></p>
<p>Vui lòng click vào link sau để đăng nhập</p>
<a href="<?php echo url('dang-nhap'); ?>">Click vào đây</a>
</body>
</html>
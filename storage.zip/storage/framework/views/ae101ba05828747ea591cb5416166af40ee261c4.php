<?php $__env->startSection('title', $detailPost->title); ?>
<?php $__env->startSection('content'); ?>

<div class="row" style="margin-top: 100px">
<section id="title">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<img src="<?php echo $detailPost->image_link; ?>" alt="" class="img-responsive img-circle" />
					</div>
					<div class="col-sm-10">
						<h1><?php echo $detailPost->title; ?></h1>
						<div class="meta">
							<span><i class="fa fa-user"></i>Admin</span>
							<span><i class="fa fa-calendar"></i><?php echo Carbon\Carbon::parse($detailPost->created_at)->format('d/m/Y'); ?></span>
							<span><i class="fa fa-comment"></i><?php echo $detailPost->views; ?></span>
						</div>
					</div>
				</div>
			</div>
		</section>
		<br>
<div class="col-sm-8">

						<!-- POSTS START -->

						<article>
							<h4><?php echo $detailPost->intro; ?></h4>
							<br>
							<div><?php echo $detailPost->content; ?></div>
						</article>

						<!-- POSTS END -->

						

						<!-- COMMENTS START -->

						<div class="row">
							<div class="col-sm-12">
								<div class="fb-comments" data-href="<?php echo url()->current();; ?>" data-width="100%" data-numposts="10"></div>
							</div>
						</div>

						<!-- COMMENTS END -->

						<hr>

						<!-- COMMENT FORM START -->

						
						
					</div>

					 <div class="col-sm-4" id="sidebar">
		          <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
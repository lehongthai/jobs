<?php
use App\Info;
$seo = Info::getSeo();
//echo '<pre>';print_r($seo);die;
?>



<?php $__env->startSection('title', $seo->title); ?>
<?php $__env->startSection('description', $seo->meta_desc); ?>
<?php $__env->startSection('keywords', $seo->meta_key); ?>

<?php $__env->startSection('slider'); ?>
<?php echo $__env->make('page.blocks.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
    

<?php $__env->startSection('project'); ?>
<div id="fh5co-work">
    <div class="container">
      <div class="row">
<h2 class="text-center fh5co-heading">Dự Án Nổi Bật</h2>
<?php foreach($listProject as $key => $project): ?>
        <div class="col-md-4 text-center animate-box">
          <a class="work" href="<?php echo URL('/detail/').'/'.$project->alias; ?>">
            <div class="work-grid" style="background-image:url(<?php echo $project->image_link; ?>);">
              <div class="inner">
                <div class="desc">
                <h3><?php echo $project->title; ?></h3>
                <span class="cat"><?php echo $project->intro; ?></span>
              </div>
              </div>
            </div>
          </a>
        </div>
<?php endforeach; ?>
</div>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('about'); ?>

<div class="row animate-box">
        <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
          <h2>Giới Thiệu</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-md-8">
          <div class="author">
            <div class="author-inner animate-box">
            </div>
            <div class="desc animate-box">
              <span><?php echo $about->title; ?></span>
              <p><?php echo $about->intro; ?></p>
              <p><a href="<?php echo URL('about'); ?>" class="btn btn-primary btn-outline">Learn More</a></p>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
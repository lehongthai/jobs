<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('body_right'); ?>

    <div class="col-lg-11" style="padding-bottom:120px">
    <h2 class="text-center">Thông tin công ty <?php echo $infoEmployer->name; ?></h2>
       <table class="table table-condensed table-hover">
           <thead>
               <tr>
                   <th>Email đăng nhập</th>
                   <td><?php echo $infoEmployer->uEmail; ?></td>
               </tr>
           </thead>
           <tbody>
               <tr>
                    <th>Tên công ty</th>
                    <td><?php echo $infoEmployer->name; ?></td>
               </tr>
               <tr>
                    <th>Logo công ty</th>
                    <td>
                        <a onclick="return false;" class="thumbnail">
                        <img src="<?php echo url('public\upload\company\\'). $infoEmployer->logo; ?>" alt="<?php echo $infoEmployer->name; ?>">
                      </a>
                    </td>
               </tr>
               <tr>
                    <th>Website</th>
                    <td><a href="<?php echo $infoEmployer->website; ?>" target="_blank"><?php echo $infoEmployer->name; ?></a></td>
               </tr>
               <tr>
                    <th>Điện thoại</th>
                    <td><?php echo $infoEmployer->phone; ?></td>
               </tr>
               <tr>
                    <th>Fax</th>
                    <td><?php echo $infoEmployer->fax; ?></td>
               </tr>
               <tr>
                    <th>Địa chỉ</th>
                    <td><?php echo $infoEmployer->address; ?></td>
               </tr>
               <tr>
                    <th>Trạng thái</th>
                    <td><?php if($infoEmployer->active != 1): ?>
                        Chưa kích hoạt
                        <?php else: ?>
                        Đã kích hoạt
                        <?php endif; ?>
                    </td>
               </tr>
               
               <tr>
                    <th>Tổng số việc làm</th>
                    <td><?php echo $infoEmployer->count_job; ?></td>
               </tr>
               <tr>
                    <th>Ngày tạo</th>
                    <td><?php echo Carbon\Carbon::parse($infoEmployer->create_date)->format('d/m/Y');; ?></td>
               </tr>
              
           </tbody>
       </table>
       <?php if($infoEmployer->active != 1): ?>
       <button type="button" class="btn btn-large btn-block btn-success" onclick="window.location='<?php echo url('admin/quan-ly-thanh-vien/kich-hoat-cong-ty/' . $infoEmployer->id); ?>'">Kích hoạt</button>
       <?php else: ?>
       <button type="button" class="btn btn-large btn-block btn-danger" onclick="window.location='<?php echo url('admin/quan-ly-thanh-vien/bo-kich-hoat-cong-ty/' . $infoEmployer->id); ?>'">Bỏ kích hoạt</button>
       <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!DOCTYPE HTML>
<html>
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Ninemobi - <?php echo $__env->yieldContent('title'); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>" />
  <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>" />
  <meta name="author" content="Ninemobi" />

   -->

    <!-- Facebook and Twitter integration -->
  <meta property="og:title" content=""/>
  <meta property="og:image" content=""/>
  <meta property="og:url" content=""/>
  <meta property="og:site_name" content=""/>
  <meta property="og:description" content=""/>
  <meta name="twitter:title" content="" />
  <meta name="twitter:image" content="" />
  <meta name="twitter:url" content="" />
  <meta name="twitter:card" content="" />

  <!-- <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet"> -->
  
  <!-- Animate.css -->
  <link rel="stylesheet" href="<?php echo url('public/page'); ?>/css/animate.css">
  <!-- Icomoon Icon Fonts-->
  <link rel="stylesheet" href="<?php echo url('public/page'); ?>/css/icomoon.css">
  <!-- Bootstrap  -->
  <link rel="stylesheet" href="<?php echo url('public/page'); ?>/css/bootstrap.css">
  <!-- Theme style  -->
  <link rel="stylesheet" href="<?php echo url('public/page'); ?>/css/style.css">

  <!-- Modernizr JS -->
  <script src="<?php echo url('public/page'); ?>/js/modernizr-2.6.2.min.js"></script>
  <!-- FOR IE9 below -->
  <!--[if lt IE 9]>
  <script src="js/respond.min.js"></script>
  <![endif]-->

  </head>
  <body>
    
  <div class="fh5co-loader"></div>
  
  <div id="page">
  <?php /* Add menu */ ?>
    <?php echo $__env->make('page.blocks.sub_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php /* End add menu */ ?>

  <?php /* Add slider */ ?>
 <div class="container">
    <?php echo $__env->yieldContent('slider'); ?>
  </div>
  <?php /* End Slider */ ?>

  <?php /* Add project */ ?>
        <?php echo $__env->yieldContent('project'); ?>
  <?php /* End project */ ?>

    <div id="fh5co-author" class="fh5co-bg-section">
      <div class="container">
        <?php echo $__env->yieldContent('about'); ?>
      </div>
    </div>

    <footer id="fh5co-footer" role="contentinfo">
    <div class="container">
    <?php echo $__env->make('page.blocks.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    </footer>
    </div>

  <div class="gototop js-top">
    <a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
  </div>


  <!-- jQuery -->
  <script src="<?php echo url('public/page'); ?>/js/jquery.min.js"></script>
  <!-- jQuery Easing -->
  <script src="<?php echo url('public/page'); ?>/js/jquery.easing.1.3.js"></script>
  <!-- Bootstrap -->
  <script src="<?php echo url('public/page'); ?>/js/bootstrap.min.js"></script>
  <!-- Waypoints -->
  <script src="<?php echo url('public/page'); ?>/js/jquery.waypoints.min.js"></script>
  <!-- Main -->
  <script src="<?php echo url('public/page'); ?>/js/main.js"></script>
</body>
</html>
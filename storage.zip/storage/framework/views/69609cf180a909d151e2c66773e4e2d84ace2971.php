<?php $__env->startSection('body_right'); ?>

                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr align="center">
                                <th>ID</th>
                                <th>Tiêu Đề</th>
                                <th>Keywords</th>
                                <th>Description</th>
                                <th>Icon</th>
                                <th>Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($data as $index => $item): ?>
                            <tr class="odd gradeX" align="center">
                                <td><?php echo $index + 1; ?></td>
                                <td><?php echo $item['title']; ?></td>
                                <td><?php echo $item['meta_key']; ?></td>
                                <td><?php echo $item['meta_desc']; ?></td>
                                <td><img src="<?php echo $item['image_thumb']; ?>"></td>
                                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo URL::route('admin.about.getEdit', $item['id']); ?>">Edit</a></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
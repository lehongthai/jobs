<?php $__env->startSection('body_right'); ?>
<?php if($data): ?>
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr align="center">
                                <th>Tên</th>
                                <th>Ảnh</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($data as $item): ?>
                            <tr class="odd gradeX" align="center">
                                <td><?php echo $item->content; ?></td>
                                <td><img src="<?php echo $item->image_thumb; ?>"></td>
                                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo URL::route('admin.image.getEdit', $item->id); ?>">Edit</a></td>
                                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="<?php echo URL::route('admin.image.getDelete', $item->id); ?>"> Delete</a></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
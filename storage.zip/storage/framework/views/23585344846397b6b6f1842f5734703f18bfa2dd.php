<?php if(Session::has('flash_message')): ?>
<div class="alert alert-<?php echo Session::get('level'); ?>">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
  <strong>Thông báo!</strong> <?php echo Session::get('flash_message'); ?>

</div>
<?php endif; ?>
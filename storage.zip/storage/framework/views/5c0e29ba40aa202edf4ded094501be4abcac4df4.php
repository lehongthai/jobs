<?php
use App\Info;
$listMenu = Info::getMenu();
$uri = Request::segment(1);
?>

<nav class="fh5co-nav" role="navigation">
    <div class="container">
      <div class="fh5co-top-logo">
        <div id="fh5co-logo"><a href="<?php echo URL('/'); ?>">Ninemobi</a></div>
      </div>
      <div class="fh5co-top-menu menu-1 text-center">
        <ul>
        <?php foreach($listMenu as $key => $menu): ?>
          <li <?php if($uri == $menu->url): ?> class="active" <?php endif; ?>><a href="<?php echo URL('/') .'/'. $menu->url; ?>"><?php echo $menu->name; ?></a></li>
        <?php endforeach; ?>
        </ul>
      </div>
      <div class="fh5co-top-social menu-1 text-right">
        <ul class="fh5co-social">
          <li><a href="#"><i class="icon-twitter"></i></a></li>
          <li><a href="#"><i class="icon-dribbble"></i></a></li>
          <li><a href="#"><i class="icon-github"></i></a></li>
        </ul>
      </div>
    </div>
  </nav>
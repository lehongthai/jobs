<div class="popup-form">
        <div class="popup-header">
          <a class="close"><i class="fa fa-remove fa-lg"></i></a>
          <h2>Login</h2>
        </div>
        <form method="post" action="<?php echo url('auth/login'); ?>">
        <input type="hidden" name="_token" id="input_token" class="form-control" value="<?php echo csrf_token(); ?>">
          <ul class="social-login">
            <li><a href="<?php echo url('facebook/redirect'); ?>" class="btn btn-facebook"><i class="fa fa-facebook"></i>Đăng Nhập Với Facebook</a></li>
            <li><a href="<?php echo url('google/redirect'); ?>" class="btn btn-google"><i class="fa fa-google-plus"></i>Đăng Nhập Với Google</a></li>
          </ul>
          <hr>
          <div class="form-group">
            <label for="login-username">Username</label>
            <input type="text" class="form-control" id="login-username" name="usernameLogin" value="<?php echo old('usernameLogin'); ?>">
            <div style="color: red"><?php echo $errors->first('usernameLogin'); ?></div>
          </div>
          <div class="form-group">
            <label for="login-password">Password</label>
            <input type="password" class="form-control" id="login-password" name="passwordLogin" >
            <div style="color: red"><?php echo $errors->first('passwordLogin'); ?></div>
          </div>
          <button type="submit" class="btn btn-primary">Sign In</button>
        </form>
      </div>
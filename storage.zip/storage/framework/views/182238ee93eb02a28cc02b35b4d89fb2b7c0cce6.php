
      <div class="row" id="form-custom-post">
      <?php if(!Auth::check()): ?>
        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" style="border-right: 2px solid #fff">
          <a href="<?php echo url('dang-nhap'); ?>" class="button-login" id="button-login">
          <i class="glyphicon glyphicon-user" aria-hidden="true"></i><br>
            <span>Đăng Nhập</span>
          </a>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
          <a href="<?php echo url('dang-ky'); ?>" class="button-login">
          <i class="fa fa-user-plus" aria-hidden="true"></i><br>
          <span>Đăng Ký</span>
          </a>
        </div>
        <?php else: ?>
          <?php if(Auth::user()->level == 1): ?>
        <button type="button" style="width: 100%;height:100px;margin-bottom: 10px;" class="btn btn-lg btn-warning" onclick="window.location='<?php echo url('ung-vien/tai-khoan'); ?>'">Tài Khoản <?php echo Auth::user()->fullname; ?></button>
          <?php elseif(Auth::user()->level == 2): ?>
          <button type="button" style="width: 100%;height:100px;margin-bottom: 10px;" class="btn btn-lg btn-warning" onclick="window.location='<?php echo url('nha-tuyen-dung/tai-khoan'); ?>'">Tài Khoản <?php echo Auth::user()->fullname; ?></button>
          <?php endif; ?>
        <?php endif; ?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" <?php if(!Auth::check()): ?> style="margin-top: 105px;" <?php endif; ?>>
          <div class="post-cv">
            <button type="button" style="width: 100%;height:100px;margin-bottom: 10px" class="btn btn-lg btn-primary" onclick="window.location='<?php echo url('nha-tuyen-dung/ho-so'); ?>'">Tạo Hồ Sơ Miễn Phí</button>
            <button type="button" style="width: 100%;height:100px;" class="btn btn-lg btn-success" onclick="window.location='<?php echo url('ung-vien/dang-tin-tuyen-dung'); ?>'">Đăng Tin Miễn Phí</button>
          </div>
        </div>
      </div>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<?php /* add menu user */ ?>
<?php echo $__env->make('page.blocks.menu_bottom_employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end menu user */ ?>
<div class="row" style="margin-top: 100px">
<div class="col-sm-8">
<?php echo $__env->make('page.blocks.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<table class="table table-bordered" id="datatable-savejob">
		<thead>
			<tr style="background-color: #14B1BB">
				<th>Thứ tự</th>
				<th>Công việc</th>
				<th>Hồ sơ</th>
				<th>Cập Nhật</th>
			</tr>
		</thead>
		<tbody>
		<?php foreach($listApplyJobs as $key => $saveJob): ?>
			<tr>
				<td><?php echo $key + 1; ?></td>
				<td><a href="<?php echo url('cong-viec/' . convert_vi_to_en($saveJob->title) . '-' . $saveJob->pId . '.html'); ?>" target="_blank"><?php echo $saveJob->title; ?></a></td>
				<td>
				<a href="<?php echo url('ho-so'). '/' . $saveJob->cvAlias . '-' . $saveJob->cvId . '.html'; ?>" target="_blank">
				<?php echo $saveJob->cvTitle; ?>

				</a></td>
				<td><?php echo Carbon\Carbon::parse($saveJob->cCreateDate)->format('d/m/Y'); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindResume', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo url('public/admin'); ?>/bower_components/DataTables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo url('public/admin'); ?>/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    $('#datatable-savejob').DataTable({
    	"language": {
            "lengthMenu": "Hiển thị _MENU_ Số lượng tin hiển thị",
            "zeroRecords": "Không có kết quả nào",
            "info": "Hiển thị tin _PAGE_ của _PAGES_",
            "infoEmpty": "Không có kết quả nào",
            "infoFiltered": "(filtered from _MAX_ total records)",
            "sSearch":        "Tìm Kiếm: "
        }
    });
    $(".input-sm").css({
    	height: '40px'
  	});
});
	
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
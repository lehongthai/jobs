<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('page.blocks.loginInline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* add menu user */ ?>
<?php echo $__env->make('page.blocks.menu_bottom_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php /* end menu user */ ?>
<div class="row" style="margin-top: -180px">
<div class="col-sm-8">
<?php echo $__env->make('page.blocks.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title text-center">Thông Tin Tài Khoản -  <strong><?php echo $infoCandidate->fullname; ?></strong></h3>
  </div>
  <div class="panel-body">
    <div class="table-responsive">
      <table class="table table-hover table-bordered">
        <tbody>
          <tr>
            <th>Tên đầy đủ</th>
            <td><?php echo $infoCandidate->fullname; ?></td>
          </tr>
          <tr>
            <th>Ảnh hiển thị</th>
            <td>
              <a onclick="return false;" class="thumbnail">
                <img src="<?php echo url('public\upload\avatar\\') . $infoCandidate->avatar; ?>">
              </a>
            </td>
          </tr>
          <tr>
            <th>Email đăng nhập</th>
            <td><?php echo $infoCandidate->email; ?></td>
          </tr>
          <tr>
            <th>Loại tài khoản</th>
            <td>
            <?php if($infoCandidate->level == 1): ?>
            Người tìm việc
            <?php elseif($infoCandidate->level == 2): ?>
            Nhà tuyển dụng
            <?php elseif($infoCandidate->level == 3): ?>
            Quản trị
            <?php endif; ?>
            </td>
          </tr>
          <tr>
            <th>Trạng thái tài khoản</th>
            <td>
            <?php if($infoCandidate->active == 1): ?>
            Đã kích hoạt
            <?php else: ?>
            Chưa kích hoạt
            <?php endif; ?>
            </td>
          </tr>
          <tr>
            <th>Ngày tạo</th>
            <td><?php echo Carbon\Carbon::parse($infoCandidate->created_at)->format('d/m/Y'); ?></td>
          </tr>
          <tr>
            <th>Ngày cập nhật</th>
            <td><?php echo Carbon\Carbon::parse($infoCandidate->updated_at)->format('d/m/Y'); ?></td>
          </tr>
          <tr>
            <th>Giới tính</th>
            <td>
              <?php if($infoCandidate->sex == 1): ?>
              Nam
              <?php elseif($infoCandidate->active == 2): ?>
              Nữ
              <?php else: ?>
              Không xác định
              <?php endif; ?>
            </td>
          </tr>
          <tr>
            <th>Ngày sinh</th>
            <td><?php echo Carbon\Carbon::parse($infoCandidate->birthday)->format('d/m/Y'); ?></td>
          </tr>
          <tr>
            <th>Điện thoại</th>
            <td><?php echo $infoCandidate->phone; ?></td>
          </tr>
          <tr>
            <th>Địa chỉ</th>
            <td><?php echo $infoCandidate->address; ?></td>
          </tr>
          <tr>
            <th>Tỉnh - Thành Phố</th>
            <td><?php echo $infoCandidate->name; ?></td>
          </tr>
        </tbody>

      </table>
      <button type="button" class="btn btn-large btn-block btn-info" onclick="window.location='<?php echo url('ung-vien/cap-nhat'); ?>'">Cập nhật</button>
      <button type="button" class="btn btn-large btn-block btn-danger" onclick="window.location='<?php echo url('ung-vien/thay-doi-mat-khau'); ?>'">Đổi mật khẩu</button>
    </div>
  </div>
</div>
</div>
<div class="col-sm-4" id="sidebar">
            <div class="sidebar-widget" id="jobsearch">
              <?php echo $__env->make('page.blocks.silderBarJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <hr>
              
              <?php echo $__env->make('page.blocks.fullFindJob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
          </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
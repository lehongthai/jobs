<?php
$uri = Request::segment(2);
?>
<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation" style="height: 10px;">
  <div class="container">
    <a class="navbar-brand" href="{!! url('ung-vien/tai-khoan') !!}">{!! Auth::user()->fullname !!}</a>
    <ul class="nav navbar-nav">
      <li @if($uri == 'ho-so-ca-nhan' || $uri == 'ho-so') class="active" @endif>
        <a href="{!! url('ung-vien/ho-so') !!}">Hồ Sơ</a>
      </li>
      <li @if($uri == 'viec-lam-da-luu') class="active" @endif>
        <a href="{!! url('ung-vien/viec-lam-da-luu') !!}">Việc Làm Đã Lưu</a>
      </li>
      <li @if($uri == 'viec-lam-ung-tuyen') class="active" @endif>
        <a href="{!! url('ung-vien/viec-lam-ung-tuyen') !!}">Việc Làm Ứng Tuyển</a>
      </li>
      <li @if($uri == 'nha-tuyen-dung-xem') class="active" @endif>
        <a href="{!! url('ung-vien/nha-tuyen-dung-xem') !!}">Nhà Tuyển Dụng Xem</a>
      </li>
      <li @if($uri == 'trang-tuyen-dung') class="active" @endif>
        <a href="#">Thông Báo Việc Làm</a>
      </li>
      <li>
        <a href="{!! url('logout') !!}">Đăng Xuất</a>
      </li>
    </ul>
  </div>
</nav>
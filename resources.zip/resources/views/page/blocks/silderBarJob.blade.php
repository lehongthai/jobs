<?php 
use App\Common;
$jobHot = Common::getHotJob(); 
$jobNew = Common::getNewJob(); 
$jobHight = Common::getHighWageJob(); 
$jobGap = Common::getGapJob(); 
?>
<h2>Công Việc Nổi Bật</h2>
<div role="tabpanel">

              <!-- Nav pills -->
              <ul class="nav nav-pills">
                <li role="presentation" class="active"><a href="#about" aria-controls="about" role="tab" data-toggle="tab" aria-expanded="true">Hot</a></li>
                <li role="presentation" class=""><a href="#services" aria-controls="services" role="tab" data-toggle="tab" aria-expanded="false">Gấp</a></li>
                <li role="presentation" class=""><a href="#sales" aria-controls="sales" role="tab" data-toggle="tab" aria-expanded="false">Lương Cao</a></li>
                <li role="presentation" class=""><a href="#sales_new" aria-controls="sales" role="tab" data-toggle="tab" aria-expanded="false">Mới</a></li>
              </ul>

              <!-- Tab panes -->
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="about">
                @foreach($jobHot as $jh => $hJob)
                 <a href="{!! url('cong-viec') . '/' . $hJob->alias . '-' . $hJob->id . '.html' !!}">
                  <h5>{!! $hJob->title !!}</h5>
                 </a>
                 <ul>
                  <li>
                  <i class="fa fa-map-marker"></i>
                  <?php $arrProvinHot = explode(',', str_replace('^', '', $hJob->provin)); ?>
                    @foreach($arrProvinHot as $ke => $provin)
                      <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                        {!! Common::getProvinNameById($provin) !!}
                      </a>
                      @if($ke != (count($arrProvinHot) - 1)),@endif
                    @endforeach                       
                  </li>
                  <li style="float: right"><i class="fa fa-dollar"></i>{!! Common::getNameById($hJob->wage) !!}</li>
                
              </ul>
              @endforeach
              <a class="btn btn-primary" href="{!! url('viec-lam-hot') !!}">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="services">
                  @foreach($jobGap as $jg => $gJob)
                 <a href="{!! url('cong-viec') . '/' . $gJob->alias . '-' . $gJob->id . '.html' !!}">
                  <h5>{!! $gJob->title !!}</h5>
                 </a>
                 <ul>
                  <li>
                  <i class="fa fa-map-marker"></i>
                  <?php $arrProvinGap = explode(',', str_replace('^', '', $gJob->provin)); ?>
                    @foreach($arrProvinGap as $ke => $provin)
                      <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                        {!! Common::getProvinNameById($provin) !!}
                      </a>
                      @if($ke != (count($arrProvinGap) - 1)),@endif
                    @endforeach                       
                  </li>
                  <li style="float: right"><i class="fa fa-dollar"></i>{!! Common::getNameById($gJob->wage) !!}</li>
                
              </ul>
              @endforeach
              <a class="btn btn-primary" href="{!! url('viec-lam-dang-gap') !!}">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="sales">
                  @foreach($jobHight as $jhw => $hwJob)
                 <a href="{!! url('cong-viec') . '/' . $hwJob->alias . '-' . $hwJob->id . '.html' !!}">
                  <h5>{!! $hwJob->title !!}</h5>
                 </a>
                 <ul>
                  <li>
                  <i class="fa fa-map-marker"></i>
                  <?php $arrProvinHigh = explode(',', str_replace('^', '', $hwJob->provin)); ?>
                    @foreach($arrProvinHigh as $ke => $provin)
                      <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                        {!! Common::getProvinNameById($provin) !!}
                      </a>
                      @if($ke != (count($arrProvinHigh) - 1)),@endif
                    @endforeach                       
                  </li>
                  <li style="float: right"><i class="fa fa-dollar"></i>{!! Common::getNameById($hwJob->wage) !!}</li>
                
              </ul>
              @endforeach
              <a class="btn btn-primary" href="{!! url('viec-lam-luong-cao') !!}">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="sales_new">
                  @foreach($jobNew as $jn => $nJob)
                 <a href="{!! url('cong-viec') . '/' . $nJob->alias . '-' . $nJob->id . '.html' !!}">
                  <h5>{!! $nJob->title !!}</h5>
                 </a>
                 <ul>
                  <li>
                  <i class="fa fa-map-marker"></i>
                  <?php $arrProvinNew = explode(',', str_replace('^', '', $nJob->provin)); ?>
                    @foreach($arrProvinNew as $ke => $provin)
                      <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                        {!! Common::getProvinNameById($provin) !!}
                      </a>
                      @if($ke != (count($arrProvinNew) - 1)),@endif
                    @endforeach                       
                  </li>
                  <li style="float: right"><i class="fa fa-dollar"></i>{!! Common::getNameById($nJob->wage) !!}</li>
                
              </ul>
              @endforeach
              <a class="btn btn-primary" href="{!! url('viec-lam-moi') !!}">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
              </div>

            </div>
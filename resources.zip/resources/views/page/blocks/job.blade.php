  <div>
            <h2>Việc Làm</h2>
                <div class="title">
                  <h5>Việc mới</h5>
                </div>
                <a href="#">việc 1</a>
                <a href="#">việc 1</a>
                <a href="#">việc 1</a>
                <a href="#">việc 1</a>
                <a href="#">việc 1</a>
            </div>
            <div>
            <hr>
                <div class="title">
                  <h5>Việc làm ngay</h5>
                </div>
                <div class="data">
                 <a href="#">việc 1</a>
                <a href="#">việc 1</a>
                <a href="#">việc 1</a>
                <a href="#">việc 1</a>
                <a href="#">việc 1</a>
              </div>
            </div>
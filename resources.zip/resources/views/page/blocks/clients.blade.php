<section id="clients">
      <div class="container">
        <div class="row text-center">
          <div class="col-sm-12">
            <h1>Happy Clients</h1>
            <h4>Some of the many companies we’ve helped</h4>
            <div class="owl-carousel">
              
              <!-- Logo 1 -->
              <div>
                <a href="company.html"><img src="images/client-logo1.gif" alt="" /></a>
              </div>
              
              <!-- Logo 2 -->
              <div>
                <a href="company.html"><img src="images/client-logo2.gif" alt="" /></a>
              </div>
              
              <!-- Logo 3 -->
              <div>
                <a href="company.html"><img src="images/client-logo3.gif" alt="" /></a>
              </div>
              
              <!-- Logo 4 -->
              <div>
                <a href="company.html"><img src="images/client-logo4.gif" alt="" /></a>
              </div>
              
              <!-- Logo 5 -->
              <div>
                <a href="company.html"><img src="images/client-logo5.gif" alt="" /></a>
              </div>
              
              <!-- Logo 6 -->
              <div>
                <a href="company.html"><img src="images/client-logo6.gif" alt="" /></a>
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
<?php
use App\Common;
$listProvin = Common::getProvin();
$uri = Request::segment(2);
?>
<div class="panel panel-default">
  <div class="panel-heading text-center">
    <h3 class="panel-title">Thông Tin Ứng Viên</h3>
  </div>

  <div class="panel-body">
  <div class="row">
<div class="col-sm-4" id="imageChange">
  <a href="#" class="thumbnail">
    <img id="target" src="{!! url('public\upload\avatar\\') . Auth::user()->avatar !!}">
  </a>
  <form enctype="multipart/form-data" id="upload_form" role="form" method="POST" action="{!! url('user/editImageAvatar') !!}" >
   <input type="hidden" name="_token" class="form-control" value="{!! csrf_token() !!}">
  <input type='file' id="imgInp" name="imageAvatar" />
  <input type="hidden" name="returnUrl" class="form-control" value="{!! $uri !!}">
  </form>
</div>
  <div class="col-sm-8">
    <div class="table-responsive">
    <table class="table table-hover">
      <tr>
        <th>Họ Và tên</th>
        <td>{!! Auth::user()->fullname !!}</td>   
      </tr>
      <tr>
        <th>Địa chỉ email</th>
        <td>{!! Auth::user()->email !!}</td>   
      </tr>
      <tr>
        <th>Số Điện Thoại</th>
        <td>{!! Auth::user()->phone !!}</td>   
      </tr>
       <tr>
        <th>Quê Quán</th>
        <td>{!! Common::getProvinNameById(Auth::user()->provin) !!}</td>   
      </tr>
       <tr>
        <th>Ngày Sinh</th>
        <td>{!! Carbon\Carbon::parse(Auth::user()->birthday)->format('d/m/Y') !!}</td>   
      </tr>
    </table>
    </div>
  </div>
  </div>
  <div class="pull-right">
      <button id="get-modal-account" type="button" class="btn btn-xs btn-primary">Chỉnh Sửa</button>
  </div>
  </div>
</div>
<div class="modal fade" id="modal-account">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Chỉnh Sửa Tài Khoản</h4>
      </div>
      <div class="modal-body">
      <form method="post" action="{!! url('user/editProfile') !!}" id="form-register">
        <input type="hidden" name="_token" id="input_token" class="form-control" value="{!! csrf_token() !!}">

          <div class="row">
            <div class="col-sm-6">
            <div class="form-group">
                <label>Họ Tên</label><span class="require">*</span>
                <input type="text" class="form-control" id="login-username" name="fullname" value="{!! old('fullname', Auth::user()->fullname) !!}">
                <span style="color:red">{!! $errors->first('fullname') !!}</span>
              </div>
              <div class="form-group">
                <label>Số Điện Thoại</label><span class="require">*</span>
                <input type="text" class="form-control" name="phone" value="{!! old('phone', Auth::user()->phone) !!}">
                <span style="color:red">{!! $errors->first('phone') !!}</span>
              </div>
              <div class="form-group">
                <label>Email</label><span class="require">*</span>
                <input type="email" class="form-control" name="email" value="{!! old('email', Auth::user()->email) !!}">
                <span style="color:red">{!! $errors->first('email') !!}</span>
              </div>
               <div class="form-group">
                <label>Tỉnh/ Thành Phố</label><span class="require">*</span>
                <select name="provinUser" class="form-control">
                  <option value="">-- Vui lòng chọn --</option>
                  @foreach($listProvin as $key => $provin)
                  <option value="{!! $provin->id !!}" @if(old('provinUser') == $provin->id || Auth::user()->provin == $provin->id) selected @endif>-- {!! $provin->name !!} --</option>
                  @endforeach
                </select>
                <span style="color:red">{!! $errors->first('provinUser') !!}</span>
              </div>
              
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label>Ngày Sinh</label><span class="require">*</span>

                <input type="date" name="birthday" class="form-control" value="{!! old('birthday', Auth::user()->birthday) !!}">
                <span style="color:red">{!! $errors->first('birthday') !!}</span>
              </div>
              <div class="form-group">
                <label>Giới Tính</label><span class="require">*</span>
                <select name="sex" id="inputSex" class="form-control">
                  <option value="">-- Select One --</option>
                  <option value="1" @if(old('sex') == 1 || Auth::user()->sex == 1) selected @endif>-- Nam --</option>
                  <option value="2" @if(old('sex') == 2 || Auth::user()->sex == 2) selected @endif>-- Nữ --</option>
                </select>
                <span style="color:red">{!! $errors->first('sex') !!}</span>
              </div>
             
              <div class="form-group">
                <label>Địa Chỉ</label><span class="require">*</span>
                <textarea name="address" id="input" class="form-control" rows="3">{!! old('address', Auth::user()->address) !!}</textarea>
                <span style="color:red">{!! $errors->first('address') !!}</span>
              </div>
            </div>
          </div>
          <div class="form-group">
                <label for="login-password">Nhập Mật Khẩu Chỉnh Sửa</label><span class="require">*</span>
                <input type="password" class="form-control" id="login-password" name="old_password" >
                <span style="color:red">{!! $errors->first('old_password') !!}</span>
              </div>
          <div class="row text-center">
            <div class="col-sm-12">
              <button type="submit" class="btn btn-primary">Cập Nhật Hồ Sơ</button>
              <button type="button" class="btn btn-warning" data-dismiss="modal">Hủy</button>
            </div>
          </div>
          <input type="hidden" name="returnUrl" class="form-control" value="{!! $uri !!}">
          </form>
      </div>
      
    </div>
  </div>
</div>

<script type="text/javascript">

  var button_save = '<button type="button" class="btn btn-xs btn-success pull-right" onclick="return buttonSave();">Save</button>';
  var button_cancel = '<button type="button" class="btn btn-xs btn-warning pull-left" id="button_cancel" onclick="return buttonCancel();">Hủy</button>'
  function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();            
            reader.onload = function (e) {
                $('#target').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imgInp").change(function(){
        readURL(this);
        $('#imgInp').hide();
        $('#imageChange').append(button_save, button_cancel);
    });


    function buttonCancel() {
      window.location = '{!! url('ung-vien/ho-so-ca-nhan') !!}';
    }


</script>


@if($errors->first('fullname') || $errors->first('phone') || $errors->first('email') || $errors->first('provinUser') || $errors->first('birthday') || $errors->first('old_password') || $errors->first('sex'))
<script type="text/javascript">
  $('#modal-account').modal('show');
</script>
@endif

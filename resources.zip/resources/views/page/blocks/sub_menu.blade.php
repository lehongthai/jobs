<div class="menu">
        <div class="button-close text-right">
          <a class="fm-button"><i class="fa fa-close fa-2x"></i></a>
        </div>
        <ul class="nav">
          <li class="active"><a href="{!! url('/') !!}">Trang chủ</a></li>
          <li><a href="{!! url('viec-lam-moi-nhat') !!}">Tất cả công việc</a></li>
          <li><a href="{!! url('ung-vien/ho-so') !!}">Hồ sơ</a></li>
          <li><a href="{!! url('trang-tuyen-dung') !!}">Danh sách hồ sơ</a></li>
          <li><a href="{!! url('nha-tuyen-dung/dang-tin-tuyen-dung') !!}">Đăng tuyển dụng</a></li>
          <li><a href="{!! url('cau-hoi-thuong-gap') !!}">Câu hỏi thường gặp</a></li>
          <li><a href="#">Báo giá dịch vụ</a>
            <ul>
              <li><a href="job-details.html">Job Details</a></li>
              <li><a href="resume.html">Resume</a></li>
              <li><a href="company.html">Company</a></li>
              <li><a href="blog.html">Blog</a></li>
              <li><a href="post.html">Single Post</a></li>
              <li><a href="about.html">About Us</a></li>
              <li><a href="testimonials.html">Testimonials</a></li>
              <li><a href="options.html">Options</a></li>
            </ul>
          </li>
        </ul>   
      </div>
<?php
use App\Search;
$totalJob = Search::getCountJob();
$newJob = Search::getCountNewJob();
?>
<div class="news-jobs-day">
  <a href="{!! url('viec-lam-moi-nhat') !!}">
    <span class="title-news-job">
      Cập nhật hôm nay 
    </span>
    <span class="glyphicon glyphicon-triangle-right pull-left"></span>
    <span class="text-news-jobs">
            Có <span class="text-danger-B">{!! $newJob !!}</span> việc làm mới hôm nay trong <span class="text-danger-B">{!! $totalJob !!}</span> việc làm đang tuyển dụng
            <span class="text-danger-B">
                <strong> >>
        </strong>                Bấm xem ngay!
            </span>
    </span>
    </a>
  </div>
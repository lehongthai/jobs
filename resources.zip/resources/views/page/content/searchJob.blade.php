<?php
use App\Common; 
?>
@extends('page.master')
@section('title', 'Kết quả tìm kiếm')
@section('content')
@include('page.blocks.loginInline')
  <div class="row" style="margin-top: -180px">
    <div class="col-sm-8">
      <h2>Kết quả tìm kiếm</h2>
      @if(count($searchRessult) <= 0)
      Không cói mẹ gì cả
      @else
            <div class="jobs">
              
             @foreach($searchRessult as $k => $sJob)
               <div class="custom-find-job">
                <div class="title">
                  <a href="{!! url('cong-viec/'. $sJob->alias . '-' . $sJob->id . '.html') !!}">
                    <h5>{!! $sJob->title !!}</h5>
                  </a>
                  <a href="{!! url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($sJob->employer_id)) . '-' . $sJob->employer_id . '.html') !!}">
                    <p>{!! Common::getCompanyNameById($sJob->employer_id); !!}</p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                  <?php $arrProvinRelated = explode(',', str_replace('^', '', $sJob->provin)); ?>
                  @foreach($arrProvinRelated as $ke => $provin)
                   <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                    {!! Common::getProvinNameById($provin) !!}
                    </a>
                    @if($ke != (count($arrProvinRelated) - 1))
                    ,
                    @endif
                  @endforeach
                  </span>
                  <span class="type part-time"><i class="fa fa-clock-o"></i>
                  {!! Common::getTypeNameById($sJob->type) !!}
                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i>{!! Common::getNameById($sJob->wage) !!}</span>
                </div>
             </div>
              @endforeach
              
            </div>
<?php 
if (isset($_GET['page'])) 
{
  $page = $_GET['page'];
}

if (!isset($page) || $page == 0) 
{
  $page = 1;
}
?>
            <nav>
              <ul class="pagination">
                <li @if($page == 1) class="disabled" onclick="return false;" @endif><a href="{!! $url !!}&page={!! $page-1 !!}" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
                @for($i = 1; $i <= $totalPagination; $i++)
                <li @if($i == $page) class="active" @endif><a href="{!! $url !!}&page={!! $i !!}">{!! $i !!}</a></li>
                @endfor
                <li @if($page >= $totalPagination) class="disabled" onclick="return false;" @endif><a href="{!! $url !!}&page={!! $page+1 !!}" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
              </ul>
            </nav>
@endif
          </div>
          <div class="col-sm-4" id="sidebar">
            <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindJob')
            </div>
          </div>
        </div>

@endsection

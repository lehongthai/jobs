@extends('page.master')
@section('title', 'Đăng nhập hệ thống')

@section('content')

<div class="row" style="margin-top: 100px">
<div class="col-sm-8">
@include('page.blocks.info')
<div role="tabpanel">
<ul class="nav nav-pills nav-justified">
								<li role="presentation" class="active"><a href="#work" aria-controls="work" role="tab" data-toggle="tab">Người Tìm Việc</a></li>
								<li role="presentation"><a href="#fun" aria-controls="fun" role="tab" data-toggle="tab">Nhà Tuyển Dụng</a></li>
							</ul>

							<!-- Tab panes -->
							<div class="tab-content">
								<div role="tabpanel" class="tab-pane active" id="work">
									

        <form method="post" action="{!! url('dang-nhap') !!}">
        <input type="hidden" name="_token" class="form-control" value="{!! csrf_token() !!}">
        <input type="hidden" name="typeUser" class="form-control" value="1">
          <ul class="social-login">
            <li><a href="{!! url('facebook/redirect') !!}" class="btn btn-facebook"><i class="fa fa-facebook"></i>Đăng Nhập Với Facebook</a></li>
            <li><a href="{!! url('google/redirect') !!}" class="btn btn-google"><i class="fa fa-google-plus"></i>Đăng Nhập Với Google</a></li>
          </ul>
          <hr>
          <div class="form-group">
            <label for="login-username">Email</label><span class="require">*</span>
            <input type="text" class="form-control" id="login-username" name="usernameLogin" value="{!! old('usernameLogin') !!}">
            <div style="color: red">{!! $errors->first('usernameLogin') !!}</div>
          </div>
          <div class="form-group">
            <label for="login-password">Mật Khẩu</label><span class="require">*</span>
            <input type="password" class="form-control" id="login-password" name="passwordLogin" >
            <div style="color: red">{!! $errors->first('passwordLogin') !!}</div>
          </div>
          <div class="pull-left">
	          <button type="submit" class="btn btn-primary">Đăng nhập</button>
	          <a href="{!! url('quen-mat-khau') !!}">Quên mật khẩu</a>
	        </div>
	        <div class="pull-right">
	        	<button type="button" class="btn btn-success" onclick="window.location='{!! url('dang-ky') !!}'">Đăng ký</button>
	        </div>
        </form>
								</div>
								<div role="tabpanel" class="tab-pane" id="fun">
									<form method="post" action="{!! url('dang-nhap') !!}">
        <input type="hidden" name="_token" id="input_token" class="form-control" value="{!! csrf_token() !!}">
        <input type="hidden" name="typeUser" class="form-control" value="2">
          <ul class="social-login">
            <li><a href="{!! url('facebook/redirect') !!}" class="btn btn-facebook"><i class="fa fa-facebook"></i>Đăng Nhập Với Facebook</a></li>
            <li><a href="{!! url('google/redirect') !!}" class="btn btn-google"><i class="fa fa-google-plus"></i>Đăng Nhập Với Google</a></li>
          </ul>
          <hr>
          <div class="form-group">
            <label for="login-username">Email</label><span class="require">*</span>
            <input type="text" class="form-control" id="login-username" name="usernameLogin" value="{!! old('usernameLogin') !!}">
            <div style="color: red">{!! $errors->first('usernameLogin') !!}</div>
          </div>
          <div class="form-group">
            <label for="login-password">Mật Khẩu</label><span class="require">*</span>
            <input type="password" class="form-control" id="login-password" name="passwordLogin" >
            <div style="color: red">{!! $errors->first('passwordLogin') !!}</div>
          </div>
          <div class="pull-left">
            <button type="submit" class="btn btn-primary">Đăng nhập</button>
            <a href="{!! url('quen-mat-khau') !!}">Quên mật khẩu</a>
          </div>
          <div class="pull-right">
            <button type="button" class="btn btn-success" onclick="window.location='{!! url('dang-ky') !!}'">Đăng ký</button>
          </div>
        </form>
								</div>
							</div>

						</div>


    </div>
            <div class="col-sm-4" id="sidebar">
		          <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindJob')
            </div>
            </div>
</div>
@endsection

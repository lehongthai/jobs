@extends('page.master')
@section('content')
@include('page.blocks.loginInline')
<div class="row" style="margin-top: -100px">
<div class="col-sm-8">
@include('page.blocks.info')
<form method="post" action="{!! url('quen-mat-khau') !!}">
  <input type="hidden" name="_token" value="{!! csrf_token() !!}">

<div class="row">
  <h2>Lấy lại mật khẩu</h2>
  <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
    <label>Email</label><span class="require">*</span>
  </div>
  <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
    <div class="form-group">
        <input type="email" name="email" class="form-control" value="{!! old('email') !!}">
        <span style="color:red">{!! $errors->first('email') !!}</span>
    </div>
  </div>
  <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
  <div class="form-group">
 <button type="submit" class="btn btn-large btn-block btn-danger">Lấy mật khẩu</button>
</div>
</div>
</div>
</form>
</div>
  <div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindJob')
            </div>
            </div>
</div>
@endsection

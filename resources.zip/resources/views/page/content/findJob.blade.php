<?php
use App\Common; 
?>
@extends('page.master')

@if(isset($detailCompany) && $detailCompany != NULL)
@section('title', 'Công việc của ' . $detailCompany->name)
@elseif(isset($detailProvin) && $detailProvin != NULL)
@section('title', 'Tỉnh-Thành Phố ' . $detailProvin->name)
@endif

@section('content')
@include('page.blocks.loginInline')
  <div class="row" style="margin-top: -180px">
    <div class="col-sm-8">
    @if(isset($detailCompany) && $detailCompany != NULL)
      <h2>{!! $detailCompany->name !!}</h2>
        <a onclick="return false;" class="thumbnail">
          <img src="{!! url('public\upload\company\\') . $detailCompany->logo !!}" alt="{!! $detailCompany->name !!}">
        </a>
        <strong>Điạ Chỉ: </strong>
        <span>{!! $detailCompany->address !!}</span><br>
        <strong>Điện Thoại: </strong>
        <span>{!! $detailCompany->phone !!}</span><br>
        <strong>Website: </strong>
        <a href="http://{!! $detailCompany->website !!}" target="_blank">{!! $detailCompany->website !!}</a><br>
        <p>{!! $detailCompany->so_luot !!}</p>
    @endif
    @if(count($listJob) <= 0)
    Không cói mẹ gì cả
    @else
    <div class="jobs">
    @foreach($listJob as $k => $sJob)
      <div class="custom-find-job">
        <div class="title">
          <a href="{!! url('cong-viec/'. $sJob->alias . '-' . $sJob->id . '.html') !!}">
            <h5>{!! $sJob->title !!}</h5>
          </a>
          <a href="{!! url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($sJob->employer_id)) . '-' . $sJob->employer_id . '.html') !!}">
            <p>{!! Common::getCompanyNameById($sJob->employer_id); !!}</p>
          </a>
        </div>
        <div class="data">
          <span class="city"><i class="fa fa-map-marker"></i>
          <?php $arrProvinRelated = explode(',', str_replace('^', '', $sJob->provin)); ?>
          @foreach($arrProvinRelated as $ke => $provin)
            <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
              {!! Common::getProvinNameById($provin) !!}
            </a>
            @if($ke != (count($arrProvinRelated) - 1)),@endif
          @endforeach
          </span>
          <span class="sallary"><i class="fa fa-dollar"></i>{!! Common::getNameById($sJob->wage) !!}</span>
          <span class="sallary"><i class="fa fa-calendar"></i>{!! Carbon\Carbon::parse($sJob->expired_at)->format('d/m/Y') !!}</span>
        </div>
      </div>
    @endforeach
    </div>
<?php 
if (isset($_GET['page'])) 
{
  $page = $_GET['page'];
}

if (!isset($page) || $page == 0) 
{
  $page = 1;
}
?>
            <nav>
              <ul class="pagination">
                <li @if($page == 1) class="disabled" onclick="return false;" @endif><a href="{!! $url !!}page={!! $page-1 !!}" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
                @for($i = 1; $i <= $totalPagination; $i++)
                <li @if($i == $page) class="active" @endif><a href="{!! $url !!}page={!! $i !!}">{!! $i !!}</a></li>
                @endfor
                <li @if($page >= $totalPagination) class="disabled" onclick="return false;" @endif><a href="{!! $url !!}page={!! $page+1 !!}" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
              </ul>
            </nav>
@endif
          </div>
          <div class="col-sm-4" id="sidebar">

            <!-- Find a Job Start -->
            <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              @include('page.blocks.fullFindJob')
            </div>
            <!-- Find a Job End -->

          </div>
        </div>

@endsection

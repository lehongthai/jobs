@extends('page.master')
@section('title', $title)
@section('content')

<section id="jobs" style="margin-top: 100px">
      <div class="container">
        <div class="row">
          <div class="col-sm-8">
            <h2>Danh sách ứng viên</h2>

            <div class="jobs">
              
             @foreach($listResume as $k => $resume)
              <div class="custom-find-job">
                <div class="title">
                <a href="{!! url('ho-so/' . $resume->alias . '-' . $resume->id . '.html') !!}">
                  <h5>{!! $resume->title !!}</h5>
                </a>
                  <p>{!! $resume->fullname !!}</p>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                  <?php $arrProvin = explode(',', str_replace('^', '', $resume->provin_wish)); ?>
                  @foreach($arrProvin as $ke => $provin)
                  <a href="{!! url('ho-so-tinh-thanh/'. convert_vi_to_en(\App\Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                    {!! \App\Common::getProvinNameById($provin) !!}
                  </a>
                    @if($ke != (count($arrProvin) - 1)),@endif
                  @endforeach
                  </span>
                  <span class="experience" style="width: 155px"><i class="fa fa-trophy"></i>{!! \App\Common::getNameById($resume->empirical) !!}</span>
                  <span class="sallary"><i class="fa fa-dollar"></i>{!! number_format($resume->wage,0,",",".") !!}</span>
                </div>
             </div>
              @endforeach
              

            </div>

           <nav>
              <ul class="pagination">
                <li @if($listResume->currentPage() == 1) class="disabled" onclick="return false;" @endif><a href="{!! str_replace('/?', '?', $listResume->url($listResume->currentPage() - 1)) !!}" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
              
              @for($i=1; $i<=$listResume->lastPage(); $i++)
                <li class="{!! ($listResume->currentPage() == $i) ? 'active' : '' !!}">
                <a href="{!! str_replace('/?', '?', $listResume->url($i)) !!}">{!! $i !!}</a></li>
              @endfor
             
                <li @if($listResume->currentPage() == $listResume->lastPage()) class="disabled" onclick="return false;" @endif>
                <a href="{!! str_replace('/?', '?', $listResume->url($listResume->currentPage() + 1)) !!}" aria-label="Next"><span aria-hidden="true">&raquo;</span></a>
                </li>
              
              </ul>
            </nav>

          </div>
          
           <div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindResume')
            </div>
            </div>
        </div>
      </div>
    </section>

@endsection

<?php  
use App\Common;
?>
@section('title',$infoResume->title)
@extends('page.master')
@section('content')

<div class="row" style="margin-top: 100px">
<section id="title">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 text-center">
        <h3>{!! $infoResume->title !!}</h3>
        <h6>Duyệt tin: {!! Carbon\Carbon::parse($infoResume->time_duyet)->format('d/m/Y') !!} - Lượt xem: {!! $infoResume->view !!}</h6>
      </div>
    </div>
  </div>
</section>
<hr>
  <div class="col-sm-8">
    <article>
    <h2>Chi tiết hồ sơ</h2>
    <div class="col-sm-4">
      <a onclick="return false;" class="thumbnail">
        <img src="{!! url('public\upload\avatar\\') . $infoCandidate->avatar !!}" alt="" class="pull-left" />
      </a>
    </div>
    <div class="col-sm-8">
    <table>
      <tr>
        <th>Họ Tên:</th>
        <td>{!! $infoCandidate->fullname !!}</td>
      </tr>
      <tr>
        <th>Ngày sinh:</th>
        <td>{!! Carbon\Carbon::parse($infoCandidate->birthday)->format('d/m/Y') !!}</td>
      </tr>
      <tr>
        <th>Giới Tính:</th>
        <td>
        @if($infoCandidate->sex == 1)
        Nam
        @elseif($infoCandidate->sex == 2)
        Nữ
        @else
        Chưa xác định
        @endif
        </td>
      </tr>
      <tr>
        <th>Email liên hệ: </th>
        <td>{!! $infoCandidate->email !!}</td>
      </tr>
      <tr>
        <th>Điện Thoại:</th>
        <td>{!! $infoCandidate->phone !!}</td>
      </tr>
      <tr>
        <th>Địa chỉ:</th>
        <td>{!! $infoCandidate->address !!}</td>
      </tr>
    </table>
    </div>
    <hr><hr><hr><hr>
      <h3>Thông tin chung</h3>
      <ul>
        <li><strong>Ngành nghề: </strong>{!! Common::getTypeNameById($infoResume->type) !!}.</li>
        <li><strong>Loại việc làm: </strong>
        <?php $arrJob = explode(',', str_replace('^', '', $infoResume->jobs_wish)); ?>
        @foreach($arrJob as $k => $job)
        <a href="{!! url('ho-so-cong-viec') . '/' . convert_vi_to_en(Common::getJobNameById($job)) . '-' . $job . '.html' !!}">
          {!! Common::getJobNameById($job) !!}
        </a>
          @if($k != (count($arrJob) - 1))
                    ,
                    @endif
                 @endforeach
        .</li>
        <li><strong>Nơi làm việc</strong>
        <?php $arrProvin = explode(',', str_replace('^', '', $infoResume->provin_wish)); ?>
        @foreach($arrProvin as $k => $provin)
        <a href="{!! url('ho-so-tinh-thanh') . '/' . convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $job . '.html' !!}">
          {!! Common::getProvinNameById($provin) !!}
          </a>
          @if($k != (count($arrProvin) - 1))
                    ,
                    @endif
                 @endforeach
        .</li>
        <li><strong>Số năm kinh nghiệm: </strong>{!! Common::getNameById($infoResume->empirical) !!}.</li>
        <li><strong>Cấp bậc hiện tại: </strong>{!! Common::getNameById($infoResume->diploma) !!}.</li>
        <li><strong>Cấp bậc mong muốn: </strong>{!! Common::getNameById($infoResume->diploma_wish) !!}.</li>
        <li><strong>Trình độ cao nhất: </strong>{!! Common::getNameById($infoResume->level) !!}.</li>
        <li><strong>Nhu cầu làm việc: </strong>{!! Common::getNameById($infoResume->exigency) !!}.</li>
        <li><strong>Tiền lương mong muốn: </strong>{!! number_format($infoResume->wage,0,",",".") !!}.</li>
      </ul>
      <h3>Giới thiệu về bản thân</h3>
        <div class="row work-experience">
        <p style="margin-left: 15px;">{!! $infoResume->description !!}</p>
        </div>
        <h3>Trình độ học vấn</h3>
          <div class="row work-experience">
            <div class="col-sm-2">
              <div class="img-circle">
                <i class="fa fa-graduation-cap"></i>
              </div>
            </div>
            <div class="col-sm-10">
            <ul>
              <li> <strong>Trình độ: </strong><span>{!! Common::getNameById($infoDetailResume->level); !!}</span></li>
              <li> <strong>Đơn vị đào tạo: </strong><span>{!! $infoDetailResume->school_name !!}</span></h6>
              <li> <strong>Thời gian đào tạo: </strong>{!! $infoDetailResume->start_time_school . 'Đến' . $infoDetailResume->end_time_school !!}</li>
              <li> <strong>Chuyên ngành: </strong>{!! $infoDetailResume->description_diploma !!}</li>
              <li> <strong>Loại tốt nghiệp: </strong>{!! Common::getNameById($infoDetailResume->loai_tn); !!}</li>
              @if(isset($infoDetailResumeDiploma->language) && $infoDetailResumeDiploma->language != NULL)
              <li><strong>Ngoại ngữ: </strong>{!! Common::getNameById($infoDetailResumeDiploma->language); !!}<br>
                <strong>Trình độ ngoại ngữ: </strong>{!! Common::getNameById($infoDetailResumeDiploma->language_level); !!}<br>
                <table class="table table-bordered">
                <tr>
                  <th>Nghe</th>
                  <th>Nói</th>
                  <th>Đọc</th>
                  <th>Viết</th>
                </tr>
                <tr>
                  <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->listen); !!}</td>
                  <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->speak); !!}</td>
                  <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->read); !!}</td>
                  <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->write); !!}</td>
                </tr>
              </table>
              </li>
              @endif

              <li><strong>Tin học văn phòng: </strong>
              <table class="table table-bordered">
                <tr>
                  @if($infoDetailResumeDiploma->ms_word != NULL) <th>MS word</th> @endif
                  @if($infoDetailResumeDiploma->ms_excel != NULL) <th>MS Excel</th> @endif
                  @if($infoDetailResumeDiploma->ms_power_point != NULL) <th>MS Power Point</th> @endif
                  @if($infoDetailResumeDiploma->ms_outlook != NULL) <th>MS Outlook</th> @endif
                </tr>
                <tr>
                  @if($infoDetailResumeDiploma->ms_word != NULL) <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_word); !!}</td> @endif
                  @if($infoDetailResumeDiploma->ms_excel != NULL) <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_excel); !!}</td> @endif
                  @if($infoDetailResumeDiploma->ms_power_point != NULL) <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_power_point); !!}</td> @endif
                  @if($infoDetailResumeDiploma->ms_outlook != NULL) <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_outlook); !!}</td> @endif
                </tr>
              </table>
              </li>
              <li><strong>Kỹ năng khác: </strong>{!! $infoDetailResumeDiploma->others; !!}</li>
            </ul>
            </div>
          </div>
        <h3>Kinh nghiệm làm việc</h3>
          <div class="row work-experience">
            <div class="col-sm-2">
              <div class="img-circle">
                <i class="fa fa-briefcase"></i>
              </div>
            </div>
            <div class="col-sm-10">
            <h4>Tên công ty: </h4><h5>{!! $infoDetailResume->company; !!}</h5>
            <h4>Giới thiệu công ty: </h4><p>{!! $infoDetailResume->intro; !!}</p>
            <ul>
              <li><strong>Vị trí: </strong>{!! $infoDetailResume->position; !!}</li>
              <li><strong>Thời gian: </strong>{!! $infoDetailResume->start_time . ' Đến ' . $infoDetailResume->end_time; !!}</li>
              @if($infoDetailResume->wage != NULL)
              <li><strong>Mức Lương: </strong>{!!  number_format($infoDetailResume->wage,0,",","."); !!}</li>
              @endif
            </ul>
            <strong>Mô tả công việc: </strong><p>{!! $infoDetailResume->description_job; !!}</p>
            <strong>Thành tích công việc: </strong><p>{!! $infoDetailResume->achieve; !!}</p>
            </div>
          </div>
              <p>&nbsp;</p>
              <a href="{!! url('in-ho-so/'. $infoResume->user_id) !!}" class="btn btn-primary btn-lg" target="_blank"><i class="fa fa-arrow-down"></i>In hồ sơ</a>
              <a href="{!! url('nha-tuyen-dung/nop-ho-so/'. $infoResume->user_id) !!}" class="btn btn-warning btn-lg pull-right">Lưu hồ sơ</a>
            </article>
          </div>
          <div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindResume')
            </div>
            </div>
</div>
@endsection

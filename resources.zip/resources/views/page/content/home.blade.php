<?php
use App\Info, App\Common;
$seo = Info::getSeo();
?>

@extends('page.master')

@section('title', $seo->title)
@section('description', $seo->meta_desc)
@section('keywords', $seo->meta_key)

{{-- Start Slider --}}
@section('slider')
<div id="slider" class="sl-slider-wrapper">

      <div class="sl-slider">
      @foreach($listSlider as $k => $slider)
      @if($k%2 == 0)
        <div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-25" data-slice2-rotation="-25" data-slice1-scale="2" data-slice2-scale="2">
          <div class="sl-slide-inner">
            <div class="bg-img" style="background-image:url({!! $slider->image_link !!})"></div>
            <div class="tint"></div>
            <div class="slide-content">
              <h2>{!! $slider->title !!}</h2>
              <h3>{!! $slider->intro !!}</h3>
              <p><a href="{!! url('bai-viet/' . $slider->alias . '-' . $slider->id . '.html') !!}" class="btn btn-lg btn-default">Xem chi tiết</a></p>
            </div>
          </div>
        </div>
      @else
        <div class="sl-slide" data-orientation="vertical" data-slice1-rotation="10" data-slice2-rotation="-15" data-slice1-scale="1.5" data-slice2-scale="1.5">
          <div class="sl-slide-inner">
            <div class="bg-img" style="background-image:url({!! $slider->image_link !!})"></div>
            <div class="tint"></div>
            <div class="slide-content">
              <h2>{!! $slider->title !!}</h2>
              <h3>{!! $slider->intro !!}</h3>
              <p><a href="{!! url('bai-viet/' . $slider->alias . '-' . $slider->id . '.html') !!}" class="btn btn-lg btn-default">Xem chi tiết</a></p>
            </div>
          </div>
        </div>
        @endif
        @endforeach
      </div>

      <nav id="nav-arrows" class="nav-arrows">
        <span class="nav-arrow-prev">Previous</span>
        <span class="nav-arrow-next">Next</span>
      </nav>

      <nav id="nav-dots" class="nav-dots">
        <span class="nav-dot-current"></span>
        <span></span>
        <span></span>
        <span></span>
      </nav>

    </div>
@endsection
{{-- End Slider --}}

{{-- Start News Jobs --}}
@section('newsJobs')
@include('page.blocks.news_job')
@endsection
{{-- End News Jobs --}}

{{-- Start colRight --}}
@section('colRight')
@include('page.blocks.colRight')
@endsection
{{-- End colRight --}}

@section('content')
<div class="row">
          <div class="col-sm-8">
  <div role="tabpanel">

              <!-- Nav pills -->
              <ul class="nav nav-pills nav-justified">
                <li role="presentation" class="active"><a href="#work" aria-controls="work" role="tab" data-toggle="tab">Việc Hot</a></li>
                <li role="presentation"><a href="#fun" aria-controls="fun" role="tab" data-toggle="tab">Việc Lương Cao</a></li>
                <li role="presentation"><a href="#life" aria-controls="life" role="tab" data-toggle="tab">Việc Gấp</a></li>
                <li role="presentation"><a href="#life2" aria-controls="life" role="tab" data-toggle="tab">Việc Mới</a></li>
              </ul>

              <!-- Tab panes -->
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="work">

            <div class="jobs">
              @foreach($hotJob as $k => $hJob)
              <!-- Job offer 1 -->
              @if($k <= 2)
              <div class="custom-find-job">
              @endif
                <div class="featured"></div>
                <div class="title">
                <a href="{!! url('cong-viec/'. $hJob->alias . '-' . $hJob->id . '.html') !!}">
                  <h5>{!! $hJob->title !!}</h5>
                  </a>
                  <a href="{!! url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($hJob->employer_id)) . '-' . $hJob->employer_id . '.html') !!}">
                  <p>{!! Common::getCompanyNameById($hJob->employer_id) !!}</p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                    <?php $arrProvinRelated = explode(',', str_replace('^', '', $hJob->provin)); ?>
                    @foreach($arrProvinRelated as $ke => $provin)
                   <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                    {!! Common::getProvinNameById($provin) !!}
                    </a>
                    @if($ke != (count($arrProvinRelated) - 1))
                    ,
                    @endif
                  @endforeach
                  </span>
                  <span class="type full-time"><i class="fa fa-clock-o"></i>
                  {!! Common::getTypeNameById($hJob->type) !!}
                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i>
                  {!! Common::getNameById($hJob->wage) !!}
                  </span>
                </div>
              </div>
              @endforeach
            </div>

            <a class="btn btn-primary" href="{!! url('viec-lam-hot') !!}">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="fun">
                  <div class="jobs">
              @foreach($highJob as $k => $hwJob)
              <!-- Job offer 1 -->
              @if($k <= 2)
              <div class="custom-find-job">
              @endif
                <div class="featured"></div>
                <div class="title">
                <a href="{!! url('cong-viec/'. $hwJob->alias . '-' . $hwJob->id . '.html') !!}">
                  <h5>{!! $hwJob->title !!}</h5>
                  </a>
                  <a href="{!! url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($hwJob->employer_id)) . '-' . $hwJob->employer_id . '.html') !!}">
                  <p>{!! Common::getCompanyNameById($hwJob->employer_id) !!}</p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                    <?php $arrProvinRelated = explode(',', str_replace('^', '', $hwJob->provin)); ?>
                    @foreach($arrProvinRelated as $ke => $provin)
                   <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                    {!! Common::getProvinNameById($provin) !!}
                    </a>
                    @if($ke != (count($arrProvinRelated) - 1))
                    ,
                    @endif
                  @endforeach
                  </span>
                  <span class="type full-time"><i class="fa fa-clock-o"></i>
                  {!! Common::getTypeNameById($hwJob->type) !!}
                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i>
                  {!! Common::getNameById($hwJob->wage) !!}
                  </span>
                </div>
              </div>
              @endforeach
            </div>
            <a class="btn btn-primary" href="{!! url('viec-lam-luong-cao') !!}">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="life">
                  <div class="jobs">
              @foreach($gapJob as $k => $gJob)
              <!-- Job offer 1 -->
              @if($k <= 2)
              <div class="custom-find-job">
              @endif
                <div class="featured"></div>
                <div class="title">
                <a href="{!! url('cong-viec/'. $gJob->alias . '-' . $gJob->id . '.html') !!}">
                  <h5>{!! $gJob->title !!}</h5>
                  </a>
                  <a href="{!! url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($gJob->employer_id)) . '-' . $gJob->employer_id . '.html') !!}">
                  <p>{!! Common::getCompanyNameById($gJob->employer_id) !!}</p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                    <?php $arrProvinRelated = explode(',', str_replace('^', '', $gJob->provin)); ?>
                    @foreach($arrProvinRelated as $ke => $provin)
                   <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                    {!! Common::getProvinNameById($provin) !!}
                    </a>
                    @if($ke != (count($arrProvinRelated) - 1))
                    ,
                    @endif
                  @endforeach
                  </span>
                  <span class="type full-time"><i class="fa fa-clock-o"></i>
                  {!! Common::getTypeNameById($gJob->type) !!}
                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i>
                  {!! Common::getNameById($gJob->wage) !!}
                  </span>
                </div>
              </div>
              @endforeach
            </div>
            <a class="btn btn-primary" href="{!! url('viec-lam-dang-gap') !!}">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
                <div role="tabpanel" class="tab-pane" id="life2">
                  <div class="jobs">
              @foreach($newJob as $k => $nJob)
              <!-- Job offer 1 -->
              @if($k <= 2)
              <div class="custom-find-job">
              @endif
                <div class="featured"></div>
                <div class="title">
                <a href="{!! url('cong-viec/'. $nJob->alias . '-' . $nJob->id . '.html') !!}">
                  <h5>{!! $nJob->title !!}</h5>
                  </a>
                  <a href="{!! url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($nJob->employer_id)) . '-' . $nJob->employer_id . '.html') !!}">
                  <p>{!! Common::getCompanyNameById($nJob->employer_id) !!}</p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                    <?php $arrProvinRelated = explode(',', str_replace('^', '', $nJob->provin)); ?>
                    @foreach($arrProvinRelated as $ke => $provin)
                   <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                    {!! Common::getProvinNameById($provin) !!}
                    </a>
                    @if($ke != (count($arrProvinRelated) - 1))
                    ,
                    @endif
                  @endforeach
                  </span>
                  <span class="type full-time"><i class="fa fa-clock-o"></i>
                  {!! Common::getTypeNameById($nJob->type) !!}
                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i>
                  {!! Common::getNameById($nJob->wage) !!}
                  </span>
                </div>
              </div>
              @endforeach
            </div>
            <a class="btn btn-primary" href="{!! url('viec-lam-moi') !!}">
              <span class="more">Xem nhiều hơn <i class="fa fa-arrow-down"></i></span>
            </a>
                </div>
              </div>

            </div>

</div>
          <div class="col-sm-4">
          <h2>Nhà tuyển dụng nổi bật</h2>
          @foreach($companyJobs as $k => $company)
            <div> 
            
              <div class="featured-job">
              <a href="{!! url('cong-ty/'. $company->alias . '-' . $company->id . '.html') !!}">
                <p class="thumbnail">
                <img src="{!! url('public\upload\company\\'). $company->logo !!}" alt="{!! $company->name !!}" />
                </p>
                <div class="title">
                  <h5>{!! $company->name !!}</h5>
                </div>
                </a>
                <div class="data">
                  <strong>Điạ Chỉ: </strong><p>{!! $company->address !!}</p>
                  <strong>Điện Thoại: </strong><p>{!! $company->phone !!}</p>
                  <strong>Website: </strong><a href="http://{!! $company->website !!}" target="_blank">{!! $company->website !!}</a>
                </div>
                <div class="description">{!!  $company->so_luot !!}</div>
              </div>
            </div>
            <hr>
            @endforeach
</div>
</div>
@endsection


{{-- DOANH NGHIỆP TUYỂN DỤNG --}}
@section('companies')
<section id="companies" class="color1">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h2>Doanh Nghiệp Tuyển Dụng</h2>
            <ul id="featured-companies" class="row">
            @foreach($companyTuyenDung as $k => $tuyenDung)
              <li class="col-sm-4 col-md-3">
                <a href="{!! url('cong-ty/'. $tuyenDung->alias . '-' . $tuyenDung->id . '.html') !!}">
                  <img src="{!! url('public\upload\company\\'). $tuyenDung->logo !!}" alt="{!! $tuyenDung->name !!}" />
                  <span class="badge">{!!  $tuyenDung->total !!}</span>
                </a>
              </li>
              @endforeach
            </ul>
          </div>
        </div>
      </div>
</section>
@endsection
{{-- END DOANH NGHIỆP TUYỂN DỤNG --}}


{{-- JOBSEEK STATS --}}
@section('stats')
@include('page.blocks.stats')
@endsection
{{-- END JOBSEEK STATS --}}

{{-- Start Client --}}
@section('clients')
@include('page.blocks.clients')
@endsection
{{-- END Client --}}
@extends('page.master')
@section('title', $detailPost->title)
@section('content')

<div class="row" style="margin-top: 100px">
<section id="title">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<img src="{!! $detailPost->image_link !!}" alt="" class="img-responsive img-circle" />
					</div>
					<div class="col-sm-10">
						<h1>{!! $detailPost->title !!}</h1>
						<div class="meta">
							<span><i class="fa fa-user"></i>Admin</span>
							<span><i class="fa fa-calendar"></i>{!! Carbon\Carbon::parse($detailPost->created_at)->format('d/m/Y') !!}</span>
							<span><i class="fa fa-comment"></i>{!! $detailPost->views !!}</span>
						</div>
					</div>
				</div>
			</div>
		</section>
		<br>
<div class="col-sm-8">

						<!-- POSTS START -->

						<article>
							<h4>{!! $detailPost->intro !!}</h4>
							<br>
							<div>{!! $detailPost->content !!}</div>
						</article>

						<!-- POSTS END -->

						

						<!-- COMMENTS START -->

						<div class="row">
							<div class="col-sm-12">
								<div class="fb-comments" data-href="{!! url()->current(); !!}" data-width="100%" data-numposts="10"></div>
							</div>
						</div>

						<!-- COMMENTS END -->

						<hr>

						<!-- COMMENT FORM START -->

						
						
					</div>

					 <div class="col-sm-4" id="sidebar">
		          <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindJob')
            </div>
            </div>

</div>

@endsection

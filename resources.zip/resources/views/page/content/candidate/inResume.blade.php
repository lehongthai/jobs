<?php use App\Common; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="@yield('description')">
    <meta name="keywords" content="@yield('keywords')" />
    <meta name="author" content="Coffeecream Themes, info@coffeecream.eu">
    <title>{!! $infoResume->title !!}</title>
    <link rel="shortcut icon" href="images/favicon.png">
    <link href="{!! url('public/page') !!}/css/style.css" rel="stylesheet">
    <script src="{!! url('public/page') !!}/js/jquery-1.11.2.min.js"></script>
    <!-- Bootstrap Plugins -->
    <script src="{!! url('public/page') !!}/js/bootstrap.min.js"></script>

<body id="home_print">
<section id="jobs">
      <div class="container">
			<div class="row">
			<section id="title">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<h3>{!! $infoResume->title !!}</h3>
							<h6>Duyệt tin: {!! Carbon\Carbon::parse($infoResume->time_duyet)->format('d/m/Y') !!} - Lượt xem: {!! $infoResume->view !!}</h6>
						</div>
					</div>
				</div>
			</section>
			<hr>
		<article>
		<h2>Chi tiết hồ sơ</h2>
		<div class="col-sm-4">
			<a onclick="return false;" class="thumbnail">
				<img src="{!! url('public\upload\avatar\\') . $infoUser->avatar !!}" alt="" class="pull-left" />
			</a>
		</div>
		<div class="col-sm-8">
		<table>
			<tr>
				<th>Họ Tên:</th>
				<td>{!! $infoUser->fullname !!}</td>
			</tr>
			<tr>
				<th>Ngày sinh:</th>
				<td>{!! Carbon\Carbon::parse($infoResume->birthday)->format('d/m/Y') !!}</td>
			</tr>
			<tr>
				<th>Giới Tính:</th>
				<td>
				@if($infoUser->sex == 1)
				Nam
				@elseif($infoUser->sex == 2)
				Nữ
				@else
				Chưa xác định
				@endif
				</td>
			</tr>
			<tr>
				<th>Email liên hệ: </th>
				<td>{!! $infoUser->email !!}</td>
			</tr>
			<tr>
				<th>Điện Thoại:</th>
				<td>{!! $infoUser->phone !!}</td>
			</tr>
			<tr>
				<th>Địa chỉ:</th>
				<td>{!! $infoUser->address !!}</td>
			</tr>
		</table>
		</div>
		<hr><hr><hr><hr><hr>
			<h3>Thông tin chung</h3>
			<ul>
				<li><strong>Ngành nghề: </strong>{!! Common::getTypeNameById($infoResume->type) !!}.</li>
				<li><strong>Loại việc làm: </strong>
				<?php $arrJob = explode(',', str_replace('^', '', $infoResume->jobs_wish)); ?>
				@foreach($arrJob as $k => $job)
					{!! Common::getJobNameById($job) !!}
					@if($k != (count($arrJob) - 1))
                    ,
                    @endif
                 @endforeach
				.</li>
				<li><strong>Nơi làm việc</strong>
				<?php $arrProvin = explode(',', str_replace('^', '', $infoResume->provin_wish)); ?>
				@foreach($arrProvin as $k => $provin)
					{!! Common::getProvinNameById($provin) !!}
					@if($k != (count($arrProvin) - 1))
                    ,
                    @endif
                 @endforeach
				.</li>
				<li><strong>Số năm kinh nghiệm: </strong>{!! Common::getNameById($infoResume->empirical) !!}.</li>
				<li><strong>Cấp bậc hiện tại: </strong>{!! Common::getNameById($infoResume->diploma) !!}.</li>
				<li><strong>Cấp bậc mong muốn: </strong>{!! Common::getNameById($infoResume->diploma_wish) !!}.</li>
				<li><strong>Trình độ cao nhất: </strong>{!! Common::getNameById($infoResume->level) !!}.</li>
				<li><strong>Nhu cầu làm việc: </strong>{!! Common::getNameById($infoResume->exigency) !!}.</li>
				<li><strong>Tiền lương mong muốn: </strong>{!! number_format($infoResume->wage,0,",",".") !!}.</li>
			</ul>
			<h3>Giới thiệu về bản thân</h3>
				<div class="row work-experience">
				<p style="margin-left: 15px;">{!! $infoResume->description !!}</p>
				</div>
				<h3>Trình độ học vấn</h3>
					<div class="row work-experience">
						<div class="col-sm-2">
							<div class="img-circle">
								<i class="fa fa-graduation-cap"></i>
							</div>
						</div>
						<div class="col-sm-10">
						<ul>
							<li> <strong>Trình độ: </strong><span>{!! Common::getNameById($infoDetailResume->level); !!}</span></li>
							<li> <strong>Đơn vị đào tạo: </strong><span>{!! $infoDetailResume->school_name !!}</span></h6>
							<li> <strong>Thời gian đào tạo: </strong>{!! $infoDetailResume->start_time_school . 'Đến' . $infoDetailResume->end_time_school !!}</li>
							<li> <strong>Chuyên ngành: </strong>{!! $infoDetailResume->description_diploma !!}</li>
							<li> <strong>Loại tốt nghiệp: </strong>{!! Common::getNameById($infoDetailResume->loai_tn); !!}</li>
							@if(isset($infoDetailResumeDiploma->language) && $infoDetailResumeDiploma->language != NULL)
							<li><strong>Ngoại ngữ: </strong>{!! Common::getNameById($infoDetailResumeDiploma->language); !!}<br>
								<strong>Trình độ ngoại ngữ: </strong>{!! Common::getNameById($infoDetailResumeDiploma->language_level); !!}<br>
								<table class="table table-bordered">
								<tr>
									<th>Nghe</th>
									<th>Nói</th>
									<th>Đọc</th>
									<th>Viết</th>
								</tr>
								<tr>
									<td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->listen); !!}</td>
									<td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->speak); !!}</td>
									<td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->read); !!}</td>
									<td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->write); !!}</td>
								</tr>
							</table>
							</li>
							@endif

							<li><strong>Tin học văn phòng: </strong>
							<table class="table table-bordered">
								<tr>
									@if($infoDetailResumeDiploma->ms_word != NULL) <th>MS word</th> @endif
									@if($infoDetailResumeDiploma->ms_excel != NULL) <th>MS Excel</th> @endif
									@if($infoDetailResumeDiploma->ms_power_point != NULL) <th>MS Power Point</th> @endif
									@if($infoDetailResumeDiploma->ms_outlook != NULL) <th>MS Outlook</th> @endif
								</tr>
								<tr>
									@if($infoDetailResumeDiploma->ms_word != NULL) <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_word); !!}</td> @endif
									@if($infoDetailResumeDiploma->ms_excel != NULL) <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_excel); !!}</td> @endif
									@if($infoDetailResumeDiploma->ms_power_point != NULL) <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_power_point); !!}</td> @endif
									@if($infoDetailResumeDiploma->ms_outlook != NULL) <td>{!! Common::getTypeLanguageAndTech($infoDetailResumeDiploma->ms_outlook); !!}</td> @endif
								</tr>
							</table>
							</li>
							<li><strong>Kỹ năng khác: </strong>{!! $infoDetailResumeDiploma->others; !!}</li>
						</ul>
						</div>
					</div>
				<h3>Kinh nghiệm làm việc</h3>
					<div class="row work-experience">
						<div class="col-sm-2">
							<div class="img-circle">
								<i class="fa fa-briefcase"></i>
							</div>
						</div>
						<div class="col-sm-10">
						<h4>Tên công ty: </h4><h5>{!! $infoDetailResume->company; !!}</h5>
						<h4>Giới thiệu công ty: </h4><p>{!! $infoDetailResume->intro; !!}</p>
						<ul>
							<li><strong>Vị trí: </strong>{!! $infoDetailResume->position; !!}</li>
							<li><strong>Thời gian: </strong>{!! $infoDetailResume->start_time . ' Đến ' . $infoDetailResume->end_time; !!}</li>
							@if($infoDetailResume->wage != NULL)
							<li><strong>Mức Lương: </strong>{!!  number_format($infoDetailResume->wage,0,",","."); !!}</li>
							@endif
						</ul>
						<strong>Mô tả công việc: </strong><p>{!! $infoDetailResume->description_job; !!}</p>
						<strong>Thành tích công việc: </strong><p>{!! $infoDetailResume->achieve; !!}</p>
						</div>
					</div>
							<p>&nbsp;</p>
							<p><button type="button" class="btn btn-success" onclick="openWin()">In hồ sơ</button></p>
						</article>
				</div>
</li></ul></div></div></article></div></div></section>
<script type="text/javascript">
  function openWin()
  {
   /* var printContent = document.getElementById('home_print');
    var myWindow=window.open('','','width=700,height=1200');
    myWindow.moveTo(300,200);
    myWindow.document.write('<html><head>');
    myWindow.document.write('<meta charset="utf-8">');
    myWindow.document.write('<meta http-equiv="X-UA-Compatible" content="IE=edge">');
    myWindow.document.write('<meta name="viewport" content="width=device-width, initial-scale=1">');
    myWindow.document.write('<title>Hồ sơ {!! $infoResume->title !!}</title>');
    myWindow.document.write('<link href="{!! url('public/page') !!}/css/style.css" rel="stylesheet">');
    myWindow.document.write('<style type="text/css">');
    myWindow.document.write('</head><body>');
    myWindow.document.write(printContent.innerHTML); 
    myWindow.document.write('</body></html>'); 
    myWindow.document.close();
    setTimeout(function(){
      myWindow.focus();
      myWindow.print();
      myWindow.close();
    }, 500);
    */
     window.print();
  }
</script>
</body>
</html>


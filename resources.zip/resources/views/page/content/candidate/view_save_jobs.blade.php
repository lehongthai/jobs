@extends('page.master')
@section('title', $title)
@section('content')
{{-- add menu user --}}
@include('page.blocks.menu_bottom_user')
{{-- end menu user --}}
<div class="row" style="margin-top: 100px">
<div class="col-sm-8">
@include('page.blocks.info')
	<table class="table table-bordered" id="datatable-savejob">
		<thead>
			<tr style="background-color: #14B1BB">
				<th>Thứ tự</th>
				<th>Vị Trí</th>
				<th>Công Ty</th>
				<th>Cập Nhật</th>
				<th>Xóa</th>
			</tr>
		</thead>
		<tbody>
		@foreach($listSaveJobs as $key => $saveJob)
			<tr>
				<td>{!! $key + 1 !!}</td>
				<td><a href="{!! url('cong-viec/' . convert_vi_to_en($saveJob->title) . '-' . $saveJob->pId . '.html') !!}">{!! $saveJob->title !!}</a></td>
				<td>
				<a href="{!! url('cong-ty'). '/' . $saveJob->alias . '-' . $saveJob->cId . '.html' !!}">
				{!! $saveJob->name !!}
				</a></td>
				<td>{!! Carbon\Carbon::parse($saveJob->cCreateDate)->format('d/m/Y') !!}</td>
				<td><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="{!! url('ung-vien/xoa-viec-lam-da-luu/' . $saveJob->cjId) !!}">Xóa</a></td>
			</tr>
		@endforeach
		</tbody>
	</table>
</div>
<div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindJob')
            </div>
            </div>
</div>
@endsection

@section('javascript')
<script src="{!! url('public/admin') !!}/bower_components/DataTables/media/js/jquery.dataTables.min.js"></script>
    <script src="{!! url('public/admin') !!}/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    $('#datatable-savejob').DataTable({
    	"language": {
            "lengthMenu": "Hiển thị _MENU_ Số lượng tin hiển thị",
            "zeroRecords": "Không có kết quả nào",
            "info": "Hiển thị tin _PAGE_ của _PAGES_",
            "infoEmpty": "Không có kết quả nào",
            "infoFiltered": "(filtered from _MAX_ total records)",
            "sSearch":        "Tìm Kiếm: "
        }
    });
    $(".input-sm").css({
    	height: '40px'
  	});
});
	
</script>
@endsection


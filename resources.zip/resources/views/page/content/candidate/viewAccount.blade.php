@extends('page.master')
@section('title', $title)
@section('content')
@include('page.blocks.loginInline')
{{-- add menu user --}}
@include('page.blocks.menu_bottom_user')
{{-- end menu user --}}
<div class="row" style="margin-top: -180px">
<div class="col-sm-8">
@include('page.blocks.info')
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title text-center">Thông Tin Tài Khoản -  <strong>{!! $infoCandidate->fullname !!}</strong></h3>
  </div>
  <div class="panel-body">
    <div class="table-responsive">
      <table class="table table-hover table-bordered">
        <tbody>
          <tr>
            <th>Tên đầy đủ</th>
            <td>{!! $infoCandidate->fullname !!}</td>
          </tr>
          <tr>
            <th>Ảnh hiển thị</th>
            <td>
              <a onclick="return false;" class="thumbnail">
                <img src="{!! url('public\upload\avatar\\') . $infoCandidate->avatar !!}">
              </a>
            </td>
          </tr>
          <tr>
            <th>Email đăng nhập</th>
            <td>{!! $infoCandidate->email !!}</td>
          </tr>
          <tr>
            <th>Loại tài khoản</th>
            <td>
            @if($infoCandidate->level == 1)
            Người tìm việc
            @elseif($infoCandidate->level == 2)
            Nhà tuyển dụng
            @elseif($infoCandidate->level == 3)
            Quản trị
            @endif
            </td>
          </tr>
          <tr>
            <th>Trạng thái tài khoản</th>
            <td>
            @if($infoCandidate->active == 1)
            Đã kích hoạt
            @else
            Chưa kích hoạt
            @endif
            </td>
          </tr>
          <tr>
            <th>Ngày tạo</th>
            <td>{!! Carbon\Carbon::parse($infoCandidate->created_at)->format('d/m/Y') !!}</td>
          </tr>
          <tr>
            <th>Ngày cập nhật</th>
            <td>{!! Carbon\Carbon::parse($infoCandidate->updated_at)->format('d/m/Y') !!}</td>
          </tr>
          <tr>
            <th>Giới tính</th>
            <td>
              @if($infoCandidate->sex == 1)
              Nam
              @elseif($infoCandidate->active == 2)
              Nữ
              @else
              Không xác định
              @endif
            </td>
          </tr>
          <tr>
            <th>Ngày sinh</th>
            <td>{!! Carbon\Carbon::parse($infoCandidate->birthday)->format('d/m/Y') !!}</td>
          </tr>
          <tr>
            <th>Điện thoại</th>
            <td>{!! $infoCandidate->phone !!}</td>
          </tr>
          <tr>
            <th>Địa chỉ</th>
            <td>{!! $infoCandidate->address !!}</td>
          </tr>
          <tr>
            <th>Tỉnh - Thành Phố</th>
            <td>{!! $infoCandidate->name !!}</td>
          </tr>
        </tbody>

      </table>
      <button type="button" class="btn btn-large btn-block btn-info" onclick="window.location='{!! url('ung-vien/cap-nhat') !!}'">Cập nhật</button>
      <button type="button" class="btn btn-large btn-block btn-danger" onclick="window.location='{!! url('ung-vien/thay-doi-mat-khau') !!}'">Đổi mật khẩu</button>
    </div>
  </div>
</div>
</div>
<div class="col-sm-4" id="sidebar">
            <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindJob')
            </div>
          </div>
</div>
@endsection

@extends('page.master')
@section('content')
@include('page.blocks.loginInline')
{{-- add menu user --}}
@include('page.blocks.menu_bottom_user')
{{-- end menu user --}}
<div class="row" style="margin-top: -180px">
<div class="col-sm-8">

        <form enctype="multipart/form-data" method="post" action="{!! url('ung-vien/cap-nhat') !!}" id="form-register">
        <input type="hidden" name="_token" id="input_token" class="form-control" value="{!! csrf_token() !!}">
        <input type="hidden" name="typeUser" class="form-control" value="1">
         
          <div class="text-center"><h3>Cập nhật tài khoản</h3></div>

          <div class="row">
          <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
            <label>Ảnh đại diện</label>
          </div>
          <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
            <div class="form-group">
            <a class="thumbnail">
              <img id="targetLogo" alt="logo" src="{!! url('public\upload\avatar\\') . $infoCandidate->avatar !!}">
            </a>
              <input type='file' id="imageAvatar" name="imageAvatar" value="{!! old('imageAvatar') !!}" />
               <span style="color:red">{!! $errors->first('imageAvatar') !!}</span>
            </div>
          </div>
            <div class="col-sm-6">
            <div class="form-group">
                <label>Họ Tên</label><span class="require">*</span>
                <input type="text" class="form-control" id="login-username" name="fullname" value="{!! old('fullname', $infoCandidate->fullname) !!}">
                <span style="color:red">{!! $errors->first('fullname') !!}</span>
              </div>
              <div class="form-group">
                <label>Số Điện Thoại</label><span class="require">*</span>
                <input type="text" class="form-control" name="phone" value="{!! old('phone', $infoCandidate->phone) !!}">
                <span style="color:red">{!! $errors->first('phone') !!}</span>
              </div>
              <div class="form-group">
                <label>Tỉnh/ Thành Phố</label><span class="require">*</span>
                <select name="provin" id="inputSex" class="form-control">
                  <option value="">-- Vui lòng chọn --</option>
                  @foreach($listProvin as $key => $provin)
                  <option value="{!! $provin->id !!}" @if(old('provin') == $provin->id || $infoCandidate->provin == $provin->id) selected @endif>-- {!! $provin->name !!} --</option>
                  @endforeach
                </select>
                <span style="color:red">{!! $errors->first('provin') !!}</span>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label>Ngày Sinh</label><span class="require">*</span>

                <input type="date" name="birthday" class="form-control" value="{!! old('birthday', $infoCandidate->birthday) !!}">
                <span style="color:red">{!! $errors->first('birthday') !!}</span>
              </div>
              <div class="form-group">
                <label>Giới Tính</label><span class="require">*</span>
                <select name="sex" id="inputSex" class="form-control">
                  <option value="">-- Select One --</option>
                  <option value="1" @if(old('sex') == 1 || $infoCandidate->sex == 1) selected @endif>-- Nam --</option>
                  <option value="2" @if(old('sex') == 2 || $infoCandidate->sex == 2) selected @endif>-- Nữ --</option>
                </select>
                <span style="color:red">{!! $errors->first('sex') !!}</span>
              </div>
              
              <div class="form-group">
                <label>Địa Chỉ</label><span class="require">*</span>
                <textarea name="address" id="input" class="form-control" rows="3">{!! old('address', $infoCandidate->address) !!}</textarea>
                <span style="color:red">{!! $errors->first('address') !!}</span>
              </div>
            </div>
            
          </div>
          <div class="text-center">
	          <button type="submit" class="btn btn-primary">Cập nhật</button>
            <button type="button" class="btn btn-warning">Hủy bỏ</button>
	        </div>
        </form>
			</div>

<div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindJob')
            </div>
            </div>
</div>
@endsection

@section('javascript')
<script>



/*logo company*/
function readURL(input) {
  if (input.files && input.files[0]) {
            var reader = new FileReader();            
            reader.onload = function (e) {
                $('#targetLogo').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imageAvatar").change(function(){
        readURL(this);
    });
</script>
@endsection
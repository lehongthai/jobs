<?php use App\Common; ?>
@extends('page.master')
@section('title', $title)
@section('content')
<div class="row" style="margin-top: 100px">
<div class="col-sm-8">
@include('page.blocks.info')
{{-- add info user --}}
@include('page.blocks.info_user')
{{-- end info user --}}

{{-- add info user --}}
@include('page.blocks.info_resume_user')
{{-- end info user --}}

{{-- add menu user --}}
@include('page.blocks.menu_bottom_user')
{{-- end menu user --}}
<div class="row">
 <input type="hidden" name="_token" id="_token" value="{!! csrf_token() !!}">
            <div class="panel panel-primary">
              <div class="panel-heading text-center">
                <h3 class="panel-title">Giới Thiệu Công Ty Cũ</h3>
              </div>
              <div class="panel-body">
                <div id="intro_content">
                <p id="intro">{!! $detailCompany->intro !!}</p>
                </div>
                <div class="pull-right" id="intro_button_div">
                <button type="button" class="btn btn-xs btn-primary" id="get-modal-intro">Chỉnh Sửa</button>
              </div>
              </div>
            </div>
            <div class="panel panel-primary">
              <div class="panel-heading text-center">
                <h3 class="panel-title">Kinh Nghiệm Làm Việc</h3>
              </div>
              <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-hover table-bordered">
                    <tbody>
                      <tr>
                        <th>Tên Công Ty</th>
                        <th>{!! $detailCompany->company !!}</th>
                      </tr>
                      <tr>
                        <th>Chức Vụ</th>
                        <th>{!! $detailCompany->position !!}</th>
                      </tr>
                      <tr>
                        <th>Thời Gian Làm</th>
                        <th>Từ {!! $detailCompany->start_time . ' Đến ' .  $detailCompany->end_time !!}</th>
                      </tr>
                      <tr>
                        <th>Lương Được Hưởng</th>
                        <th>{!! number_format($detailCompany->wage, 0, '.', ',')  !!}</th>
                      </tr>
                      <tr>
                        <th>Mô Tả Công Việc</th>
                        <th>{!! $detailCompany->description_job !!}</th>
                      </tr>
                      <tr>
                        <th>Thành Tích</th>
                        <th>{!! $detailCompany->achieve !!}</th>
                      </tr>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="pull-right">
      <button type="button" id="get-modal-company" class="btn btn-xs btn-primary">Chỉnh Sửa</button>
    </div>
              </div>
              
            </div>
            <div class="panel panel-primary">
              <div class="panel-heading text-center">
                <h3 class="panel-title">Trình Độ & Bằng Cấp</h3>
              </div>
              <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-hover table-bordered">
                    <tbody>
                      <tr>
                        <th>Trình Độ</th>
                        <th>{!! Common::getNameById($detailCompany->level) !!}</th>
                      </tr>
                      <tr>
                        <th>Đơn Vị Đào Tạo</th>
                        <th>{!! $detailCompany->school_name !!}</th>
                      </tr>
                      <tr>
                        <th>Thời Gian Đào Tạo</th>
                        <th>Từ {!! $detailCompany->start_time_school . ' Đến ' . $detailCompany->end_time_school !!}</th>
                      </tr>
                      <tr>
                        <th>Chuyên Ngành</th>
                        <th>{!! $detailCompany->description_diploma !!}</th>
                      </tr>
                      <tr>
                        <th>Tốt Nghiệp Loại</th>
                        <th>{!! Common::getNameById($detailCompany->loai_tn) !!}</th>
                      </tr>
                      <tr>
                        <th>Bằng Tốt Nghiệp</th>
                        <th>@if($detailCompany->image_tn != NULL)
                        <img id="target" src="{!! url('public\upload\image_tn\\') . $detailCompany->image_tn !!}">@endif()</th>
                      </tr>
                      <tr>
                        <th>Ngoại Ngữ</th>
                        <th>{!! Common::getNameById($detailDiploma->language) !!}</th>
                      </tr>
                      <tr>
                        <th>Trình Độ Ngoại Ngữ</th>
                        <th>{!! Common::getNameById($detailDiploma->language_level) !!}</th>
                      </tr>
                      <tr>
                        <th>Chi Tiết Ngoại Ngữ</th>
                        <td>
                          <ul>
                            <li> Nghe : {!! Common::getTypeLanguageAndTech($detailDiploma->listen) !!}</li>
                            <li> Nói : {!! Common::getTypeLanguageAndTech($detailDiploma->speak) !!}</li>
                            <li> Đọc : {!! Common::getTypeLanguageAndTech($detailDiploma->read ) !!}</li>
                            <li> Viết : {!! Common::getTypeLanguageAndTech($detailDiploma->write) !!}</li>
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <th>Tin Học Văn Phòng</th>
                        <td>
                          <ul>
                            <li> MS Word : {!! Common::getTypeLanguageAndTech($detailDiploma->ms_word) !!}</li>
                            <li> MS Excel : {!! Common::getTypeLanguageAndTech($detailDiploma->ms_excel) !!}</li>
                            <li> MS Power Point : {!! Common::getTypeLanguageAndTech($detailDiploma->ms_power_point ) !!}</li>
                            <li> MS Outlook : {!! Common::getTypeLanguageAndTech($detailDiploma->ms_outlook) !!}</li>
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <th>Kỹ Năng Khác</th>
                        <td>{!! $detailDiploma->others !!}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="pull-right">
      <button type="button" id="get-modal-level" class="btn btn-xs btn-primary">Chỉnh Sửa</button>
    </div>
              </div>

            </div>
            <button type="button" class="btn btn-large btn-block btn-warning" onclick="window.location='{!! url('ung-vien/ho-so') !!}'">Xem bản chi tiết</button>
            </div>
</div>
<div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindJob')
            </div>
            </div>
</div>
<div class="modal fade" id="modal-intro">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Chỉnh Sửa Giới Thiệu Bản Thân</h4>
      </div>
      <div class="modal-body">
      <form action="{!! url('ung-vien/ho-so-ca-nhan') !!}" method="POST" class="form-horizontal" role="form">
      <input type="hidden" name="_token" value="{!! csrf_token() !!}">
      <input type="hidden" name="check_edit" value="edit_company_intro">
      <input type="hidden" name="id_company" value="{!! $detailCompany->id !!}">
        <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="intro">Giới Thiệu</label><span class="require">*</span>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <textarea name="intro" id="intro" class="form-control" rows="3">{!! old('intro', $detailCompany->intro) !!}</textarea>
                          <span style="color:red">{!! $errors->first('intro') !!}</span>
                    </div>
                    </div>
                  </div>
                  <div class="modal-footer text-center">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Hủy</button>
        <button type="submit" class="btn btn-primary">Lưu</button>
      </div>
                  </form>
      </div>
      
    </div>
  </div>
</div>
<div class="modal fade" id="modal-company">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Chỉnh Sửa Kinh Nghiệm Làm Việc</h4>
      </div>
      <div class="modal-body">
      <form action="{!! url('ung-vien/ho-so-ca-nhan') !!}" method="POST" class="form-horizontal" role="form">
      <input type="hidden" name="_token" value="{!! csrf_token() !!}">
      <input type="hidden" name="check_edit" value="edit_company">
      <input type="hidden" name="id_company" value="{!! $detailCompany->id !!}">
        <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="company">Tên Công Ty <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <input type="text" name="company" id="company" class="form-control" value="{!! old('company', $detailCompany->company) !!}">
                          <span style="color:red">{!! $errors->first('company') !!}</span>
                        </div>
                      </div>
                    </div> 
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="position">Chức Vụ <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <input type="text" name="position" id="position" class="form-control" value="{!! old('position',$detailCompany->position) !!}">
                          <span style="color:red">{!! $errors->first('position') !!}</span>
                        </div>
                      </div>
                    </div> 
                    
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label>Thời Gian <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                      <?php 
                        $arr_start = explode('/', $detailCompany->start_time);
                        $arr_end = explode('/', $detailCompany->end_time); 
                      ?>
                        <div class="form-group">
                          <table style="width: 100%">
                            <tr>
                              <td>Từ: </td>
                              <td>
                                <select name="start_month" id="start_month" class="form-control">
                                  @for($i = 1; $i < 13; $i++)
                                  <option value="{!! $i !!}" @if(old('start_month') == $i || $arr_start[0] == $i) selected @endif>Tháng {!! $i !!}</option>
                                  @endfor
                                </select>
                              </td>
                              <td>&nbsp;</td>
                              <td>
                                <select name="start_year" id="start_year" class="form-control">
                                  @for($i = 1940; $i <= date('Y'); $i++)
                                  <option value="{!! $i !!}" @if(old('start_year') == $i  || $arr_start[1] == $i) selected @endif>{!! $i !!}</option>
                                  @endfor
                                </select>
                              </td>
                              <td>&nbsp;</td>
                              <td>Đến: </td>
                              <td>
                                <select name="end_month" id="end_month" class="form-control">
                                  @for($i = 1; $i < 13; $i++)
                                  <option value="{!! $i !!}" @if(old('end_month') == $i  || $arr_end[0] == $i) selected @endif>Tháng {!! $i !!}</option>
                                  @endfor
                                </select>
                              </td>
                              <td>&nbsp;</td>
                              <td>
                                <select name="end_year" id="end_year" class="form-control">
                                  @for($i = 1940; $i <= date('Y'); $i++)
                                  <option value="{!! $i !!}" @if(old('end_year') == $i  || $arr_end[1] == $i) selected @endif>{!! $i !!}</option>
                                  @endfor
                                </select>
                              </td>
                            </tr>
                          </table>
                        </div>
                      </div>
                    </div>  
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label>Mức Lương</label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <table style="width: 100%">
                            <tr>
                              <td>
                                <select name="type_wage" id="type_wage" class="form-control">
                                  <option value="vnd">VND</option>
                                  <option value="usd">USD</option>
                                </select>
                              </td>
                              <td>&nbsp; &nbsp;</td>
                              <td>
                                <input type="text" name="wage" id="wage" class="form-control" value="{!! old('wage',$detailCompany->wage) !!}">
                              </td>
                            </tr>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="description_job">Mô Tả Công Việc</label><span class="require">*</span>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <textarea name="description_job" id="description_job" class="form-control" rows="3">{!! old('description_job', $detailCompany->description_job) !!}</textarea>
                          <span style="color:red">{!! $errors->first('description_job') !!}</span>
                    </div>
                    </div>
                  </div>
                  <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="achieve">Thành Tích</label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <textarea name="achieve" id="achieve" class="form-control" rows="3">{!! old('achieve',$detailCompany->achieve) !!}</textarea>
                          <span style="color:red">{!! $errors->first('achieve') !!}</span>
                    </div>
                    </div>
                  </div>
                  <div class="modal-footer text-center">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Hủy</button>
        <button type="submit" class="btn btn-primary">Lưu</button>
      </div>
                  </form>
      </div>
      
    </div>
  </div>
</div>
<div class="modal fade" id="modal-level">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Cập Nhật Trình Độ & Bằng Cấp</h4>
      </div>
      <div class="modal-body">
      <form action="{!! url('ung-vien/ho-so-ca-nhan') !!}" method="POST" class="form-horizontal" role="form" enctype="multipart/form-data">
      <input type="hidden" name="_token" value="{!! csrf_token() !!}">
      <input type="hidden" name="check_edit" value="edit_level">
      <input type="hidden" name="id_company" value="{!! $detailCompany->id !!}">
      <input type="hidden" name="id_level" value="{!! $detailDiploma->id !!}">
        <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="level">Trình Độ <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <select name="level" id="level" class="form-control">
                            <option>-- Vui Lòng Chọn Một --</option>
                            @foreach($listLevel as $level)
                             <option value="{!! $level->id !!}" @if(old('level') == $level->id || $detailCompany->level == $level->id) selected @endif>-- {!! $level->name !!} --</option>
                            @endforeach
                          </select>
                          <span style="color:red">{!! $errors->first('level') !!}</span>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="school_name">Đơn Vị Đào Tạo <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <input type="text" name="school_name" id="school_name" class="form-control" value="{!! old('school_name', $detailCompany->school_name) !!}">
                          <span style="color:red">{!! $errors->first('school_name') !!}</span>
                        </div>
                      </div>
                    </div> 
                    
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label>Thời Gian <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <table style="width: 100%">
                            <tr>
                              <td>Từ: </td>
                              <td>
                                <select name="start_time_school" id="start_time_school" class="form-control">
                                  @for($i = 2000; $i < date('Y'); $i++)
                                  <option value="{!! $i !!}" @if(old('start_time_school') == $i || $detailCompany->start_time_school == $i) selected @endif>{!! $i !!}</option>
                                  @endfor
                                </select>
                                <span style="color:red">{!! $errors->first('start_time_school') !!}</span>
                              </td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>Đến: </td>
                              <td>
                                <select name="end_time_school" id="end_time_school" class="form-control">
                                  @for($i = 2000; $i < date('Y'); $i++)
                                  <option value="{!! $i !!}" @if(old('end_time_school') == $i || $detailCompany->end_time_school == $i) selected @endif>{!! $i !!}</option>
                                  @endfor
                                </select>
                                 <span style="color:red">{!! $errors->first('end_time_school') !!}</span>
                              </td>
                            </tr>
                          </table>
                        </div>
                      </div>
                    </div>  
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="description_diploma">Chuyên Ngành <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <input type="text" name="description_diploma" id="description_diploma" class="form-control" value="{!! old('description_diploma', $detailCompany->description_diploma) !!}">
                          <span style="color:red">{!! $errors->first('description_diploma') !!}</span>
                        </div>
                      </div>
                    </div> 
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label>Loại Tốt Nghiệp <span class="require">*</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <select name="loai_tn" id="input" class="form-control">
                            <option>-- Vui Lòng Chọn Một --</option>
                            @foreach($listLoaiTn as $loai_tn)
                             <option value="{!! $loai_tn->id !!}" @if(old('loai_tn') == $loai_tn->id || $detailCompany->loai_tn == $loai_tn->id) selected @endif>-- {!! $loai_tn->name !!} --</option>
                            @endforeach
                          </select>
                          <span style="color:red">{!! $errors->first('loai_tn') !!}</span>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="image_tn">Tải Bằng Tốt Nghiệp <span>(nếu có)</span></label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                         <input type="file" name="image_tn" id="image_tn" class="form-control" value="{!! old('image_tn') !!}">
                         <span style="color:red">{!! $errors->first('image_tn') !!}</span>
                        </div>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="language">Ngoại Ngữ </label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <select name="language" id="language" class="form-control">
                            <option>-- Vui Lòng Chọn Một --</option>
                            @foreach($listLanguage as $language)
                             <option value="{!! $language->id !!}" @if(old('language') == $language->id || $detailDiploma->language == $language->id) selected @endif>-- {!! $language->name !!} --</option>
                            @endforeach
                          </select>
                          <span style="color:red">{!! $errors->first('language') !!}</span>
                        </div>
                      </div>
                    </div> 
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                        <label for="language_level">Trình Độ </label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div class="form-group">
                          <select name="language_level" id="language_level" class="form-control">
                            <option>-- Vui Lòng Chọn Một --</option>
                            @foreach($listLanguageLevel as $language_level)
                             <option value="{!! $language_level->id !!}" @if(old('language_level') == $language_level->id || $detailDiploma->language_level == $language_level->id) selected @endif>-- {!! $language_level->name !!} --</option>
                            @endforeach
                          </select>
                           <span style="color:red">{!! $errors->first('language_level') !!}</span>
                        </div>
                      </div>
                    </div> 
                    <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <table style="text-align: center; width: 100%">
                          <tr>
                            <td>&nbsp;</td>
                            <td>Tốt</td>
                            <td>Khá</td>
                            <td>Trung Bình</td>
                            <td>Kém</td>
                          </tr>
                          <tr>
                            <td>Nghe</td>
                            <td><input type="checkbox" value="1" name="listen_language" @if(old('listen_language') == 1 || $detailDiploma->listen == 1) checked @endif></td>
                            <td><input type="checkbox" value="2" name="listen_language" @if(old('listen_language') == 2 || $detailDiploma->listen == 2) checked @endif></td>
                            <td><input type="checkbox" value="3" name="listen_language" @if(old('listen_language') == 3 ||  $detailDiploma->listen == 3) checked @endif></td>
                            <td><input type="checkbox" value="4" name="listen_language" @if(old('listen_language') == 4 ||  $detailDiploma->listen == 4) checked @endif></td>
                          </tr>
                          <tr>
                            <td>Nói</td>
                            <td><input type="checkbox" value="1" name="speak_language" @if(old('speak_language') == 1 ||  $detailDiploma->speak == 1) checked @endif></td>
                            <td><input type="checkbox" value="2" name="speak_language" @if(old('speak_language') == 2 ||  $detailDiploma->speak == 2) checked @endif></td>
                            <td><input type="checkbox" value="3" name="speak_language" @if(old('speak_language') == 3 ||  $detailDiploma->speak == 3) checked @endif></td>
                            <td><input type="checkbox" value="4" name="speak_language" @if(old('speak_language') == 4 ||  $detailDiploma->speak == 4) checked @endif></td>
                          </tr>
                          <tr>
                            <td>Đọc</td>
                            <td><input type="checkbox" value="1" name="read_language" @if(old('read_language') == 1 ||  $detailDiploma->read == 1) checked @endif></td>
                            <td><input type="checkbox" value="2" name="read_language" @if(old('read_language') == 2 ||  $detailDiploma->read == 2) checked @endif></td>
                            <td><input type="checkbox" value="3" name="read_language" @if(old('read_language') == 3 ||  $detailDiploma->read == 3) checked @endif></td>
                            <td><input type="checkbox" value="4" name="read_language" @if(old('read_language') == 4 ||  $detailDiploma->read == 4) checked @endif></td>
                          </tr>
                          <tr>
                            <td>Viết</td>
                            <td><input type="checkbox" value="1" name="write_language" @if(old('write_language') == 1 ||  $detailDiploma->write == 1) checked @endif></td>
                            <td><input type="checkbox" value="2" name="write_language" @if(old('write_language') == 2 ||  $detailDiploma->write == 2) checked @endif></td>
                            <td><input type="checkbox" value="3" name="write_language" @if(old('write_language') == 3 ||  $detailDiploma->write == 3) checked @endif></td>
                            <td><input type="checkbox" value="4" name="write_language" @if(old('write_language') == 4 ||  $detailDiploma->write == 4) checked @endif></td>
                          </tr>
                        </table>
                      </div>
                      </div>
                      <hr>
                      <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                      <label>Tin Học Văn Phòng</label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <table style="text-align: center; width: 100%">
                          <tr>
                            <td>&nbsp;</td>
                            <td>Tốt</td>
                            <td>Khá</td>
                            <td>Trung Bình</td>
                            <td>Kém</td>
                          </tr>
                          <tr>
                            <td>MS word</td>
                            <td><input type="checkbox" value="1" name="ms_word" @if(old('ms_word') == 1 ||  $detailDiploma->ms_word == 1) checked @endif></td>
                            <td><input type="checkbox" value="2" name="ms_word" @if(old('ms_word') == 2 ||  $detailDiploma->ms_word == 2) checked @endif></td>
                            <td><input type="checkbox" value="3" name="ms_word" @if(old('ms_word') == 3 ||  $detailDiploma->ms_word == 3) checked @endif></td>
                            <td><input type="checkbox" value="4" name="ms_word" @if(old('ms_word') == 4 ||  $detailDiploma->ms_word == 4) checked @endif></td>
                          </tr>
                          <tr>
                            <td>MS Excel</td>
                            <td><input type="checkbox" value="1" name="ms_excel" @if(old('ms_excel') == 1 ||  $detailDiploma->ms_excel == 1) checked @endif></td>
                            <td><input type="checkbox" value="2" name="ms_excel" @if(old('ms_excel') == 2 || $detailDiploma->ms_excel == 2) checked @endif></td>
                            <td><input type="checkbox" value="3" name="ms_excel" @if(old('ms_excel') == 3 || $detailDiploma->ms_excel == 3) checked @endif></td>
                            <td><input type="checkbox" value="4" name="ms_excel" @if(old('ms_excel') == 4 || $detailDiploma->ms_excel == 4) checked @endif></td>
                          </tr>
                          <tr>
                            <td>MS Power Point</td>
                            <td><input type="checkbox" value="1" name="ms_power_point" @if(old('ms_power_point') == 1 || $detailDiploma->ms_power_point == 1) checked @endif></td>
                            <td><input type="checkbox" value="2" name="ms_power_point" @if(old('ms_power_point') == 2 || $detailDiploma->ms_power_point == 2) checked @endif></td>
                            <td><input type="checkbox" value="3" name="ms_power_point" @if(old('ms_power_point') == 3 || $detailDiploma->ms_power_point == 3) checked @endif></td>
                            <td><input type="checkbox" value="4" name="ms_power_point" @if(old('ms_power_point') == 4 || $detailDiploma->ms_power_point == 4) checked @endif></td>
                          </tr>
                          <tr>
                            <td>MS Outlook</td>
                            <td><input type="checkbox" value="1" name="ms_outlook" @if(old('ms_outlook') == 1 || $detailDiploma->ms_outlook == 1) checked @endif></td>
                            <td><input type="checkbox" value="2" name="ms_outlook" @if(old('ms_outlook') == 2 || $detailDiploma->ms_outlook == 2) checked @endif></td>
                            <td><input type="checkbox" value="3" name="ms_outlook" @if(old('ms_outlook') == 3 || $detailDiploma->ms_outlook == 3) checked @endif></td>
                            <td><input type="checkbox" value="4" name="ms_outlook"> @if(old('ms_outlook') == 4 || $detailDiploma->ms_outlook == 4) checked @endif</td>
                          </tr>
                        </table>
                      </div>
                      </div>
                      <hr>
                      <div class="row">
                      <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                      <label for="others">Kỹ Năng Khác</label>
                      </div>
                      <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                      <div class="form-group">
                          <input type="text" name="others" id="others" class="form-control" value="{!! old('others',$detailDiploma->others) !!}">
                          <span style="color:red">{!! $errors->first('others') !!}</span>
                        </div>
                      </div>
                </div>
                <div class="modal-footer text-center">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Hủy</button>
        <button type="submit" class="btn btn-primary">Lưu</button>
      </div>
                </form>
      </div>
    </div>
  </div>
</div>
@endsection

@section('javascript')
@if($errors->first('company') || $errors->first('position') || $errors->first('wage') || $errors->first('description_job') || $errors->first('achieve'))
<script type="text/javascript">
  $('#modal-company').modal('show');
</script>
@endif

@if($errors->first('level') || $errors->first('school_name') || $errors->first('description_diploma') || $errors->first('loai_tn') || $errors->first('language') || $errors->first('language_level'))
<script type="text/javascript">
  $('#modal-level').modal('show');
</script>
@endif

@if($errors->first('intro'))
<script type="text/javascript">
  $('#modal-intro').modal('show');
</script>
@endif
@endsection

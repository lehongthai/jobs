<?php  
use App\Common;
$infoCompany = Common::getInfoCompanyById($detailJob->employer_id);
$getJobCompany = Common::getJobCompanyById($detailJob->employer_id);
?>
@section('title', $detailJob->title)


@extends('page.master')
@section('content')

<div class="row" style="margin-top: 100px">
<section id="title">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <h1>{!! $detailJob->title !!}</h1><br>
            <h4>
              <span><i class="fa fa-map-marker"></i>
              <?php $arrProvin = explode(',', str_replace('^', '', $detailJob->provin)); ?>
              @foreach($arrProvin as $key => $provin)
                  {!! Common::getProvinNameById($provin) !!}
                  @if($key != (count($arrProvin) - 1))
                  -
                  @endif
              @endforeach
              </span>
              <span><i class="fa fa-clock-o"></i>
                  {!! Common::getTypeNameById($detailJob->type) !!}
              </span>
              <span><i class="fa fa-dollar"></i>{!! Common::getNameById($detailJob->wage) !!}</span>
            </h4>
          </div>
        </div>
      </div>
    </section><hr>
          <div class="col-sm-8">
            <article>
            <div class="alert alert-info">
              <strong>Cập nhật ngày</strong> {!! Carbon\Carbon::parse($detailJob->create_date)->format('d/m/Y') !!} &nbsp; |  &nbsp;
              <strong>Lượt xem</strong> {!! $detailJob->view !!}
            </div>
            <div class="text-center">
              <h3>{!! $infoCompany->name !!}</h3>
              <p>{!! $infoCompany->address !!}</p>
            </div>
              <h2>Chi tiết công việc</h2>
              <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                  <ul>
                    <li><strong>Mức lương:</strong> {!! $detailJob->wage !!}</li>
                    <li><strong>Kinh nghiệm:</strong> {!! Common::getNameById($detailJob->empirical) !!}</li>
                    <li><strong>Trình độ:</strong> {!! Common::getNameById($detailJob->level) !!}</li>
                    <li><strong>Tỉnh/ Thành phố:</strong> 
                    @foreach($arrProvin as $key => $provins)
                    <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                        {!! Common::getProvinNameById($provins) !!}
                        </a>
                        @if($key != (count($arrProvin) - 1))
                        -
                        @endif
                    @endforeach
                  </li>
                    <li><strong>Ngành nghề:</strong>
                    <?php $arrJobs = explode(',', str_replace('^', '', $detailJob->fields)); ?> 
                    @foreach($arrJobs as $key => $jobs)
                    <a href="{!! url('viec-lam/'. convert_vi_to_en(Common::getJobNameById($jobs)) . '-' . $jobs . '.html') !!}">
                        {!! Common::getJobNameById($jobs) !!}
                        </a>
                        @if($key != (count($arrJobs) - 1))
                        ,
                        @endif
                    @endforeach
                    </li>
                  </ul>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                  <ul>
                    <li><strong>Số lượng tuyển dụng:</strong> {!! $detailJob->quanlity !!}</li>
                    <li><strong>Giới tính:</strong> 
                    @if($detailJob->sex == NULL)
                    Không yêu cầu
                    @elseif($detailJob->sex == 1)
                    Nam
                    @elseif($detailJob->sex == 2)
                    Nữ
                    @endif
                    </li>
                    <li><strong>Tính chất công việc:</strong> {!! Common::getNameById($detailJob->attribute) !!}</li>
                    <li><strong>Hình thức làm việc:</strong> 
                    {!! Common::getTypeNameById($detailJob->type) !!}
                    </li>
                    <li><strong>Hạn chốt:</strong> {!! Carbon\Carbon::parse($detailJob->expired_at)->format('d/m/Y') !!}</li>
                  </ul>
                </div>
              </div>
              <h3>Mô tả</h3>
              {!! $detailJob->description !!}
              <h3>Yêu cầu</h3>
              {!! $detailJob->require !!}
              <h3>Lợi ích</h3>
              {!! $detailJob->benefit !!}
              <hr>
              <p>
                <a href="{!! url('ung-vien/luu-ho-so/' . $detailJob->id) !!}" class="btn btn-primary btn-lg">Lưu Công Việc</a>
                &nbsp;
                <a href="{!! url('ung-vien/nop-ho-so/' . $detailJob->id) !!}" class="btn btn-success btn-lg pull-right">Nộp Hồ Sơ</a>
                &nbsp;
              </p>
            </article>
            <article>
              <h2>Việc làm liên quan</h2>
              <div class="jobs">
              @foreach($listRelatedJob as $k => $relatedJob)
              <div class="custom-find-job">
                <div class="title">
                <a href="{!! url('cong-viec/'. $relatedJob->alias . '-' . $relatedJob->id . '.html') !!}">
                  <h5>{!! $relatedJob->title !!}</h5>
                  </a>
                   <a href="{!! url('cong-ty/'. convert_vi_to_en(Common::getCompanyNameById($relatedJob->employer_id)) . '-' . $relatedJob->employer_id . '.html') !!}">
                  <p>{!! Common::getCompanyNameById($relatedJob->employer_id); !!}</p>
                  </a>
                </div>
                <div class="data">
                  <span class="city"><i class="fa fa-map-marker"></i>
                  <?php $arrProvinRelated = explode(',', str_replace('^', '', $relatedJob->provin)); ?>
                  @foreach($arrProvinRelated as $ke => $provin)
                  <a href="{!! url('tinh-thanh/'. convert_vi_to_en(Common::getProvinNameById($provin)) . '-' . $provin . '.html') !!}">
                    {!! Common::getProvinNameById($provin) !!}
                    </a>
                    @if($ke != (count($arrProvinRelated) - 1)),@endif
                  @endforeach
                  </span>
                  <span class="type part-time"><i class="fa fa-clock-o"></i>
                  {!! Common::getTypeNameById($relatedJob->type) !!}
                  </span>
                  <span class="sallary"><i class="fa fa-dollar"></i>{!! Common::getNameById($relatedJob->wage) !!}</span>
                </div>
              </a>
              </div>
              @endforeach
              </div>
            </article>
          </div>
          <div class="col-sm-4" id="sidebar">
            <div class="sidebar-widget" id="share">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <a onclick="return false;" class="thumbnail">
                <img src="{!! url('public\upload\company\\'). $infoCompany->logo !!}" alt="{!! $infoCompany->name !!}">
              </a>
              <h4>{!! $infoCompany->name !!}</h4>
              <strong>Điạ Chỉ: </strong><p>{!! $infoCompany->address !!}</p>
              <strong>Điện Thoại: </strong><p>{!! $infoCompany->phone !!}</p>
              <strong>Website: </strong><a href="{!! $infoCompany->website !!}" target="_blank">{!! $infoCompany->website !!}</a>
            </div>
            </div>
            <div class="sidebar-widget" id="company">
              <h2>Chúng tôi đang tuyển dụng</h2>
              @foreach($getJobCompany as $key => $job)
              <a href="{!! url('cong-viec/'. $job->alias . '-' . $job->id . '.html') !!}"><h5>{!! $job->title !!}</h5></a>
              <ul>
                <li><i class="fa fa-map-marker"></i>
                <?php $arrProvinCompany = explode(',', str_replace('^', '', $job->provin)); ?>
                  @foreach($arrProvinCompany as $k => $provins)
                  {!! Common::getProvinNameById($provins) !!}
                  @if($k != (count($arrProvinCompany) - 1))
                  ,
                  @endif
              @endforeach
                </li>
                <li style="float: right"><i class="fa fa-dollar"></i>{!! Common::getNameById($job->wage) !!}</li>
              </ul>
              @endforeach
            </div>
            <hr>
            <div class="sidebar-widget" id="company-jobs">
              @include('page.blocks.fullFindJob')
            </div>
          </div>
        </div>
      </div>
    </section>
@endsection

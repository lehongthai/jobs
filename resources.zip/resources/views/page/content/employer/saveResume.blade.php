@extends('page.master')
@section('title', $title)
@section('content')
{{-- add menu user --}}
@include('page.blocks.menu_bottom_employer')
{{-- end menu user --}}
<div class="row" style="margin-top: 100px">
@include('page.blocks.info')
	<table class="table table-bordered" id="datatable-savejob">
		<thead>
			<tr style="background-color: #14B1BB">
				<th>Thứ tự</th>
				<th>Công việc</th>
				<th>Hồ sơ</th>
				<th>Trình độ</th>
				<th>Ngày lưu</th>
				<th>Trạng thái</th>
				<th>Cập nhật</th>
				<th>Xóa</th>
			</tr>
		</thead>
		<tbody>
		@foreach($listSaveResume as $key => $saveResume)
			<tr>
				<td>{!! $key + 1 !!}</td>
				<td><a href="{!! url('cong-viec/' . $saveResume->pAlias . '-' . $saveResume->pId . '.html') !!}">{!! $saveResume->pTitle !!}</a></td>
				<td><a href="{!! url('ho-so/' . $saveResume->cAlias . '-' . $saveResume->cId . '.html') !!}">{!! $saveResume->cTitle !!}</a></td>
				<td>{!! $saveResume->iName !!}</td>
				<td>{!! Carbon\Carbon::parse($saveResume->create_date)->format('d/m/Y') !!}</td>
				<td>
					<table>
						<ul>
							<li><div class="checkbox">
									<label>
										<input type="checkbox" @if($saveResume->da_lien_he == 1) checked @endif>
										Đã liên hệ
									</label>
								</div>
							</li>
							<li>
								<div class="checkbox">
									<label>
										<input type="checkbox" @if($saveResume->da_phong_van == 1) checked @endif>
										Đã phỏng vấn
									</label>
								</div>
							</li>
							<li>
								<div class="checkbox">
									<label>
										<input type="checkbox" @if($saveResume->da_test == 1) checked @endif>
										Đã test
									</label>
								</div>
							</li>
							<li>
								<div class="checkbox">
									<label>
										<input type="checkbox" @if($saveResume->trung_tuyen == 1) checked @endif>
										Trúng tuyển
									</label>
								</div>
							</li>
							<li>
								<div class="checkbox">
									<label>
										<input type="checkbox" @if($saveResume->tu_choi == 1) checked @endif>
										Từ chối
									</label>
								</div>
							</li>
						</ul>
					</table>
				</td>
				<td><a href="{!! url('nha-tuyen-dung/cap-nhat-ho-so-da-luu/' . $saveResume->id) !!}">Cập nhật</a></td>
				<td><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="{!! url('nha-tuyen-dung/xoa-ho-so-da-luu/' . $saveResume->id) !!}">Xóa</a></td>
			</tr>
		@endforeach
		</tbody>
	</table>
</div>
@endsection

@section('javascript')
<script src="{!! url('public/admin') !!}/bower_components/DataTables/media/js/jquery.dataTables.min.js"></script>
    <script src="{!! url('public/admin') !!}/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    $('#datatable-savejob').DataTable({
    	"language": {
            "lengthMenu": "Hiển thị _MENU_ Số lượng tin hiển thị",
            "zeroRecords": "Không có kết quả nào",
            "info": "Hiển thị tin _PAGE_ của _PAGES_",
            "infoEmpty": "Không có kết quả nào",
            "infoFiltered": "(filtered from _MAX_ total records)",
            "sSearch":        "Tìm Kiếm: "
        }
    });
    $(".input-sm").css({
    	height: '40px'
  	});
});
	
</script>
@endsection


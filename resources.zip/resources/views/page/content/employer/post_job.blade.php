@extends('page.master')
@section('title', $title)
@section('content')
@include('page.blocks.loginInline')
{{-- add menu user --}}
@include('page.blocks.menu_bottom_employer')
{{-- end menu user --}}
<div class="row" style="margin-top: -100px">
<div class="col-sm-8">
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Đăng Tin Tuyển Dụng</h3>
  </div>
  <div class="panel-body">
    <form action="{!! url('nha-tuyen-dung/dang-tin-tuyen-dung') !!}" method="POST" class="form-horizontal" role="form">
    <input type="hidden" name="_token" value="{!! csrf_token() !!}">
    <div class="row">
    <div class="col-sm-4">
    <label>Tiêu Đề <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
            <input type="text" name="title" class="form-control" value="{!! old('title') !!}">
            <span style="color:red">{!! $errors->first('title') !!}</span>
        </div>
    </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Số Lượng Cần Tuyển</label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <input type="text" name="quanlity" class="form-control" value="{!! old('quanlity') !!}">
        <span style="color:red">{!! $errors->first('quanlity') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Giới Tính <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <select name="sex" class="form-control">
          <option value="">-- Không yêu cầu --</option>
          <option value="1" @if(old('sex') == 1) selected @endif>-- Nam --</option>
          <option value="2" @if(old('sex') == 2) selected @endif>-- Nữ --</option>
        </select>
        <span style="color:red">{!! $errors->first('sex') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Mô Tả Công Việc <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <textarea name="description" class="form-control" rows="5" required="required">{!! old('description') !!}</textarea>
        <span style="color:red">{!! $errors->first('description') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Yêu Cầu Công Việc</label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <textarea name="require" class="form-control" rows="5">{!! old('require') !!}</textarea>
        <span style="color:red">{!! $errors->first('require') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Tính Chất Công Việc <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <select name="attribute" class="form-control">
          <option value="">-- Select One --</option>
          @foreach($listAttribute as $attribute)
          <option value="{!! $attribute->id !!}" @if(old('attribute') == $attribute->id) selected @endif>-- {!! $attribute->name !!} --</option>
          @endforeach
        </select>
        <span style="color:red">{!! $errors->first('attribute') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Trình Độ <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <select name="level" class="form-control">
          <option value="">-- Select One --</option>
          @foreach($listLevel as $level)
          <option value="{!! $level->id !!}" @if(old('level') == $level->id) selected @endif>-- {!! $level->name !!} --</option>
          @endforeach
        </select>
        <span style="color:red">{!! $errors->first('level') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Kinh Nghiệm <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <select name="empirical" class="form-control">
          <option value="">-- Select One --</option>
          @foreach($listEmpirical as $empirical)
          <option value="{!! $empirical->id !!}" @if(old('empirical') == $empirical->id) selected @endif>-- {!! $empirical->name !!} --</option>
          @endforeach
        </select>
        <span style="color:red">{!! $errors->first('empirical') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Mức Lương <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <select name="wage" class="form-control">
          <option value="">-- Select One --</option>
          @foreach($listWage as $wage)
          <option value="{!! $wage->id !!}" @if(old('wage') == $wage->id) selected @endif>-- {!! $wage->name !!} --</option>
          @endforeach
        </select>
        <span style="color:red">{!! $errors->first('wage') !!}</span>
        </div>
        </div>
    </div>


    <div class="row">
    <div class="col-sm-4">
    <label>Hoa Hồng <span>(nếu có)</span></label>
    </div>
    <div class="col-sm-1">
    Từ:
    </div>
    <div class="col-sm-3">
        <div class="form-group">
        <input type="text" name="min_kickback" class="form-control" value="{!! old('min_kickback') !!}">
        <span style="color:red">{!! $errors->first('min_kickback') !!}</span>
        </div>
        </div>
        <div class="col-sm-1">
    Đến:
    </div>
        <div class="col-sm-3">
        <div class="form-group">
        <input type="text" name="max_kickback" class="form-control" value="{!! old('max_kickback') !!}">
        <span style="color:red">{!! $errors->first('max_kickback') !!}</span>
        </div>
        </div>
    </div>
    
    
    <div class="row">
    <div class="col-sm-4">
    <label>Hình Thức Làm Việc <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <select name="type" class="form-control">
          <option value="">-- Select One --</option>
          @foreach($listType as $type)
          <option value="{!! $type->id !!}" @if(old('type') == $type->id) selected @endif>-- {!! $type->name !!} --</option>
          @endforeach
        </select>
        <span style="color:red">{!! $errors->first('type') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Thời Gian Thử Việc <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <select name="probation_time" class="form-control">
          <option value="">-- Select One --</option>
          @foreach($listProbationTime as $probation_time)
          <option value="{!! $probation_time->id !!}" @if(old('probation_time') == $probation_time->id) selected @endif>-- {!! $probation_time->name !!} --</option>
          @endforeach
        </select>
        <span style="color:red">{!! $errors->first('probation_time') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Quyền Lợi</label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <textarea name="benefit" class="form-control" rows="5">{!! old('benefit') !!}</textarea>
        <span style="color:red">{!! $errors->first('benefit') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Ngành Nghề <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">

        <select data-placeholder="Chọn tối đa 3 việc" name="job[]" multiple id="input" class="form-control multiple-select2">
          <option value="">-- Select One --</option>
          @foreach($listJob as $job)
          <option value="{!! $job->id !!}" @if(old('job') != NULL) @if(in_array($job->id, old('job'))) selected @endif @endif>-- {!! $job->name !!} --</option>
          @endforeach
        </select>
        <span style="color:red">{!! $errors->first('job') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Nơi Làm Việc <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <select data-placeholder="Chọn tối đa 3 tỉnh" name="provin[]" multiple='multiple' id="input" class="form-control multiple-select2">
          <option value="">-- Select One --</option>
          @foreach($listProvin as $provin)
          <option value="{!! $provin->id !!}"" @if(old('provin') != NULL) @if(in_array($provin->id, old('provin'))) selected @endif @endif>-- {!! $provin->name !!} --</option>
          @endforeach
        </select>
        <span style="color:red">{!! $errors->first('provin') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Hết Hạn <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <input type="date" name="expired_at" class="form-control" value="{!! old('expired_at') !!}">
        <span style="color:red">{!! $errors->first('expired_at') !!}</span>
        </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-4">
    <label>Cho xem đăng việc <span class="require">*</span></label>
    </div>
    <div class="col-sm-8">
        <div class="form-group">
        <div class="radio">
            <label>
                <input type="radio" name="status" value="1" @if(old('status') == 1) checked="checked" @endif>
                Cho Xem
            </label>
            <label>
                <input type="radio" name="status" value="2" @if(old('status') == 2) checked="checked" @endif>
                Không Cho Xem
            </label>
        </div>
        <span style="color:red">{!! $errors->first('status') !!}</span>
        </div>
        </div>
    </div>
    
        <div class="form-group text-center">
          <div class="col-sm-10 col-sm-offset-2">
            <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-floppy-saved"></i>Lưu</button>
                            <button type="button" class="btn btn-warning"><i class="glyphicon glyphicon-remove"></i>Hủy</button>
          </div>
        </div>
    </form>
  </div>
</div>

</div>
  <div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindResume')
            </div>
            </div>
</div>
@endsection

@section('javascript')
<script src="{!! url('public/admin') !!}/js/select2.min.js"></script>
<script type="text/javascript">
    $('.multiple-select2').select2({
        maximumSelectionLength: 3,
        "language": "pt-BR"
    });
</script>
@endsection

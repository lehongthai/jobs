<?php
use App\Common; 
$listJob = Common::getJob();
$listProvin = Common::getProvin();
$listLevel = Common::getLevel();
$listEmpirical = Common::getEmpirical();
$listExigency = Common::getExigency();
$listType = Common::getType();
?>
@extends('page.master')
@section('title', $title)
@section('content')
{{-- add menu user --}}
@include('page.blocks.menu_bottom_employer')
{{-- end menu user --}}
<div class="row" style="margin-top: 100px">
<div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-md-offset-2">
<h2>Tìm kiếm ứng viên</h2>
<form action="{!! url('tim-kiem-ho-so') !!}" method="get" role="form">
  <div class="form-group">
    <input type="text" class="form-control" name="title" placeholder="Nhập từ khóa" @if(isset($_GET['title'])) value="{!! $_GET['title'] !!}" @endif>
  </div>
  <div class="form-group">
    <select name="job" class="form-control">
      <option value="">-- Công Việc --</option>
      @foreach($listJob as $job)
      <option value="{!! $job->id !!}" @if(isset($_GET['job']) && $_GET['job'] == $job->id) selected @endif>-- {!! $job->name !!} --</option>
      @endforeach
    </select>
    <span style="color:red">{!! $errors->first('job') !!}</span>
  </div>
  <div class="form-group">
    <select name="provin" class="form-control">
      <option value="">-- Địa Điểm --</option>
      @foreach($listProvin as $provin)
      <option value="{!! $provin->id !!}" @if(isset($_GET['provin']) && $_GET['provin'] == $provin->id) selected @endif>-- {!! $provin->name !!} --</option>
      @endforeach
    </select>
    <span style="color:red">{!! $errors->first('provin') !!}</span>
  </div>
  <div class="form-group">
    <select name="level" class="form-control">
      <option value="">-- Bằng Cấp --</option>
      @foreach($listLevel as $level)
      <option value="{!! $level->id !!}" @if(isset($_GET['level']) && $_GET['level'] == $level->id) selected @endif>-- {!! $level->name !!} --</option>
      @endforeach
    </select>
    <span style="color:red">{!! $errors->first('level') !!}</span>
  </div>
  <div class="form-group">
    <select name="sex" class="form-control">
      <option value="0">-- Không yêu cầu --</option>
      <option value="1" @if(isset($_GET['sex']) && $_GET['sex'] == 1) selected @endif>-- Nam --</option>
      <option value="2" @if(isset($_GET['sex']) && $_GET['sex'] == 2) selected @endif>-- Nữ --</option>
    </select>
    <span style="color:red">{!! $errors->first('sex') !!}</span>
  </div>
  <div class="form-group">
    <select name="type" class="form-control">
      <option value="">-- Hình Thức làm Việc --</option>
      @foreach($listType as $type)
      <option value="{!! $type->id !!}" @if(isset($_GET['type']) && $_GET['type'] == $type->id) selected @endif>-- {!! $type->name !!} --</option>
      @endforeach
    </select>
    <span style="color:red">{!! $errors->first('type') !!}</span>
  </div>
  <div class="form-group">
    <select name="empirical" class="form-control">
      <option value="">-- Kinh Nghiệm --</option>
      @foreach($listEmpirical as $empirical)
      <option value="{!! $empirical->id !!}" @if(isset($_GET['empirical']) && $_GET['empirical'] == $empirical->id) selected @endif>-- {!! $empirical->name !!} --</option>
      @endforeach
    </select>
    <span style="color:red">{!! $errors->first('empirical') !!}</span>
  </div>
  <button type="submit" class="btn btn-primary">Tìm Kiếm</button>
</form>
</div>
@endsection


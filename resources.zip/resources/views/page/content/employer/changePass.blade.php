@extends('page.master')
@section('title', $title)
@section('content')
@include('page.blocks.loginInline')
{{-- add menu user --}}
@include('page.blocks.menu_bottom_employer')
{{-- end menu user --}}
<div class="row" style="margin-top: -100px">
<div class="col-sm-8">
@include('page.blocks.info')
<form method="post" action="{!! url('nha-tuyen-dung/thay-doi-mat-khau') !!}">
  <input type="hidden" name="_token" id="input_token" class="form-control" value="{!! csrf_token() !!}">

<div class="row">
  <h2>Thay đổi mật khẩu</h2>
  <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
    <label>Mật khẩu cũ</label><span class="require">*</span>
  </div>
  <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
    <div class="form-group">
        <input type="password" name="passwordOld" class="form-control">
        <span style="color:red">{!! $errors->first('passwordOld') !!}</span>
        @if(Session::has('flash_message_password_error'))
        <span style="color:red">{!! Session::get('flash_message_password_error') !!}</span>
        @endif
    </div>
  </div>
  <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
    <label>Mật khẩu mới</label><span class="require">*</span>
  </div>
  <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
    <div class="form-group">
        <input type="password" name="passwordNew" class="form-control">
        <span style="color:red">{!! $errors->first('passwordNew') !!}</span>
    </div>
  </div>
  <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
    <label>Nhập lại mật khẩu</label><span class="require">*</span>
  </div>
  <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
    <div class="form-group">
        <input type="password" name="passwordNewConfirm" class="form-control">
        <span style="color:red">{!! $errors->first('passwordNewConfirm') !!}</span>
    </div>
  </div>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
  <div class="form-group">
 <button type="submit" class="btn btn-large btn-block btn-danger">Đổi mật khẩu</button>
</div>
</div>
</div>
</form>
</div>
  <div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindResume')
            </div>
            </div>
</div>
@endsection


<?php
use App\Common; 
?>
@extends('page.master')
@section('title', 'Quản lý tin tuyển dụng')
@section('content')
@include('page.blocks.loginInline')
{{-- add menu user --}}
@include('page.blocks.menu_bottom_employer')
{{-- end menu user --}}
<div class="row" style="margin-top: -100px">
@include('page.blocks.info')
	<table class="table table-bordered" id="datatable-savejob">
		<thead>
			<tr style="background-color: #14B1BB">
				<th>Thứ tự</th>
				<th>Tên</th>
				<th>Trạng Thái</th>
				<th>Hết hạn</th>
				<th>Cập Nhật</th>
				<th>Ứng tuyển</th>
				<th>Lượt Xem</th>
				<th>Cập nhật</th>
				<th>Xóa</th>
			</tr>
		</thead>
		<tbody>
		@foreach($listPostJob as $key => $postJob)
			<tr>
				<td>{!! $key + 1 !!}</td>
				<td><a href="{!! url('cong-viec/' . $postJob->alias . '-' . $postJob->id . '.html') !!}" target="_blank">{!! $postJob->title !!}</a></td>
				<td>@if($postJob->active == 1)
				Đã Duyệt
				@else
				Chờ Duyệt
				@endif
				</td>
				<td>{!! Carbon\Carbon::parse($postJob->expired_at)->format('d/m/Y') !!}</td>
				<td>{!! Carbon\Carbon::parse($postJob->create_date)->format('d/m/Y') !!}</td>
				<td>{!! Common::countViewJob($postJob->id) !!}</td>
				<td>{!! $postJob->view !!}</td>
				<td><a href="{!! url('nha-tuyen-dung/cap-nhat-tin-tuyen-dung/' . $postJob->id) !!}">Cập nhật</a></td>
				<td><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="{!! url('nha-tuyen-dung/xoa-tin-tuyen-dung/' . $postJob->id) !!}">Xóa</a></td>
			</tr>
		@endforeach
		</tbody>
	</table>
</div>
@endsection

@section('javascript')
<script src="{!! url('public/admin') !!}/bower_components/DataTables/media/js/jquery.dataTables.min.js"></script>
    <script src="{!! url('public/admin') !!}/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    $('#datatable-savejob').DataTable({
    	"language": {
            "lengthMenu": "Hiển thị _MENU_ Số lượng tin hiển thị",
            "zeroRecords": "Không có kết quả nào",
            "info": "Hiển thị tin _PAGE_ của _PAGES_",
            "infoEmpty": "Không có kết quả nào",
            "infoFiltered": "(filtered from _MAX_ total records)",
            "sSearch":        "Tìm Kiếm: "
        }
    });
    $(".input-sm").css({
    	height: '40px'
  	});
});
	
</script>
@endsection


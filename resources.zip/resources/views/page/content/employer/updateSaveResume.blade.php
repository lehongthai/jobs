@extends('page.master')
@section('title', $title)
@section('content')
@include('page.blocks.loginInline')
{{-- add menu user --}}
@include('page.blocks.menu_bottom_employer')
{{-- end menu user --}}
<div class="row" style="margin-top: -100px">
<div class="col-sm-8">
<form action="{!! url('nha-tuyen-dung/cap-nhat-ho-so-da-luu') !!}" method="POST" class="form-horizontal" role="form">
 <input type="hidden" name="_token" value="{!! csrf_token() !!}">
  <input type="hidden" name="id" value="{!! $infoSaveResume->id !!}">
        <div class="form-group">
            <legend>Cập nhật hồ sơ đã lưu</legend>
        </div>
        <div class="form-group">
            <label>Công Việc</label>
            <select name="job" class="form-control">
                <option value="">-- Chọn công việc --</option>
                @foreach($listJob as $k => $job)
                <option value="{!! $job->id !!}">-- {!! $job->title !!} --</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label>Trạng thái</label>
            <table>
                        <ul>
                            <li><div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="1" @if($infoSaveResume->da_lien_he == 1) checked @endif name="da_lien_he">
                                        Đã liên hệ
                                    </label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="1" @if($infoSaveResume->da_phong_van == 1) checked @endif name="da_phong_van">
                                        Đã phỏng vấn
                                    </label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="1" @if($infoSaveResume->da_test == 1) checked @endif name="da_test">
                                        Đã test
                                    </label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="1" @if($infoSaveResume->trung_tuyen == 1) checked @endif name="trung_tuyen">
                                        Trúng tuyển
                                    </label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="1" @if($infoSaveResume->tu_choi == 1) checked @endif name="tu_choi">
                                        Từ chối
                                    </label>
                                </div>
                            </li>
                        </ul>
                    </table>
        </div>
        <div class="form-group">
        <label>Ghi chú</label>
        <textarea name="note" class="form-control" rows="3">{!! old('note', $infoSaveResume->note) !!}</textarea>
        </div>
        <div class="form-group">
            <div class="col-sm-10 col-sm-offset-2">
                <button type="submit" class="btn btn-primary">Cập nhật</button>
            </div>
        </div>
</form>

</div>
 <div class="col-sm-4" id="sidebar">
              <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindResume')
            </div>
            </div>
</div>
@endsection

@section('javascript')
<script src="{!! url('public/admin') !!}/js/select2.min.js"></script>
<script type="text/javascript">
    $('.multiple-select2').select2({
        maximumSelectionLength: 3,
        "language": "pt-BR"
    });
</script>
@endsection

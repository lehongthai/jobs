<?php
use App\Common; 
?>
@extends('page.master')
@section('title', $title)
@section('content')
@include('page.blocks.loginInline')

        <div class="row" style="margin-top: -180px">
          <div class="col-sm-8">
            <h2>Câu hỏi thường gặp</h2>

           <div class="panel-group" id="accordion">
           @foreach($listAq as $k => $aq)
              <div class="panel panel-primary">
                <div class="panel-heading">
                  <h4 class="panel-title">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne{!! $k+1 !!}">
                      {!! $k+1 . '  -  ' . $aq->answer !!}
                      <i class="indicator glyphicon @if($k == 0) glyphicon-chevron-up @else glyphicon-chevron-down @endif pull-right"></i>
                    </a>
                  </h4>
                </div>
                <div id="collapseOne{!! $k+1 !!}" class="panel-collapse collapse @if($k == 0) in @endif">
                  <div class="panel-body">
                    {!! $aq->question !!}
                  </div>
                </div>
              </div>
              @endforeach
            </div>

          </div>
          <div class="col-sm-4" id="sidebar">
            <div class="sidebar-widget" id="jobsearch">
              @include('page.blocks.silderBarJob')
              <hr>
              
              @include('page.blocks.fullFindJob')
            </div>
            <!-- Find a Job End -->

          </div>
        </div>

@endsection

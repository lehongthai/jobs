<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>

<div>
    <h3>Xác nhận tài khoản</h3>
    
</div>
<p>Vui lòng click vào đường link bên dưới để xác nhận tài khoản <br> <a href="{!! url('/') . '/user/active/' . $id !!}">Click vào đây</a></p>
</body>
</html>
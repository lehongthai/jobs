@extends('layouts.admin')
@section('title', $title)
@section('body_right')

    <div class="col-lg-11" style="padding-bottom:120px">
    <h2 class="text-center">Thông tin công ty {!! $infoEmployer->name !!}</h2>
       <table class="table table-condensed table-hover">
           <thead>
               <tr>
                   <th>Email đăng nhập</th>
                   <td>{!! $infoEmployer->uEmail !!}</td>
               </tr>
           </thead>
           <tbody>
               <tr>
                    <th>Tên công ty</th>
                    <td>{!! $infoEmployer->name !!}</td>
               </tr>
               <tr>
                    <th>Logo công ty</th>
                    <td>
                        <a onclick="return false;" class="thumbnail">
                        <img src="{!! url('public\upload\company\\'). $infoEmployer->logo !!}" alt="{!! $infoEmployer->name !!}">
                      </a>
                    </td>
               </tr>
               <tr>
                    <th>Website</th>
                    <td><a href="{!! $infoEmployer->website !!}" target="_blank">{!! $infoEmployer->name !!}</a></td>
               </tr>
               <tr>
                    <th>Điện thoại</th>
                    <td>{!! $infoEmployer->phone !!}</td>
               </tr>
               <tr>
                    <th>Fax</th>
                    <td>{!! $infoEmployer->fax !!}</td>
               </tr>
               <tr>
                    <th>Địa chỉ</th>
                    <td>{!! $infoEmployer->address !!}</td>
               </tr>
               <tr>
                    <th>Trạng thái</th>
                    <td>@if($infoEmployer->active != 1)
                        Chưa kích hoạt
                        @else
                        Đã kích hoạt
                        @endif
                    </td>
               </tr>
               
               <tr>
                    <th>Tổng số việc làm</th>
                    <td>{!! $infoEmployer->count_job !!}</td>
               </tr>
               <tr>
                    <th>Ngày tạo</th>
                    <td>{!! Carbon\Carbon::parse($infoEmployer->create_date)->format('d/m/Y'); !!}</td>
               </tr>
              
           </tbody>
       </table>
       @if($infoEmployer->active != 1)
       <button type="button" class="btn btn-large btn-block btn-success" onclick="window.location='{!! url('admin/quan-ly-thanh-vien/kich-hoat-cong-ty/' . $infoEmployer->id) !!}'">Kích hoạt</button>
       @else
       <button type="button" class="btn btn-large btn-block btn-danger" onclick="window.location='{!! url('admin/quan-ly-thanh-vien/bo-kich-hoat-cong-ty/' . $infoEmployer->id) !!}'">Bỏ kích hoạt</button>
       @endif
    </div>
@endsection()

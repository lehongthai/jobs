@extends('layouts.admin')
@section('title', $title)
@section('body_right')   
    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
            <tr align="center">
                <td style="display: none"></td>
                <td style="display: none"></td>
                <th>Thứ tự</th>
                <th>Email</th>
                @if($url == 'nha-tuyen-dung')
                <th>Tên công ty</th>
                @elseif($url == 'ung-vien')
                <th>Tên ứng viên</th>
                @endif
                <th>Trạng thái tài khoản</th>
                <th>Trạng thái kích hoạt</th>
                <th>Ngày tạo</th>
                <th>Delete</th>   
            </tr>
        </thead>
        <tbody>
        @if(isset($listUser) && $listUser != NULL)
        @foreach($listUser as $index => $item)
            <tr class="odd gradeX" align="center">
                <td style="display: none">{!! $item->id !!}</td>
                <td style="display: none">{!! csrf_token() !!}</td>
                <td>{!! $index+1 !!}</td>
                <td>{!! $item->email !!}</td>
                @if($url == 'nha-tuyen-dung')
                <td>
                    <a href="{!! url('admin/quan-ly-thanh-vien/xem-nhanh/') . '/' . $item->alias . '-' . $item->cId . '.html' !!}" target="_blank">
                        {!! $item->name !!}
                    </a>
                </td>
                @elseif($url == 'ung-vien')
                <td>{!! $item->fullname !!}</td>
                @endif
                <td>
                    @if($item->banded == 1)
                    Đang hoạt động
                    @else
                    Cấm hoạt động
                    @endif
                </td>
                <td>
                    @if($item->active == 1)
                    Đã kích hoạt
                    @else
                    Chưa kích hoạt
                    @endif
                </td>
                <td>{!! Carbon\Carbon::parse($item->create_date)->format('d/m/Y'); !!}</td>
                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="{!! url('admin/quan-ly-thanh-vien/xoa-thanh-vien/') . '/' . $item->id !!}"> Delete</a></td>
            </tr>
        @endforeach()
        @endif
        </tbody>
    </table>

<script src="{!! url('public/admin') !!}/js/jquery.tabledit.js"></script>
<script type="text/javascript">
    $('#dataTables-example').Tabledit({
    url: '{!! url('admin/quan-ly-thanh-vien/sua-nhanh') !!}',
    deleteButton: false,
    columns: {
        identifier: [0, 'id'],
        editable: [[1, '_token'],  [5, 'banded', '{"1": "Hoạt động", "2": "Cấm hoạt động"}']]
    },
    action: 'Sửa Nhanh',
    onDraw: function() {
    },

    onSuccess: function(data, textStatus, jqXHR) {
        window.location.href="{!! url('admin/quan-ly-thanh-vien/' . $url) !!}";
    },
    onFail: function(jqXHR, textStatus, errorThrown) {
        $(function() {
        $('#dialog-message').empty();
          $('#dialog-message').append(jqXHR['responseJSON']['code']);
          $( "#dialog-message" ).dialog({
                modal: true,
                buttons: [
                          {
                              text: "OK",
                              click: function() {                     
                                  $(this).dialog("close"); 
                                  var row_fail = $('.danger').index();
                                  $('.tabledit-edit-button')[row_fail].click();
                                  $('input[name="'+ jqXHR['responseJSON']['position_error'] +'"]').focus();
                              }
                          }
                        ]
          });
        });
        },
    onAlways: function() {
    },
    onAjax: function(action, serialize) {
    }
});
</script>
@endsection
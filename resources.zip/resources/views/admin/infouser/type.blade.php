@extends('layouts.admin')
@section('title', $title)
@section('body_right')
    <button type="button" onclick="window.location='{!! url('admin/info/add/'.$check) !!}'" class="btn btn-success">Thêm mới</button>
    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
            <tr align="center">
                <th>Thứ tự</th>
                <th>Tên</th>
                <th>Danh mục</th>
                <th>Edit</th>
                <th>Delete</th>   
            </tr>
        </thead>
        <tbody>
        @if(isset($data) && $data != NULL)
        @foreach($data as $index => $item)
            <tr class="odd gradeX" align="center">
            <td>{!! $index+1 !!}</td>
                <td>{!! $item->name !!}</td>
                <td>Loại việc làm</td>
                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="{!! URL::route('admin.infouser.getEditType', $item->id) !!}">Edit</a></td>
                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a onclick="return confirm_delete('Bạn chắc chắn xóa !')" href="{!! URL::route('admin.infouser.getDeleteType', $item->id) !!}"> Delete</a></td>
            </tr>
        @endforeach()
        @endif
        </tbody>
    </table>
@endsection